-- ============================================================
-- MBA Communication Dominance — Complete Database Schema
-- Run this in Supabase SQL Editor (Dashboard → SQL Editor → New query)
-- ============================================================

-- ─────────────────────────────────────────────
-- 1. EXTENSIONS
-- ─────────────────────────────────────────────
create extension if not exists "pgcrypto";

-- ─────────────────────────────────────────────
-- 2. PROFILES
-- ─────────────────────────────────────────────
create table if not exists public.profiles (
  id             uuid        primary key references auth.users(id) on delete cascade,
  full_name      text,
  email          text,
  college        text,
  student_id     text        unique,           -- auto-generated on enrollment e.g. MBAC-2024-0042
  avatar_url     text,
  created_at     timestamptz default now(),
  updated_at     timestamptz default now()
);

-- ─────────────────────────────────────────────
-- 3. PAYMENTS
-- ─────────────────────────────────────────────
create table if not exists public.payments (
  id                  uuid        primary key default gen_random_uuid(),
  user_id             uuid        not null references auth.users(id) on delete cascade,
  razorpay_order_id   text        not null unique,
  razorpay_payment_id text        unique,
  razorpay_signature  text,
  amount_paise        integer     not null default 19900,  -- ₹199 in paise
  currency            text        not null default 'INR',
  status              text        not null default 'created'  -- created | paid | failed | refunded
                        check (status in ('created','paid','failed','refunded')),
  payload             jsonb,                               -- full Razorpay webhook payload
  verified_at         timestamptz,
  created_at          timestamptz default now()
);

-- ─────────────────────────────────────────────
-- 4. ENROLLMENTS
-- ─────────────────────────────────────────────
create table if not exists public.enrollments (
  id              uuid        primary key default gen_random_uuid(),
  user_id         uuid        not null unique references auth.users(id) on delete cascade,
  payment_id      uuid        references public.payments(id),
  enrolled_at     timestamptz default now(),
  expires_at      timestamptz,                             -- null = lifetime
  is_active       boolean     default true,
  coupon_code     text,
  amount_paid     integer     default 19900
);

-- ─────────────────────────────────────────────
-- 5. DAILY SUBMISSIONS
-- ─────────────────────────────────────────────
create table if not exists public.submissions (
  id              uuid        primary key default gen_random_uuid(),
  user_id         uuid        not null references auth.users(id) on delete cascade,
  day_number      integer     not null check (day_number between 1 and 30),
  content         text        not null check (char_length(content) >= 50),
  word_count      integer     generated always as (
                    array_length(string_to_array(trim(content), ' '), 1)
                  ) stored,
  submitted_at    timestamptz default now(),
  unique (user_id, day_number)                             -- one submission per day per user
);

-- ─────────────────────────────────────────────
-- 6. AI SCORES
-- ─────────────────────────────────────────────
create table if not exists public.scores (
  id                   uuid        primary key default gen_random_uuid(),
  submission_id        uuid        not null unique references public.submissions(id) on delete cascade,
  user_id              uuid        not null references auth.users(id) on delete cascade,
  day_number           integer     not null,

  -- Dimension scores (1–5 each)
  clarity              numeric(3,1) check (clarity between 1 and 5),
  structure            numeric(3,1) check (structure between 1 and 5),
  logical_depth        numeric(3,1) check (logical_depth between 1 and 5),
  confidence_projection numeric(3,1) check (confidence_projection between 1 and 5),
  consulting_articulation numeric(3,1) check (consulting_articulation between 1 and 5),
  leadership_signals   numeric(3,1) check (leadership_signals between 1 and 5),

  -- Computed composite (out of 100)
  composite_score      numeric(5,1) generated always as (
    round(
      ((clarity + structure + logical_depth + confidence_projection +
        consulting_articulation + leadership_signals) / 30.0) * 100,
    1)
  ) stored,

  -- Filler analysis
  filler_count         integer     default 0,
  filler_words_found   text[],
  word_economy_score   numeric(3,1) check (word_economy_score between 1 and 5),

  -- Textual feedback
  strengths            text[],
  weaknesses           text[],
  improvement_advice   text,
  model_answer         text,

  -- Meta
  model_used           text        default 'gpt-4o',
  evaluation_tokens    integer,
  evaluated_at         timestamptz default now()
);

-- ─────────────────────────────────────────────
-- 7. USER PROGRESS (aggregated per day)
-- ─────────────────────────────────────────────
create table if not exists public.user_progress (
  id              uuid        primary key default gen_random_uuid(),
  user_id         uuid        not null references auth.users(id) on delete cascade,
  day_number      integer     not null check (day_number between 1 and 30),
  completed       boolean     default false,
  completed_at    timestamptz,
  composite_score numeric(5,1),
  unique (user_id, day_number)
);

-- ─────────────────────────────────────────────
-- 8. WEEKLY REPORTS
-- ─────────────────────────────────────────────
create table if not exists public.weekly_reports (
  id                  uuid        primary key default gen_random_uuid(),
  user_id             uuid        not null references auth.users(id) on delete cascade,
  week_number         integer     not null check (week_number in (1, 2, 3, 4)),  -- after day 7,15,23,30
  trigger_day         integer     not null,               -- 7 | 15 | 23 | 30
  days_covered        int4range   not null,               -- e.g. [1,8)

  -- Aggregate stats
  avg_score           numeric(5,1),
  baseline_score      numeric(5,1),                       -- first submission score
  growth_pct          numeric(5,1),

  -- Category breakdown
  best_category       text,
  weakest_category    text,
  category_scores     jsonb,                              -- {foundation: 76, structure: 84, ...}

  -- Narrative summary (AI-generated)
  summary_text        text,
  top_strength        text,
  focus_area          text,

  generated_at        timestamptz default now(),
  unique (user_id, week_number)
);

-- ─────────────────────────────────────────────
-- 9. RATE LIMITING TABLE
-- ─────────────────────────────────────────────
create table if not exists public.rate_limits (
  id          uuid        primary key default gen_random_uuid(),
  key         text        not null,                       -- e.g. user_id:submit or ip:create-order
  window_start timestamptz not null default now(),
  count       integer     default 1,
  unique (key, window_start)
);

-- ─────────────────────────────────────────────
-- 10. INDEXES
-- ─────────────────────────────────────────────
create index if not exists idx_submissions_user      on public.submissions(user_id);
create index if not exists idx_submissions_day       on public.submissions(day_number);
create index if not exists idx_scores_user           on public.scores(user_id);
create index if not exists idx_scores_day            on public.scores(day_number);
create index if not exists idx_scores_composite      on public.scores(composite_score desc);
create index if not exists idx_user_progress_user    on public.user_progress(user_id);
create index if not exists idx_enrollments_user      on public.enrollments(user_id);
create index if not exists idx_payments_user         on public.payments(user_id);
create index if not exists idx_payments_order        on public.payments(razorpay_order_id);
create index if not exists idx_weekly_reports_user   on public.weekly_reports(user_id);
create index if not exists idx_rate_limits_key       on public.rate_limits(key);

-- ─────────────────────────────────────────────
-- 11. ROW LEVEL SECURITY
-- ─────────────────────────────────────────────
alter table public.profiles            enable row level security;
alter table public.payments            enable row level security;
alter table public.enrollments         enable row level security;
alter table public.submissions         enable row level security;
alter table public.scores              enable row level security;
alter table public.user_progress       enable row level security;
alter table public.weekly_reports      enable row level security;
alter table public.rate_limits         enable row level security;

-- Profiles
create policy "profiles_select_own"  on public.profiles for select using (auth.uid() = id);
create policy "profiles_update_own"  on public.profiles for update using (auth.uid() = id);

-- Payments — users can read their own
create policy "payments_select_own"  on public.payments for select using (auth.uid() = user_id);

-- Enrollments
create policy "enrollments_select_own" on public.enrollments for select using (auth.uid() = user_id);

-- Submissions — full CRUD own rows
create policy "submissions_all_own"  on public.submissions for all using (auth.uid() = user_id);

-- Scores — read only (written by service role)
create policy "scores_select_own"    on public.scores for select using (auth.uid() = user_id);

-- User progress
create policy "progress_all_own"     on public.user_progress for all using (auth.uid() = user_id);

-- Weekly reports
create policy "reports_select_own"   on public.weekly_reports for select using (auth.uid() = user_id);

-- Rate limits — service role only (no user policy needed)

-- ─────────────────────────────────────────────
-- 12. HELPER FUNCTIONS
-- ─────────────────────────────────────────────

-- Generate student ID: MBAC-YYYY-NNNN
create or replace function public.generate_student_id()
returns text
language plpgsql
as $$
declare
  seq_num integer;
  yr      text;
begin
  yr := to_char(now(), 'YYYY');
  select coalesce(max(
    (regexp_match(student_id, 'MBAC-\d{4}-(\d+)'))[1]::integer
  ), 0) + 1
  into seq_num
  from public.profiles;
  return 'MBAC-' || yr || '-' || lpad(seq_num::text, 4, '0');
end;
$$;

-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, email)
  values (
    new.id,
    new.raw_user_meta_data->>'full_name',
    new.email
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Get user's completed days array
create or replace function public.get_completed_days(p_user_id uuid)
returns integer[]
language sql
stable
as $$
  select array_agg(day_number order by day_number)
  from public.user_progress
  where user_id = p_user_id and completed = true;
$$;

-- Get streak count
create or replace function public.get_streak(p_user_id uuid)
returns integer
language plpgsql
stable
as $$
declare
  days     integer[];
  streak   integer := 0;
  i        integer;
  expected integer;
begin
  select array_agg(day_number order by day_number desc)
  into days
  from public.user_progress
  where user_id = p_user_id and completed = true;

  if days is null or array_length(days, 1) = 0 then
    return 0;
  end if;

  expected := days[1];
  for i in 1..array_length(days, 1) loop
    if days[i] = expected then
      streak := streak + 1;
      expected := expected - 1;
    else
      exit;
    end if;
  end loop;
  return streak;
end;
$$;

-- ─────────────────────────────────────────────
-- 13. CLEAN UP OLD RATE LIMIT ROWS (cron-friendly)
-- ─────────────────────────────────────────────
create or replace function public.cleanup_rate_limits()
returns void
language sql
as $$
  delete from public.rate_limits
  where window_start < now() - interval '1 hour';
$$;
