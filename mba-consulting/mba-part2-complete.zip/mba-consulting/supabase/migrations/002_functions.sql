-- ============================================================
-- Migration 002: Rate limit upsert function + admin policies
-- Run AFTER 001_schema.sql
-- ============================================================

-- Atomic upsert for rate limiting
-- Returns the current count (post-increment)
create or replace function public.upsert_rate_limit(
  p_key         text,
  p_window_start timestamptz,
  p_max         integer
)
returns integer
language plpgsql
security definer
as $$
declare
  current_count integer;
begin
  insert into public.rate_limits (key, window_start, count)
  values (p_key, p_window_start, 1)
  on conflict (key, window_start)
  do update set count = rate_limits.count + 1
  returning count into current_count;

  return current_count;
end;
$$;

-- Allow service role to bypass RLS on rate_limits
create policy "rate_limits_service_only"
  on public.rate_limits
  for all
  using (true)
  with check (true);

-- ─────────────────────────────────────────────
-- Service role policies for API writes
-- (Scores and submissions written by service role from API routes)
-- ─────────────────────────────────────────────

-- Allow service role to insert/update scores
create policy "scores_service_insert"
  on public.scores
  for insert
  with check (true);

create policy "scores_service_update"
  on public.scores
  for update
  using (true);

-- Allow service role to manage weekly reports
create policy "reports_service_insert"
  on public.weekly_reports
  for insert
  with check (true);

create policy "reports_service_update"
  on public.weekly_reports
  for update
  using (true);

-- Allow service role to manage payments and enrollments
create policy "payments_service_all"
  on public.payments
  for all
  using (true)
  with check (true);

create policy "enrollments_service_all"
  on public.enrollments
  for all
  using (true)
  with check (true);

-- Allow service role to manage profiles
create policy "profiles_service_all"
  on public.profiles
  for all
  using (true)
  with check (true);
