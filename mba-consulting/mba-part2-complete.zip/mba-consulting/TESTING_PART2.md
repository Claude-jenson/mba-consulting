# Part 2 Testing Guide

## Setup

```bash
# 1. Install new dependency
npm install openai

# 2. Add all env vars to .env.local
cp .env.local.example .env.local
# Fill in: OPENAI_API_KEY, RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET,
#          NEXT_PUBLIC_RAZORPAY_KEY_ID, RAZORPAY_WEBHOOK_SECRET,
#          SUPABASE_SERVICE_ROLE_KEY

# 3. Run migrations in Supabase SQL Editor
# → Paste supabase/migrations/001_schema.sql → Run
# → Paste supabase/migrations/002_functions.sql → Run

# 4. Start dev server
npm run dev
```

---

## 1. Test Database Schema

In Supabase Dashboard → Table Editor, verify these tables exist:
- `profiles`
- `payments`
- `enrollments`
- `submissions`
- `scores`
- `user_progress`
- `weekly_reports`
- `rate_limits`

---

## 2. Test Payment Flow (Razorpay Test Mode)

Use test credentials from [Razorpay Dashboard → Test Mode]

```bash
# Step 1: Register a new account at /auth/register
# Step 2: You'll be redirected to /pay (paywall)
# Step 3: Click "Get Access — ₹199"
# Step 4: In Razorpay modal, use test card:
#   Card: 4111 1111 1111 1111
#   Expiry: 12/25
#   CVV: 123
#   Name: Test User
# Step 5: After payment, should redirect to /dashboard
```

### Test the create-order API directly:
```bash
curl -X POST http://localhost:3000/api/payment/create-order \
  -H "Content-Type: application/json" \
  -H "Cookie: <your-auth-cookie>"
# Should return: { orderId, amount, currency, keyId, prefill }
```

---

## 3. Test Webhook Locally (Razorpay + ngrok)

```bash
# Install ngrok
npm install -g ngrok

# Expose local server
ngrok http 3000

# Copy the https URL, e.g.: https://abc123.ngrok.io

# In Razorpay Dashboard → Settings → Webhooks → Add webhook
# URL: https://abc123.ngrok.io/api/payment/verify-webhook
# Events: payment.captured, payment.failed, refund.created
# Secret: set as RAZORPAY_WEBHOOK_SECRET in .env.local
```

---

## 4. Test AI Evaluation

```bash
# Step 1: Login as an enrolled user
# Step 2: Go to /dashboard/day/1
# Step 3: Click Practice tab
# Step 4: Write 100+ word response
# Step 5: Click "Submit for AI Evaluation"
# Should see: Score ring, dimension bars, strengths, weaknesses, advice, model answer

# Direct API test:
curl -X POST http://localhost:3000/api/submissions \
  -H "Content-Type: application/json" \
  -H "Cookie: <auth-cookie>" \
  -d '{
    "dayNumber": 1,
    "content": "The consulting voice starts with clarity — leading with the point before justification. In this GD about startup profitability, my position is clear: profitability is the only sustainable moat. Growth without it is renting market share at someone else's expense. Three reasons support this. First, in India's funding winter, capital efficiency separates survivors from casualties. Second, Zomato and Nykaa's recent path to profitability shows this is achievable without sacrificing market position. Third, boards and investors have fundamentally shifted — they are no longer rewarding growth-at-all-costs. The strategic imperative is simple: profitability discipline is now a competitive advantage, not a constraint."
  }'
```

Expected response:
```json
{
  "success": true,
  "submissionId": "...",
  "evaluation": {
    "compositeScore": 78.5,
    "dimensions": {
      "clarity": 4.2,
      "structure": 3.8,
      ...
    },
    "strengths": [...],
    "weaknesses": [...],
    "improvementAdvice": "...",
    "modelAnswer": "..."
  }
}
```

---

## 5. Test Rate Limiting

```bash
# Submit 11 times in 1 hour as the same user
# On the 11th attempt, should receive:
# HTTP 429 with { error: "Rate limit exceeded", retryAfter: "..." }
```

---

## 6. Test Weekly Report Generation

```bash
# After completing 7 days (or mock it in DB):
curl -X POST http://localhost:3000/api/weekly-report \
  -H "Content-Type: application/json" \
  -H "Cookie: <auth-cookie>" \
  -d '{"weekNumber": 1}'

# Should return the generated narrative + category breakdown
```

---

## 7. Test Enrollment Check

```bash
# Not enrolled user:
curl http://localhost:3000/api/enrollment -H "Cookie: <auth-cookie>"
# Returns: { enrolled: false, reason: "not_purchased" }

# Enrolled user:
# Returns: { enrolled: true, enrolledAt: "...", studentId: "MBAC-2024-0001" }
```

---

## 8. Verify Supabase Data

After a successful submission, check Supabase Dashboard:
1. `submissions` table → should have your row with content
2. `scores` table → should have all 6 dimension scores + composite
3. `user_progress` table → day marked as completed
4. Check that `composite_score` is auto-generated (not null)

---

## Common Issues

| Issue | Fix |
|-------|-----|
| "Razorpay credentials not configured" | Check RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET in .env.local |
| "OpenAI returned empty response" | Check OPENAI_API_KEY is valid and has credits |
| "Payment record creation failed" | Run 001_schema.sql migration first |
| "Rate limit exceeded" | Wait 1 hour or delete row from rate_limits table in Supabase |
| Webhook signature invalid | Ensure RAZORPAY_WEBHOOK_SECRET matches exactly what's in Razorpay Dashboard |
| User shows enrolled: false after payment | Webhook may be slow — check payments table for status="paid" |
