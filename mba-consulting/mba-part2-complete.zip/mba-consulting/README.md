# MBA Communication Dominance — Part 1 Setup Guide

## Project Structure

```
mba-consulting/
├── src/
│   ├── app/
│   │   ├── layout.tsx                    # Root layout
│   │   ├── page.tsx                      # Landing page
│   │   ├── auth/
│   │   │   ├── login/page.tsx            # Login
│   │   │   ├── register/page.tsx         # Registration
│   │   │   └── callback/route.ts         # OAuth callback
│   │   └── dashboard/
│   │       ├── layout.tsx                # Dashboard shell + sidebar
│   │       ├── page.tsx                  # Main dashboard
│   │       ├── day/[id]/page.tsx         # Day module viewer
│   │       ├── modules/page.tsx          # All modules browser
│   │       ├── performance/page.tsx      # Analytics
│   │       ├── certificate/page.tsx      # Certificate tracker
│   │       └── settings/page.tsx         # Account settings
│   ├── components/
│   │   └── ui/
│   │       ├── Button.tsx
│   │       ├── Card.tsx
│   │       ├── Badge.tsx
│   │       └── ProgressBar.tsx
│   ├── data/
│   │   └── course-modules.ts             # 30-day curriculum data
│   ├── lib/
│   │   ├── utils.ts                      # Helper functions
│   │   └── supabase/
│   │       ├── client.ts                 # Browser Supabase client
│   │       ├── server.ts                 # Server Supabase client
│   │       └── middleware.ts             # Route protection
│   ├── middleware.ts                     # Next.js middleware
│   ├── styles/globals.css               # Global styles + CSS vars
│   └── types/index.ts                   # TypeScript interfaces
├── package.json
├── tailwind.config.ts
├── tsconfig.json
├── next.config.js
└── .env.local.example
```

---

## Local Development

### 1. Prerequisites

```bash
node --version    # >= 18.0
npm --version     # >= 8.0
```

### 2. Install dependencies

```bash
cd mba-consulting
npm install
```

### 3. Set up environment variables

```bash
cp .env.local.example .env.local
```

Edit `.env.local`:
```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

### 4. Run dev server

```bash
npm run dev
```

Open http://localhost:3000

---

## Supabase Setup

### Step 1: Create project

1. Go to https://supabase.com
2. Create new project
3. Copy **Project URL** and **anon/public key** into `.env.local`

### Step 2: Enable Google OAuth (optional)

1. In Supabase dashboard → Authentication → Providers
2. Enable Google
3. Create OAuth credentials at https://console.cloud.google.com
4. Add redirect URL: `https://your-project.supabase.co/auth/v1/callback`

### Step 3: Create tables (run in Supabase SQL Editor)

```sql
-- User profiles
create table public.profiles (
  id uuid references auth.users on delete cascade primary key,
  full_name text,
  college text,
  created_at timestamp with time zone default now(),
  has_paid boolean default false
);

-- User progress per day
create table public.user_progress (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users on delete cascade not null,
  day_number integer not null check (day_number between 1 and 30),
  completed boolean default false,
  score integer,
  feedback text,
  submitted_at timestamp with time zone,
  unique(user_id, day_number)
);

-- Submissions store
create table public.submissions (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users on delete cascade not null,
  day_number integer not null,
  content text not null,
  score integer,
  feedback text,
  submitted_at timestamp with time zone default now()
);

-- RLS Policies
alter table public.profiles enable row level security;
alter table public.user_progress enable row level security;
alter table public.submissions enable row level security;

create policy "Users see own profile" on profiles for select using (auth.uid() = id);
create policy "Users update own profile" on profiles for update using (auth.uid() = id);
create policy "Users see own progress" on user_progress for all using (auth.uid() = user_id);
create policy "Users see own submissions" on submissions for all using (auth.uid() = user_id);

-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, new.raw_user_meta_data->>'full_name');
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
```

---

## Deploy to Netlify

### Method 1: Netlify CLI

```bash
npm install -g netlify-cli
netlify login
netlify init
netlify env:set NEXT_PUBLIC_SUPABASE_URL "your-url"
netlify env:set NEXT_PUBLIC_SUPABASE_ANON_KEY "your-key"
netlify deploy --prod
```

### Method 2: Git + Netlify UI

1. Push to GitHub
2. Go to https://app.netlify.com → New site from Git
3. Select your repo
4. Build settings:
   - **Build command:** `npm run build`
   - **Publish directory:** `.next`
5. Add environment variables in Site Settings → Environment Variables
6. Add `netlify.toml` to root:

```toml
[build]
  command = "npm run build"
  publish = ".next"

[[plugins]]
  package = "@netlify/plugin-nextjs"
```

Install the Netlify Next.js plugin:
```bash
npm install @netlify/plugin-nextjs
```

### Update Supabase for production

In Supabase dashboard → Authentication → URL Configuration:
- **Site URL:** `https://your-site.netlify.app`
- **Redirect URLs:** `https://your-site.netlify.app/auth/callback`

---

## What's in Part 1

✅ Next.js 14 App Router + TypeScript  
✅ Tailwind CSS with premium dark gold design system  
✅ Global CSS with design tokens, card styles, animations  
✅ Supabase auth (email/password + Google OAuth)  
✅ Route protection middleware  
✅ Conversion-optimized landing page (8 sections)  
✅ Login + Register pages with form validation  
✅ Dashboard with sidebar, stats, 30-day grid  
✅ Day module viewer with Learn + Practice tabs  
✅ Course module browser (all 30 days)  
✅ Performance analytics with Recharts  
✅ Certificate tracker with requirements  
✅ Settings page  
✅ 4 reusable UI components (Button, Card, Badge, ProgressBar)  
✅ Full TypeScript types  
✅ 10 fully fleshed Day modules with real frameworks  

## What comes in Part 2

⬜ OpenAI GPT-4 evaluation on submissions  
⬜ Real Supabase data persistence (progress, scores)  
⬜ Razorpay payment gate (₹199)  
⬜ Payment verification + access unlock logic  
⬜ Score history + feedback storage  
⬜ Streak calculation from real data  

## What comes in Part 3

⬜ PDF certificate generation  
⬜ Admin panel (manage users, view submissions, override scores)  
⬜ Production deployment config  
⬜ Performance optimization  
