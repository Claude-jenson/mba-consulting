"use client";

import { motion } from "framer-motion";
import { Check, ArrowRight, Shield, Zap } from "lucide-react";
import { PaymentButton } from "@/components/ui/PaymentButton";

export default function PaywallPage() {
  return (
    <div className="min-h-screen bg-[#0a0f1e] bg-grid flex items-center justify-center px-4 py-10">
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 70% 50% at 50% 0%, rgba(201,162,39,0.07), transparent)",
        }}
      />

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-xl relative z-10"
      >
        <div className="text-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-gold-500 to-gold-700 flex items-center justify-center shadow-gold mx-auto mb-5">
            <span className="text-slate-900 font-black text-xl">M</span>
          </div>
          <h1
            className="text-3xl font-bold text-slate-100 mb-2"
            style={{ fontFamily: "var(--font-display)" }}
          >
            One payment. 30 days. <br />
            <span className="text-gold-gradient">Lifetime access.</span>
          </h1>
          <p className="text-slate-400 text-sm">
            Your account is created. Complete payment to unlock all 30 modules.
          </p>
        </div>

        <div className="card-premium card-accent glow-gold p-8">
          {/* Price */}
          <div className="text-center mb-6">
            <div className="flex items-baseline justify-center gap-2 mb-1">
              <span className="text-slate-500 line-through text-xl">₹1,999</span>
              <span className="text-5xl font-black text-gold-gradient">₹199</span>
            </div>
            <p className="text-slate-500 text-sm">One-time · No subscription · Lifetime access</p>
          </div>

          {/* Features */}
          <ul className="space-y-2.5 mb-7">
            {[
              "30 structured daily modules (25–45 min each)",
              "AI evaluation on every submission (GPT-4o)",
              "6-dimension scoring: Clarity, Structure, Confidence + more",
              "Filler word detection + vocabulary coaching",
              "Model answers from a McKinsey-calibrated evaluator",
              "Weekly progress reports + growth analytics",
              "Verified completion certificate (after Day 30)",
              "All future module updates included",
            ].map((item, i) => (
              <li key={i} className="flex items-start gap-3 text-slate-300 text-sm">
                <div className="w-5 h-5 rounded-full bg-gold-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Check className="w-3 h-3 text-gold-400" />
                </div>
                {item}
              </li>
            ))}
          </ul>

          {/* Payment button */}
          <PaymentButton size="xl" className="w-full" />

          {/* Trust signals */}
          <div className="flex items-center justify-center gap-5 mt-5 text-xs text-slate-500">
            <div className="flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5" />
              Secure payment
            </div>
            <div className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5" />
              Instant access
            </div>
            <div className="flex items-center gap-1.5">
              <ArrowRight className="w-3.5 h-3.5" />
              Start immediately
            </div>
          </div>
        </div>

        <p className="text-center text-slate-600 text-xs mt-4">
          Payments processed by Razorpay · UPI, cards, net banking, wallets accepted
        </p>
      </motion.div>
    </div>
  );
}
