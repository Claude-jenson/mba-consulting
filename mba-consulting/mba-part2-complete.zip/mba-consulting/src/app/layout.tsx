import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "@/styles/globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  title: "MBA Communication Dominance — 30-Day Consulting Transformation",
  description:
    "Master Group Discussion, Personal Interview & executive communication in 30 days. Built for Tier 2–3 MBA students targeting consulting and finance roles.",
  keywords: [
    "MBA Communication",
    "Group Discussion",
    "Personal Interview",
    "Consulting",
    "MBA India",
    "CAT",
    "IIM",
  ],
  openGraph: {
    title: "MBA Communication Dominance",
    description: "30-Day consulting communication transformation for Indian MBA students",
    type: "website",
    locale: "en_IN",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={inter.variable}>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;1,9..40,400&family=JetBrains+Mono:wght@400;500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-[#0a0f1e] text-slate-100 antialiased">
        {children}
      </body>
    </html>
  );
}
