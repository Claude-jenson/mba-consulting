"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import {
  Flame,
  Trophy,
  TrendingUp,
  Clock,
  Lock,
  CheckCircle2,
  Circle,
  ArrowRight,
  Star,
  Zap,
} from "lucide-react";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { Badge } from "@/components/ui/Badge";
import { Card, CardHeader, CardContent } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { getDayStatus, getCategoryColor } from "@/lib/utils";
import { categoryConfig } from "@/data/course-modules";

// Mock data — replaced with real Supabase data in Part 2
const mockProgress = {
  completedDays: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
  currentDay: 11,
  streak: 7,
  averageScore: 87,
  totalSubmissions: 10,
};

const categoryColors: Record<string, string> = {
  foundation: "#3b82f6",
  structure: "#8b5cf6",
  influence: "#f59e0b",
  executive: "#10b981",
  mastery: "#c9a227",
};

function getDayCategory(day: number): string {
  if (day <= 6) return "foundation";
  if (day <= 12) return "structure";
  if (day <= 18) return "influence";
  if (day <= 24) return "executive";
  return "mastery";
}

export default function DashboardPage() {
  const { completedDays, currentDay, streak, averageScore } = mockProgress;
  const progressPct = Math.round((completedDays.length / 30) * 100);

  const statsData = [
    {
      icon: <Flame className="w-5 h-5 text-orange-400" />,
      label: "Day Streak",
      value: streak,
      suffix: "days",
      color: "text-orange-400",
    },
    {
      icon: <Star className="w-5 h-5 text-gold-400" />,
      label: "Avg. Score",
      value: averageScore,
      suffix: "/100",
      color: "text-gold-400",
    },
    {
      icon: <Trophy className="w-5 h-5 text-emerald-400" />,
      label: "Days Done",
      value: completedDays.length,
      suffix: "/30",
      color: "text-emerald-400",
    },
    {
      icon: <TrendingUp className="w-5 h-5 text-blue-400" />,
      label: "Progress",
      value: progressPct,
      suffix: "%",
      color: "text-blue-400",
    },
  ];

  return (
    <div className="p-4 md:p-8 max-w-6xl mx-auto">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-slate-100"
              style={{ fontFamily: "var(--font-display)" }}>
              Good morning, Priyanka
            </h1>
            <p className="text-slate-400 mt-1">
              Day {currentDay} is ready. Keep the streak alive.
            </p>
          </div>
          <Badge variant="gold" className="hidden sm:flex items-center gap-1.5">
            <Flame className="w-3 h-3 text-orange-400" />
            {streak}-day streak
          </Badge>
        </div>
      </motion.div>

      {/* Stats row */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8"
      >
        {statsData.map((stat, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 + i * 0.07 }}
            className="card-premium p-5"
          >
            <div className="flex items-center gap-2 mb-2">
              {stat.icon}
              <span className="text-xs text-slate-500">{stat.label}</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className={`text-2xl font-black ${stat.color}`}>
                {stat.value}
              </span>
              <span className="text-sm text-slate-500">{stat.suffix}</span>
            </div>
          </motion.div>
        ))}
      </motion.div>

      <div className="grid lg:grid-cols-3 gap-6 mb-8">
        {/* Current day CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="lg:col-span-2"
        >
          <div className="card-premium card-accent glow-gold p-6 relative overflow-hidden">
            <div
              className="absolute right-0 top-0 w-48 h-48 pointer-events-none opacity-5"
              style={{
                background:
                  "radial-gradient(circle, #c9a227, transparent 70%)",
              }}
            />
            <div className="flex items-start justify-between mb-4">
              <div>
                <Badge variant="current" className="mb-2">
                  <Zap className="w-3 h-3 mr-1" />
                  Today&apos;s Module
                </Badge>
                <h2 className="text-xl font-bold text-slate-100" style={{ fontFamily: "var(--font-display)" }}>
                  Day {currentDay}: Issue Tree Thinking
                </h2>
                <p className="text-slate-400 text-sm mt-1">
                  Structure ambiguity — decompose any problem into exhaustive, mutually exclusive branches
                </p>
              </div>
              <div className="text-4xl font-black text-gold-500/20 ml-4">
                {currentDay}
              </div>
            </div>

            <div className="flex items-center gap-4 mb-5 text-sm text-slate-400">
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" />
                40 minutes
              </div>
              <div className="flex items-center gap-1.5">
                <div
                  className="w-2 h-2 rounded-full"
                  style={{ background: categoryColors[getDayCategory(currentDay)] }}
                />
                {categoryConfig[getDayCategory(currentDay) as keyof typeof categoryConfig]?.label}
              </div>
            </div>

            <Link href={`/dashboard/day/${currentDay}`}>
              <Button variant="gold" size="lg" className="group">
                Start Day {currentDay}
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </div>
        </motion.div>

        {/* Overall progress */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
        >
          <Card className="p-6 h-full">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-slate-200 text-sm">
                Overall Progress
              </h3>
              <span className="text-gold-400 font-bold text-sm">
                {progressPct}%
              </span>
            </div>
            <ProgressBar
              value={progressPct}
              showLabel={false}
              size="lg"
              className="mb-4"
            />
            <div className="text-sm text-slate-400 mb-6">
              <span className="text-slate-200 font-semibold">
                {completedDays.length} of 30
              </span>{" "}
              days completed
            </div>

            {/* Category breakdown */}
            <div className="space-y-3">
              {Object.entries(categoryConfig).map(([key, config]) => {
                const categoryDays = Array.from({ length: 30 }, (_, i) => i + 1).filter(
                  (d) => getDayCategory(d) === key
                );
                const done = categoryDays.filter((d) =>
                  completedDays.includes(d)
                ).length;
                const pct = Math.round((done / categoryDays.length) * 100);

                return (
                  <div key={key}>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-500">{config.label}</span>
                      <span style={{ color: config.color }} className="font-medium">
                        {done}/{categoryDays.length}
                      </span>
                    </div>
                    <div className="h-1 rounded-full bg-slate-800">
                      <div
                        className="h-1 rounded-full transition-all duration-1000"
                        style={{
                          width: `${pct}%`,
                          background: config.color,
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </motion.div>
      </div>

      {/* 30-Day Grid */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="card-premium p-6 mb-6"
      >
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-semibold text-slate-200">30-Day Progress Grid</h3>
          <div className="flex items-center gap-4 text-xs text-slate-500">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Done
            </span>
            <span className="flex items-center gap-1.5">
              <Zap className="w-3 h-3 text-gold-400" /> Today
            </span>
            <span className="flex items-center gap-1.5">
              <Lock className="w-3 h-3 text-slate-600" /> Locked
            </span>
          </div>
        </div>

        <div className="grid grid-cols-10 sm:grid-cols-15 gap-2" style={{ gridTemplateColumns: "repeat(10, minmax(0, 1fr))" }}>
          {Array.from({ length: 30 }, (_, i) => {
            const day = i + 1;
            const status = getDayStatus(day, completedDays, currentDay);
            const category = getDayCategory(day);
            const color = categoryColors[category];

            return (
              <Link
                key={day}
                href={
                  status === "locked"
                    ? "#"
                    : `/dashboard/day/${day}`
                }
                className={`
                  day-cell relative
                  ${status === "locked" ? "pointer-events-none" : ""}
                `}
                style={{
                  background:
                    status === "completed"
                      ? `${color}25`
                      : status === "current"
                      ? `${color}20`
                      : status === "available"
                      ? `${color}10`
                      : "rgba(30, 41, 59, 0.4)",
                  border: `1px solid ${
                    status === "completed"
                      ? `${color}50`
                      : status === "current"
                      ? `${color}60`
                      : status === "available"
                      ? `${color}25`
                      : "rgba(51, 65, 85, 0.3)"
                  }`,
                  boxShadow:
                    status === "current"
                      ? `0 0 12px ${color}30`
                      : undefined,
                }}
              >
                {status === "completed" ? (
                  <CheckCircle2
                    className="w-4 h-4"
                    style={{ color }}
                  />
                ) : status === "current" ? (
                  <span
                    className="text-xs font-bold"
                    style={{ color }}
                  >
                    {day}
                  </span>
                ) : status === "locked" ? (
                  <Lock className="w-3 h-3 text-slate-600" />
                ) : (
                  <span className="text-xs font-medium text-slate-500">
                    {day}
                  </span>
                )}

                {status === "current" && (
                  <span
                    className="absolute inset-0 rounded-lg animate-ping opacity-20"
                    style={{ background: color }}
                  />
                )}
              </Link>
            );
          })}
        </div>

        {/* Legend */}
        <div className="flex flex-wrap gap-3 mt-5 pt-4 border-t border-gold-500/10">
          {Object.entries(categoryConfig).map(([key, config]) => (
            <div key={key} className="flex items-center gap-1.5 text-xs text-slate-500">
              <div
                className="w-2.5 h-2.5 rounded-sm"
                style={{ background: config.color + "60" }}
              />
              {config.label} (Days {config.days})
            </div>
          ))}
        </div>
      </motion.div>

      {/* Recent activity */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.35 }}
        className="card-premium p-6"
      >
        <h3 className="font-semibold text-slate-200 mb-4">Recent Activity</h3>
        <div className="space-y-3">
          {[
            { day: 10, title: "Executive Presence: P.A.C.E. Model", score: 91, time: "2h ago" },
            { day: 9, title: "Issue Tree Thinking", score: 88, time: "Yesterday" },
            { day: 8, title: "Influence Without Authority", score: 85, time: "2 days ago" },
          ].map((item, i) => (
            <div
              key={i}
              className="flex items-center justify-between py-3 border-b border-slate-800/50 last:border-0"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-gold-500/10 border border-gold-500/20 flex items-center justify-center text-xs font-bold text-gold-400">
                  {item.day}
                </div>
                <div>
                  <div className="text-sm text-slate-200 font-medium">
                    {item.title}
                  </div>
                  <div className="text-xs text-slate-500">{item.time}</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span
                  className={`text-sm font-bold ${
                    item.score >= 90
                      ? "text-emerald-400"
                      : item.score >= 75
                      ? "text-gold-400"
                      : "text-blue-400"
                  }`}
                >
                  {item.score}
                </span>
                <span className="text-xs text-slate-600">/100</span>
              </div>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
