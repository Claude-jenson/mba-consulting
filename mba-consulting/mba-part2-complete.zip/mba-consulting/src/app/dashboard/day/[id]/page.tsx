"use client";

import { useState, use } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  Clock,
  Target,
  BookOpen,
  Lightbulb,
  MessageSquare,
  Send,
  Lock,
  ChevronRight,
  Loader2,
  AlertCircle,
} from "lucide-react";
import { courseModules, categoryConfig } from "@/data/course-modules";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { EvaluationCard } from "@/components/course/EvaluationCard";
import { useSubmission } from "@/lib/hooks/use-submission";
import { getCategoryColor } from "@/lib/utils";

interface PageProps {
  params: Promise<{ id: string }>;
}

export default function DayPage({ params }: PageProps) {
  const { id } = use(params);
  const dayNumber = parseInt(id);
  const [submissionText, setSubmissionText] = useState("");
  const [activeTab, setActiveTab] = useState<"learn" | "practice">("learn");

  const completedDays = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  const currentDay = 11;
  const isCompleted = completedDays.includes(dayNumber);
  const isCurrent = dayNumber === currentDay;
  const isLocked = dayNumber > currentDay && !completedDays.includes(dayNumber);

  const { submit, status, evaluation, nextDay, error, reset } =
    useSubmission(dayNumber);

  const module = courseModules.find((m) => m.day_number === dayNumber);
  const categoryColor = module ? getCategoryColor(module.category) : "#c9a227";
  const categoryLabel =
    module?.category &&
    categoryConfig[module.category as keyof typeof categoryConfig]?.label;

  const wordCount = submissionText.trim().split(/\s+/).filter(Boolean).length;

  if (!module) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-slate-400">Module not found</p>
          <Link href="/dashboard" className="text-gold-400 hover:underline mt-4 block">← Dashboard</Link>
        </div>
      </div>
    );
  }

  if (isLocked) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="max-w-md w-full text-center">
          <div className="card-premium p-10">
            <div className="w-16 h-16 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center mx-auto mb-6">
              <Lock className="w-8 h-8 text-slate-500" />
            </div>
            <div className="text-4xl font-black text-slate-700 mb-2">Day {dayNumber}</div>
            <h2 className="text-xl font-bold text-slate-300 mb-2">{module.title}</h2>
            <p className="text-slate-500 text-sm mb-6">Complete Day {currentDay} first to unlock this module.</p>
            <Link href={`/dashboard/day/${currentDay}`}>
              <Button variant="gold" className="w-full">Go to Day {currentDay} <ArrowRight className="w-4 h-4" /></Button>
            </Link>
          </div>
        </motion.div>
      </div>
    );
  }

  const tabs = [
    { id: "learn", label: "Learn", icon: BookOpen },
    { id: "practice", label: "Practice", icon: MessageSquare },
  ];

  return (
    <div className="min-h-screen p-4 md:p-8 max-w-4xl mx-auto">
      {/* Nav */}
      <div className="flex items-center gap-2 mb-6 text-slate-400 text-sm">
        <Link href="/dashboard" className="hover:text-slate-200 flex items-center gap-1.5 transition-colors">
          <ArrowLeft className="w-4 h-4" /> Dashboard
        </Link>
        <ChevronRight className="w-3 h-3 text-slate-600" />
        <span>Day {dayNumber}</span>
      </div>

      {/* Header */}
      <div className="mb-7">
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <div className="px-3 py-1 rounded-full text-xs font-bold" style={{ background: `${categoryColor}15`, color: categoryColor, border: `1px solid ${categoryColor}30` }}>
            Day {dayNumber}
          </div>
          {categoryLabel && <Badge variant="gold" size="sm">{categoryLabel}</Badge>}
          <span className="text-xs text-slate-500 flex items-center gap-1"><Clock className="w-3 h-3" /> {module.duration_minutes} min</span>
          {isCurrent && <Badge variant="current" size="sm">Today</Badge>}
          {isCompleted && <Badge variant="completed" size="sm">✓ Done</Badge>}
        </div>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-100" style={{ fontFamily: "var(--font-display)" }}>{module.title}</h1>
        <p className="text-slate-400 mt-2 text-sm leading-relaxed">{module.objective}</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-slate-900/50 rounded-xl border border-slate-800/50 mb-6 w-fit">
        {tabs.map((tab) => (
          <button key={tab.id} onClick={() => { setActiveTab(tab.id as "learn" | "practice"); if (tab.id === "practice") reset(); }}
            className={`flex items-center gap-2 px-5 py-2 rounded-lg text-sm font-medium transition-all ${activeTab === tab.id ? "bg-gold-500/15 text-gold-300 border border-gold-500/20" : "text-slate-500 hover:text-slate-300"}`}>
            <tab.icon className="w-3.5 h-3.5" />{tab.label}
          </button>
        ))}
      </div>

      {/* LEARN TAB */}
      {activeTab === "learn" && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
          <div className="card-premium card-accent p-6">
            <div className="flex items-center gap-2 mb-3"><Target className="w-4 h-4 text-gold-400" /><span className="text-xs font-semibold text-gold-400 uppercase tracking-wider">Objective</span></div>
            <p className="text-slate-200 leading-relaxed">{module.objective}</p>
          </div>
          <div className="card-premium p-6">
            <div className="flex items-center gap-2 mb-4"><Lightbulb className="w-4 h-4 text-gold-400" /><span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">The Framework</span></div>
            <div className="inline-flex px-3 py-1.5 rounded-lg mb-3 text-sm font-bold" style={{ background: `${categoryColor}12`, color: categoryColor, border: `1px solid ${categoryColor}25` }}>{module.framework.name}</div>
            <p className="text-slate-400 text-sm mb-4">{module.framework.description}</p>
            <div className="space-y-3">
              {module.framework.steps.map((step, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-md flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5" style={{ background: `${categoryColor}15`, color: categoryColor }}>{i + 1}</div>
                  <p className="text-slate-300 text-sm pt-0.5 leading-relaxed">{step}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="card-premium p-6">
            <div className="flex items-center gap-2 mb-4"><BookOpen className="w-4 h-4 text-gold-400" /><span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Worked Example</span></div>
            <div className="space-y-3">
              <div><span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider">Scenario</span><p className="text-slate-300 text-sm mt-1">{module.example.scenario}</p></div>
              <div><span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider">Application</span><p className="text-slate-300 text-sm mt-1">{module.example.application}</p></div>
              <div className="p-4 rounded-xl bg-gold-500/5 border border-gold-500/15">
                <span className="text-[10px] font-semibold text-gold-500/60 uppercase tracking-wider block mb-2">Model Output</span>
                <p className="text-slate-200 text-sm leading-relaxed font-mono">{module.example.output}</p>
              </div>
            </div>
          </div>
          <Button variant="gold" size="lg" className="w-full group" onClick={() => setActiveTab("practice")}>
            Ready to Practice? <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Button>
        </motion.div>
      )}

      {/* PRACTICE TAB */}
      {activeTab === "practice" && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
          {status === "success" && evaluation ? (
            <EvaluationCard evaluation={evaluation} dayNumber={dayNumber} nextDay={nextDay} />
          ) : (
            <>
              <div className="card-premium card-accent p-6">
                <div className="flex items-center gap-2 mb-3"><MessageSquare className="w-4 h-4 text-gold-400" /><span className="text-xs font-semibold text-gold-400 uppercase tracking-wider">GD / PI Simulation Prompt</span></div>
                <p className="text-slate-200 text-sm md:text-base leading-relaxed">{module.gd_prompt}</p>
              </div>

              {status === "error" && error && (
                <div className="flex items-start gap-3 p-4 rounded-xl bg-red-900/20 border border-red-800/30">
                  <AlertCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-red-400 text-sm font-medium">Submission Failed</p>
                    <p className="text-red-400/70 text-xs mt-0.5">{error}</p>
                    <button onClick={reset} className="text-xs text-gold-400 hover:underline mt-1">Try again</button>
                  </div>
                </div>
              )}

              <div className="card-premium p-6">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold text-slate-200">Your Response</h3>
                  <span className={`text-xs ${wordCount >= 150 ? "text-emerald-400" : wordCount >= 50 ? "text-amber-400" : "text-slate-500"}`}>
                    {wordCount} words {wordCount >= 150 ? "✓" : wordCount >= 50 ? "(aim for 150+)" : "(min. 50)"}
                  </span>
                </div>
                <p className="text-slate-500 text-xs mb-3">Apply <span className="text-gold-400 font-medium">{module.framework.name}</span>. Write as if speaking in the room. 150–300 words.</p>
                <textarea
                  value={submissionText}
                  onChange={(e) => setSubmissionText(e.target.value)}
                  placeholder={`Apply ${module.framework.name}. Lead with your point. No filler. No hedging...`}
                  className="input-premium h-52 resize-none text-sm font-mono leading-relaxed mb-4"
                  disabled={status === "submitting"}
                />
                <div className="flex items-center justify-between gap-4 flex-wrap">
                  <div className="text-xs text-slate-600">AI evaluates: Clarity · Structure · Confidence · Consulting Voice · Leadership</div>
                  <Button
                    variant="gold"
                    onClick={() => submit(submissionText)}
                    disabled={wordCount < 50 || status === "submitting"}
                    icon={status === "submitting" ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                    iconPosition="right"
                  >
                    {status === "submitting" ? "Evaluating..." : "Submit for AI Evaluation"}
                  </Button>
                </div>
              </div>
            </>
          )}
        </motion.div>
      )}

      {/* Day nav */}
      <div className="flex items-center justify-between mt-10 pt-6 border-t border-gold-500/10">
        {dayNumber > 1 ? (
          <Link href={`/dashboard/day/${dayNumber - 1}`}><Button variant="ghost" size="sm" icon={<ArrowLeft className="w-3.5 h-3.5" />}>Day {dayNumber - 1}</Button></Link>
        ) : <div />}
        {dayNumber < 30 && (
          <Link href={`/dashboard/day/${dayNumber + 1}`}><Button variant="ghost" size="sm" icon={<ArrowRight className="w-3.5 h-3.5" />} iconPosition="right">Day {dayNumber + 1}</Button></Link>
        )}
      </div>
    </div>
  );
}
