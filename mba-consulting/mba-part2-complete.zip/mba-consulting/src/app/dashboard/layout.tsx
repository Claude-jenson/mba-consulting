"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard, BookOpen, BarChart2, Award,
  Settings, LogOut, Menu, Flame, ChevronRight,
} from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { EnrollmentGuard } from "@/components/layout/EnrollmentGuard";
import { cn } from "@/lib/utils";

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard",   href: "/dashboard" },
  { icon: BookOpen,        label: "Day Modules", href: "/dashboard/modules" },
  { icon: BarChart2,       label: "Performance", href: "/dashboard/performance" },
  { icon: Award,           label: "Certificate", href: "/dashboard/certificate" },
  { icon: Settings,        label: "Settings",    href: "/dashboard/settings" },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router   = useRouter();
  const supabase = createClient();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [user, setUser]   = useState<{ name: string; email: string } | null>(null);
  const [streak, setStreak] = useState(0);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) {
        setUser({ name: data.user.user_metadata?.full_name || data.user.email?.split("@")[0] || "Student", email: data.user.email || "" });
      }
    });
    fetch("/api/progress").then(r => r.ok ? r.json() : null).then(d => d?.streak && setStreak(d.streak)).catch(() => {});
  }, []);

  const handleLogout = async () => { await supabase.auth.signOut(); router.push("/"); };

  const Sidebar = ({ mobile = false }: { mobile?: boolean }) => (
    <aside className={cn("flex flex-col h-full", mobile ? "w-72" : "w-64 border-r border-gold-500/10")} style={{ background: "linear-gradient(180deg, #0d1628 0%, #0a0f1e 100%)" }}>
      <div className="px-5 py-5 border-b border-gold-500/10">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-gold-500 to-gold-700 flex items-center justify-center"><span className="text-slate-900 font-black text-sm">M</span></div>
          <div><div className="text-sm font-semibold text-slate-100 leading-none">MBA Comm</div><div className="text-[10px] text-gold-500/70 tracking-wider uppercase mt-0.5">Dominance</div></div>
        </Link>
      </div>
      {streak > 0 && (
        <div className="mx-3 mt-3 px-3 py-2.5 rounded-xl bg-gold-500/8 border border-gold-500/15">
          <div className="flex items-center gap-2"><Flame className="w-4 h-4 text-orange-400" /><div><div className="text-xs font-semibold text-slate-200">{streak}-day streak</div><div className="text-[10px] text-slate-500">Keep it going!</div></div><div className="ml-auto text-lg font-black text-gold-400">{streak}</div></div>
        </div>
      )}
      <nav className="flex-1 px-3 py-4 space-y-1">
        {navItems.map((item) => {
          const isActive = item.href === "/dashboard" ? pathname === "/dashboard" : pathname.startsWith(item.href);
          return (
            <Link key={item.href} href={item.href} onClick={() => setMobileOpen(false)}
              className={cn("flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all group",
                isActive ? "bg-gold-500/12 text-gold-300 border border-gold-500/20" : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40")}>
              <item.icon className={cn("w-4 h-4 flex-shrink-0", isActive ? "text-gold-400" : "text-slate-500 group-hover:text-slate-300")} />
              {item.label}
              {isActive && <ChevronRight className="w-3 h-3 text-gold-400/60 ml-auto" />}
            </Link>
          );
        })}
      </nav>
      <div className="px-3 py-4 border-t border-gold-500/10">
        <div className="flex items-center gap-3 px-3 py-2 rounded-xl mb-2">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-gold-600 to-gold-800 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">{user?.name[0]?.toUpperCase() || "S"}</div>
          <div className="flex-1 min-w-0"><div className="text-sm font-medium text-slate-200 truncate">{user?.name}</div><div className="text-xs text-slate-500 truncate">{user?.email}</div></div>
        </div>
        <button onClick={handleLogout} className="flex items-center gap-3 px-3 py-2 rounded-xl text-slate-500 hover:text-red-400 hover:bg-red-900/10 transition-all w-full text-sm">
          <LogOut className="w-4 h-4" /> Sign out
        </button>
      </div>
    </aside>
  );

  return (
    <EnrollmentGuard>
      <div className="flex h-screen bg-[#0a0f1e] overflow-hidden">
        <div className="hidden md:flex flex-shrink-0"><Sidebar /></div>
        <AnimatePresence>
          {mobileOpen && (
            <>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/60 z-40 md:hidden" onClick={() => setMobileOpen(false)} />
              <motion.div initial={{ x: -288 }} animate={{ x: 0 }} exit={{ x: -288 }} transition={{ type: "spring", damping: 28, stiffness: 280 }} className="fixed left-0 top-0 bottom-0 z-50 md:hidden"><Sidebar mobile /></motion.div>
            </>
          )}
        </AnimatePresence>
        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="md:hidden flex items-center justify-between px-4 py-3 border-b border-gold-500/10 bg-[#0d1628]">
            <button onClick={() => setMobileOpen(true)} className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200"><Menu className="w-5 h-5" /></button>
            <div className="flex items-center gap-2"><div className="w-6 h-6 rounded-md bg-gradient-to-br from-gold-500 to-gold-700 flex items-center justify-center"><span className="text-slate-900 font-black text-xs">M</span></div><span className="text-sm font-semibold text-slate-100">MBA Comm</span></div>
            {streak > 0 && <div className="flex items-center gap-1 text-orange-400 text-sm font-bold"><Flame className="w-4 h-4" /><span>{streak}</span></div>}
          </div>
          <main className="flex-1 overflow-y-auto">{children}</main>
        </div>
      </div>
    </EnrollmentGuard>
  );
}
