"use client";

import { motion } from "framer-motion";
import { BarChart2, TrendingUp, Award, Zap } from "lucide-react";
import { Badge } from "@/components/ui/Badge";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from "recharts";

const mockScores = [
  { day: 1, score: 71, label: "D1" },
  { day: 2, score: 74, label: "D2" },
  { day: 3, score: 72, label: "D3" },
  { day: 4, score: 78, label: "D4" },
  { day: 5, score: 80, label: "D5" },
  { day: 6, score: 77, label: "D6" },
  { day: 7, score: 84, label: "D7" },
  { day: 8, score: 85, label: "D8" },
  { day: 9, score: 88, label: "D9" },
  { day: 10, score: 91, label: "D10" },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="card-premium px-3 py-2 text-sm">
        <p className="text-slate-400 text-xs">Day {payload[0]?.payload?.day}</p>
        <p className="text-gold-400 font-bold">{payload[0]?.value}/100</p>
      </div>
    );
  }
  return null;
};

export default function PerformancePage() {
  const avgScore =
    mockScores.reduce((a, b) => a + b.score, 0) / mockScores.length;
  const trend = mockScores[mockScores.length - 1].score - mockScores[0].score;

  return (
    <div className="p-4 md:p-8 max-w-5xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <Badge variant="gold" className="mb-3">Performance Analytics</Badge>
        <h1
          className="text-2xl md:text-3xl font-bold text-slate-100"
          style={{ fontFamily: "var(--font-display)" }}
        >
          Your Progress Curve
        </h1>
        <p className="text-slate-400 mt-1">
          10 days completed · AI scoring activates in Part 2
        </p>
      </motion.div>

      {/* KPI row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          {
            icon: <Award className="w-5 h-5 text-gold-400" />,
            label: "Avg. Score",
            value: avgScore.toFixed(1),
            suffix: "/100",
          },
          {
            icon: <TrendingUp className="w-5 h-5 text-emerald-400" />,
            label: "Improvement",
            value: `+${trend}`,
            suffix: "pts",
          },
          {
            icon: <Zap className="w-5 h-5 text-blue-400" />,
            label: "Best Day",
            value: Math.max(...mockScores.map((s) => s.score)),
            suffix: "/100",
          },
          {
            icon: <BarChart2 className="w-5 h-5 text-purple-400" />,
            label: "Submissions",
            value: mockScores.length,
            suffix: "/30",
          },
        ].map((stat, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            className="card-premium p-5"
          >
            <div className="flex items-center gap-2 mb-2">
              {stat.icon}
              <span className="text-xs text-slate-500">{stat.label}</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-black text-slate-100">
                {stat.value}
              </span>
              <span className="text-sm text-slate-500">{stat.suffix}</span>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="card-premium p-6 mb-6"
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-semibold text-slate-200">Score Trajectory</h3>
          <Badge variant="gold">Days 1–10</Badge>
        </div>

        <ResponsiveContainer width="100%" height={260}>
          <AreaChart data={mockScores}>
            <defs>
              <linearGradient id="goldGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#c9a227" stopOpacity={0.2} />
                <stop offset="95%" stopColor="#c9a227" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid
              strokeDasharray="3 3"
              stroke="rgba(201,162,39,0.06)"
            />
            <XAxis
              dataKey="label"
              tick={{ fill: "#64748b", fontSize: 11 }}
              axisLine={{ stroke: "rgba(201,162,39,0.1)" }}
              tickLine={false}
            />
            <YAxis
              domain={[60, 100]}
              tick={{ fill: "#64748b", fontSize: 11 }}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip content={<CustomTooltip />} />
            <Area
              type="monotone"
              dataKey="score"
              stroke="#c9a227"
              strokeWidth={2}
              fill="url(#goldGrad)"
              dot={{ fill: "#c9a227", r: 4, strokeWidth: 0 }}
              activeDot={{ r: 6, fill: "#e8c96a" }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </motion.div>

      {/* Category breakdown */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="card-premium p-6"
      >
        <h3 className="font-semibold text-slate-200 mb-4">
          Score by Category
        </h3>
        <div className="space-y-4">
          {[
            { name: "Foundation (Days 1–6)", avg: 75.3, color: "#3b82f6" },
            { name: "Structure & Clarity (Days 7–10)", avg: 87.0, color: "#8b5cf6" },
          ].map((cat, i) => (
            <div key={i}>
              <div className="flex justify-between text-sm mb-1.5">
                <span className="text-slate-300">{cat.name}</span>
                <span className="font-bold" style={{ color: cat.color }}>
                  {cat.avg}
                </span>
              </div>
              <div className="h-2 rounded-full bg-slate-800">
                <motion.div
                  className="h-2 rounded-full"
                  style={{ background: cat.color }}
                  initial={{ width: 0 }}
                  animate={{ width: `${cat.avg}%` }}
                  transition={{ duration: 1.2, ease: "easeOut" }}
                />
              </div>
            </div>
          ))}
        </div>
        <p className="text-xs text-slate-600 mt-4">
          More categories unlock as you progress through the 30 days
        </p>
      </motion.div>
    </div>
  );
}
