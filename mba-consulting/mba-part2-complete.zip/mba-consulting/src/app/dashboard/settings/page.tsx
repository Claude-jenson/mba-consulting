"use client";

import { motion } from "framer-motion";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { User, Bell, Shield } from "lucide-react";

export default function SettingsPage() {
  return (
    <div className="p-4 md:p-8 max-w-3xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <Badge variant="gold" className="mb-3">Settings</Badge>
        <h1
          className="text-2xl md:text-3xl font-bold text-slate-100"
          style={{ fontFamily: "var(--font-display)" }}
        >
          Account Settings
        </h1>
      </motion.div>

      <div className="space-y-6">
        {/* Profile */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="card-premium p-6"
        >
          <div className="flex items-center gap-3 mb-5">
            <User className="w-4 h-4 text-gold-400" />
            <h3 className="font-semibold text-slate-200">Profile</h3>
          </div>
          <div className="space-y-4">
            {[
              { label: "Full Name", value: "Priyanka Sharma", type: "text" },
              { label: "Email", value: "priyanka@nmims.edu.in", type: "email" },
              { label: "College", value: "NMIMS Mumbai", type: "text" },
            ].map((field, i) => (
              <div key={i}>
                <label className="block text-xs font-medium text-slate-400 mb-1.5">
                  {field.label}
                </label>
                <input
                  type={field.type}
                  defaultValue={field.value}
                  className="input-premium"
                />
              </div>
            ))}
          </div>
          <Button variant="secondary" className="mt-5">
            Save Changes
          </Button>
        </motion.div>

        {/* Notifications */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="card-premium p-6"
        >
          <div className="flex items-center gap-3 mb-5">
            <Bell className="w-4 h-4 text-gold-400" />
            <h3 className="font-semibold text-slate-200">Notifications</h3>
          </div>
          <div className="space-y-4">
            {[
              { label: "Daily reminder to complete module", enabled: true },
              { label: "Streak alert (when about to break)", enabled: true },
              { label: "Score notification after AI evaluation", enabled: true },
              { label: "Weekly progress summary email", enabled: false },
            ].map((item, i) => (
              <div key={i} className="flex items-center justify-between">
                <span className="text-sm text-slate-300">{item.label}</span>
                <div
                  className={`w-11 h-6 rounded-full relative cursor-pointer transition-colors ${
                    item.enabled ? "bg-gold-600" : "bg-slate-700"
                  }`}
                >
                  <div
                    className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform ${
                      item.enabled ? "translate-x-6" : "translate-x-1"
                    }`}
                  />
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Account */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="card-premium p-6"
        >
          <div className="flex items-center gap-3 mb-5">
            <Shield className="w-4 h-4 text-gold-400" />
            <h3 className="font-semibold text-slate-200">Security</h3>
          </div>
          <div className="space-y-3">
            <Button variant="secondary" className="w-full sm:w-auto">
              Change Password
            </Button>
            <div>
              <Button variant="danger" className="w-full sm:w-auto">
                Delete Account
              </Button>
              <p className="text-xs text-slate-600 mt-1.5">
                This will permanently delete all your progress and submissions.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
