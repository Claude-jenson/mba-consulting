"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Clock, CheckCircle2, Lock, Zap } from "lucide-react";
import { courseModules, categoryConfig } from "@/data/course-modules";
import { Badge } from "@/components/ui/Badge";
import { getDayStatus, getCategoryColor } from "@/lib/utils";

const completedDays = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
const currentDay = 11;

export default function ModulesPage() {
  const grouped = Object.entries(categoryConfig).map(([key, config]) => ({
    key,
    config,
    modules: courseModules.filter((m) => m.category === key),
  }));

  return (
    <div className="p-4 md:p-8 max-w-5xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <Badge variant="gold" className="mb-3">Course Modules</Badge>
        <h1
          className="text-2xl md:text-3xl font-bold text-slate-100"
          style={{ fontFamily: "var(--font-display)" }}
        >
          All 30 Modules
        </h1>
        <p className="text-slate-400 mt-1">
          Click any unlocked module to start or review it.
        </p>
      </motion.div>

      <div className="space-y-10">
        {grouped.map(({ key, config, modules }, gi) => (
          <motion.div
            key={key}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: gi * 0.1 }}
          >
            <div className="flex items-center gap-3 mb-4">
              <div
                className="px-4 py-1.5 rounded-full text-sm font-semibold"
                style={{
                  background: `${config.color}12`,
                  color: config.color,
                  border: `1px solid ${config.color}25`,
                }}
              >
                {config.label}
              </div>
              <div className="h-px flex-1 bg-gradient-to-r from-current to-transparent opacity-10"
                style={{ color: config.color }} />
              <span className="text-xs text-slate-500">Days {config.days}</span>
            </div>

            <div className="grid gap-3">
              {modules.map((module) => {
                const status = getDayStatus(
                  module.day_number,
                  completedDays,
                  currentDay
                );
                const isLocked = status === "locked";
                const color = config.color;

                return (
                  <Link
                    key={module.id}
                    href={isLocked ? "#" : `/dashboard/day/${module.day_number}`}
                    className={isLocked ? "pointer-events-none" : ""}
                  >
                    <motion.div
                      whileHover={!isLocked ? { x: 4 } : undefined}
                      className={`flex items-center gap-4 p-4 rounded-xl border transition-all ${
                        isLocked
                          ? "bg-slate-900/20 border-slate-800/30 opacity-40"
                          : status === "current"
                          ? "bg-gold-500/8 border-gold-500/20 hover:border-gold-500/40"
                          : status === "completed"
                          ? "bg-emerald-500/5 border-emerald-500/15 hover:border-emerald-500/30"
                          : "bg-slate-800/20 border-slate-700/20 hover:border-slate-600/40"
                      }`}
                    >
                      {/* Day number */}
                      <div
                        className="w-11 h-11 rounded-xl flex items-center justify-center text-sm font-black flex-shrink-0"
                        style={{
                          background: `${color}12`,
                          color: isLocked ? "#475569" : color,
                          border: `1px solid ${color}20`,
                        }}
                      >
                        {module.day_number}
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <h3 className={`text-sm font-semibold truncate ${isLocked ? "text-slate-600" : "text-slate-200"}`}>
                          {module.title}
                        </h3>
                        <div className="flex items-center gap-3 mt-1">
                          <span className="text-xs text-slate-500 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {module.duration_minutes}m
                          </span>
                          <span className="text-xs text-slate-600">
                            {module.framework.name}
                          </span>
                        </div>
                      </div>

                      {/* Status icon */}
                      <div className="flex-shrink-0">
                        {status === "completed" ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                        ) : status === "current" ? (
                          <Zap className="w-5 h-5 text-gold-400" />
                        ) : isLocked ? (
                          <Lock className="w-4 h-4 text-slate-600" />
                        ) : (
                          <div className="w-4 h-4 rounded-full border border-slate-600" />
                        )}
                      </div>
                    </motion.div>
                  </Link>
                );
              })}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
