"use client";

import { motion } from "framer-motion";
import { Award, Lock, CheckCircle2 } from "lucide-react";
import { Badge } from "@/components/ui/Badge";
import { ProgressBar } from "@/components/ui/ProgressBar";

const requirements = [
  { label: "Complete all 30 day modules", done: false, progress: 10, total: 30 },
  { label: "Achieve average score ≥ 70/100", done: false, progress: 87, total: 100 },
  { label: "Maintain at least one submission streak", done: true, progress: 7, total: 7 },
];

export default function CertificatePage() {
  const daysCompleted = 10;
  const isEligible = daysCompleted >= 30;

  return (
    <div className="p-4 md:p-8 max-w-3xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <Badge variant="gold" className="mb-3">Certificate</Badge>
        <h1
          className="text-2xl md:text-3xl font-bold text-slate-100"
          style={{ fontFamily: "var(--font-display)" }}
        >
          Completion Certificate
        </h1>
        <p className="text-slate-400 mt-1">
          Unlock your verified certificate by completing all 30 modules
        </p>
      </motion.div>

      {/* Certificate preview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="relative mb-8"
      >
        <div
          className={`card-premium p-10 text-center relative overflow-hidden ${
            isEligible ? "glow-gold" : "opacity-50"
          }`}
        >
          {/* Background pattern */}
          <div
            className="absolute inset-0 opacity-[0.03]"
            style={{
              backgroundImage:
                "repeating-linear-gradient(45deg, #c9a227 0, #c9a227 1px, transparent 0, transparent 50%)",
              backgroundSize: "12px 12px",
            }}
          />

          {!isEligible && (
            <div className="absolute inset-0 bg-[#0a0f1e]/60 backdrop-blur-sm flex items-center justify-center z-10 rounded-xl">
              <div className="text-center">
                <Lock className="w-12 h-12 text-slate-500 mx-auto mb-3" />
                <p className="text-slate-400 font-medium">
                  Complete all 30 days to unlock
                </p>
                <p className="text-slate-600 text-sm mt-1">
                  {30 - daysCompleted} days remaining
                </p>
              </div>
            </div>
          )}

          <div className="relative z-0">
            <div className="flex justify-center mb-6">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-gold-500 to-gold-700 flex items-center justify-center shadow-gold-lg">
                <Award className="w-10 h-10 text-white" />
              </div>
            </div>

            <div className="text-xs font-bold text-gold-500/60 uppercase tracking-widest mb-2">
              Certificate of Completion
            </div>
            <h2
              className="text-3xl font-bold text-gold-gradient mb-1"
              style={{ fontFamily: "var(--font-display)" }}
            >
              MBA Communication Dominance
            </h2>
            <p className="text-slate-400 text-sm mb-6">
              30-Day Consulting Transformation Program
            </p>

            <div
              className="w-48 h-px mx-auto mb-6"
              style={{
                background:
                  "linear-gradient(90deg, transparent, #c9a227, transparent)",
              }}
            />

            <p className="text-slate-300 text-sm mb-1">This certifies that</p>
            <p
              className="text-2xl font-bold text-slate-100 mb-1"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Priyanka Sharma
            </p>
            <p className="text-slate-400 text-sm">
              has successfully completed all 30 modules with distinction
            </p>

            <div className="flex items-center justify-center gap-8 mt-6 text-xs text-slate-500">
              <div>
                <div className="font-bold text-slate-300">—</div>
                <div>Completion Date</div>
              </div>
              <div>
                <div className="font-bold text-gold-400">—/100</div>
                <div>Final Score</div>
              </div>
              <div>
                <div className="font-bold text-slate-300">#MBAC—</div>
                <div>Certificate ID</div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Requirements */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="card-premium p-6"
      >
        <h3 className="font-semibold text-slate-200 mb-5">
          Unlock Requirements
        </h3>
        <div className="space-y-5">
          {requirements.map((req, i) => (
            <div key={i}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  {req.done ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <div className="w-4 h-4 rounded-full border-2 border-slate-600" />
                  )}
                  <span className="text-sm text-slate-300">{req.label}</span>
                </div>
                <span
                  className={`text-xs font-bold ${
                    req.done ? "text-emerald-400" : "text-slate-500"
                  }`}
                >
                  {req.progress}/{req.total}
                </span>
              </div>
              <ProgressBar
                value={(req.progress / req.total) * 100}
                size="sm"
                color={req.done ? "green" : "gold"}
              />
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
