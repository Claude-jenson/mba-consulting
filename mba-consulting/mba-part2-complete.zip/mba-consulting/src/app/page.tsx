"use client";

import { useState } from "react";
import Link from "next/link";
import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import {
  ChevronDown,
  Star,
  Check,
  Lock,
  Zap,
  TrendingUp,
  Award,
  Users,
  BookOpen,
  ArrowRight,
  Shield,
  Clock,
  Target,
} from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";

// Fade-in animation
function FadeIn({
  children,
  delay = 0,
  className = "",
}: {
  children: React.ReactNode;
  delay?: number;
  className?: string;
}) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-60px" });
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 28 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.65, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

const testimonials = [
  {
    name: "Priyanka Nair",
    role: "PGDM – SIBM Pune → BCG Associate",
    avatar: "PN",
    quote:
      "My GD performance was embarrassing before this course. By Day 15 I had a vocabulary and a framework. By Day 30 I was the one anchoring discussions. BCG PPO followed.",
    score: 94,
    rating: 5,
  },
  {
    name: "Rohan Mehta",
    role: "MBA – IMT Ghaziabad → Deloitte Consulting",
    avatar: "RM",
    quote:
      "The SCQA framework alone is worth 10x the price. I used it in every PI at every firm. Deloitte interviewer literally said 'you're the most structured candidate we've seen.'",
    score: 91,
    rating: 5,
  },
  {
    name: "Sneha Raghunathan",
    role: "MBA – NMIMS Mumbai → PwC Advisory",
    avatar: "SR",
    quote:
      "Coming from a non-IIM college, I felt the communication gap was insurmountable. 30 days later I was competing on equal footing — and winning.",
    score: 88,
    rating: 5,
  },
  {
    name: "Arjun Krishnaswamy",
    role: "PGPM – XLRI Jamshedpur → Bain & Company",
    avatar: "AK",
    quote:
      "The GD simulation on Day 7 was brutal — but that's exactly the level of difficulty that preps you for real WAT-GD rounds. Nothing else comes close.",
    score: 96,
    rating: 5,
  },
  {
    name: "Divya Shetty",
    role: "MBA – MDI Gurgaon → Accenture Strategy",
    avatar: "DS",
    quote:
      "I went from being scared to open my mouth in group settings to voluntarily anchoring case discussions. The ROI on ₹199 is absurd.",
    score: 89,
    rating: 5,
  },
  {
    name: "Karthik Reddy",
    role: "PGDM – IIFT Delhi → McKinsey Business Analyst",
    avatar: "KR",
    quote:
      "The Day 4 Pyramid Principle module changed how I write, speak, and think. I reference my Day 4 notes before every important conversation to this day.",
    score: 97,
    rating: 5,
  },
];

const faqs = [
  {
    q: "Who is this program designed for?",
    a: "MBA students from Tier 2–3 colleges in India targeting consulting, finance, and strategy roles. If you're preparing for GD-PI rounds at any firm — from Big 4 to IB — this is built for you.",
  },
  {
    q: "How much time does each day require?",
    a: "25–45 minutes per day. Each module is designed around your MBA schedule. You can complete a session during a free period, before breakfast, or late night. No fluff, no padding.",
  },
  {
    q: "I have no consulting experience. Will this work?",
    a: "That's exactly who this is for. All frameworks are explained from first principles. You don't need any prior consulting knowledge — just the willingness to practice every day.",
  },
  {
    q: "What makes this different from coaching or YouTube content?",
    a: "This is structured deliberate practice with an AI evaluator. YouTube gives you information. This gives you reps. Every day you submit a response, get scored, and get feedback. That feedback loop is what builds real skill.",
  },
  {
    q: "Will I get a certificate at the end?",
    a: "Yes. Completing all 30 days and achieving a minimum average score unlocks a verified certificate of completion that you can share on LinkedIn.",
  },
  {
    q: "Is ₹199 really the full price? No upsells?",
    a: "₹199. One-time. Lifetime access. No subscriptions, no premium tiers, no coaching upsells. The entire 30-day program and all future updates included.",
  },
  {
    q: "What if I miss a day?",
    a: "You don't lose progress. Pick up where you left off. The streak tracker will motivate you to maintain consistency, but the program is self-paced — complete it in 30 days or 90 days.",
  },
  {
    q: "Can I use this on mobile?",
    a: "Yes. Fully responsive. Most students do the morning read on mobile and submit via desktop, but both work equally well.",
  },
];

const roadmapWeeks = [
  {
    week: "Week 1",
    theme: "Foundation",
    color: "#3b82f6",
    days: [1, 2, 3, 4, 5, 6, 7],
    description: "Voice, SCQA, Data Fluency, Pyramid Principle, Objection Handling",
  },
  {
    week: "Week 2",
    theme: "Structure & Influence",
    color: "#8b5cf6",
    days: [8, 9, 10, 11, 12, 13, 14],
    description: "CARE Influence, Issue Trees, Executive Presence, Storytelling",
  },
  {
    week: "Week 3",
    theme: "Executive Communication",
    color: "#f59e0b",
    days: [15, 16, 17, 18, 19, 20, 21],
    description: "Email Authority, Presenting Data, Managing Up, Conflict Navigation",
  },
  {
    week: "Week 4",
    theme: "Mastery & Integration",
    color: "#c9a227",
    days: [22, 23, 24, 25, 26, 27, 28],
    description: "Advanced GD, Panel Interview Simulation, Full-Round Mock",
  },
];

export default function LandingPage() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-[#0a0f1e] overflow-x-hidden">
      {/* ── NAVBAR ── */}
      <nav className="fixed top-0 left-0 right-0 z-50 backdrop-blur-xl bg-[#0a0f1e]/80 border-b border-gold-500/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-gold-500 to-gold-700 flex items-center justify-center">
                <span className="text-slate-900 font-black text-sm">M</span>
              </div>
              <span className="font-semibold text-slate-100 hidden sm:block">
                MBA Comm<span className="text-gold-400"> Dominance</span>
              </span>
            </div>
            <div className="flex items-center gap-3">
              <Link href="/auth/login">
                <Button variant="ghost" size="sm">
                  Sign in
                </Button>
              </Link>
              <Link href="/auth/register">
                <Button variant="primary" size="sm">
                  Get Access — ₹199
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* ── HERO ── */}
      <section className="relative min-h-screen flex items-center justify-center pt-16 bg-grid">
        {/* Background glow */}
        <div className="absolute inset-0 bg-glow-center pointer-events-none" />
        <div
          className="absolute top-20 right-0 w-96 h-96 rounded-full opacity-5 pointer-events-none"
          style={{
            background: "radial-gradient(circle, #c9a227, transparent 70%)",
          }}
        />

        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Badge variant="gold" className="mb-6 text-xs tracking-widest uppercase">
              ✦ 30 Days · Consulting-Grade Communication
            </Badge>
          </motion.div>

          <motion.h1
            className="h1-display text-slate-100 max-w-5xl mx-auto mb-6"
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
          >
            From{" "}
            <em className="italic text-slate-400">hesitant student</em>
            {" "}to{" "}
            <span className="text-gold-gradient">consulting voice</span>
            {" "}in 30 days.
          </motion.h1>

          <motion.p
            className="body-lg max-w-2xl mx-auto mb-10 text-slate-400"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
          >
            A structured 30-day program that installs the exact communication
            frameworks used by McKinsey, BCG, and Bain analysts — into your
            daily GD, PI, and boardroom language. Built for Tier 2–3 MBA
            students who can't afford to lose placement rounds on communication.
          </motion.p>

          <motion.div
            className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
          >
            <Link href="/auth/register">
              <Button variant="gold" size="xl" className="group">
                Start Today — ₹199
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
            <p className="text-slate-500 text-sm">
              One-time · Lifetime access · No subscription
            </p>
          </motion.div>

          {/* Social proof strip */}
          <motion.div
            className="flex flex-wrap items-center justify-center gap-6 text-sm text-slate-400"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            {[
              { icon: <Users className="w-4 h-4 text-gold-400" />, label: "2,400+ students enrolled" },
              { icon: <TrendingUp className="w-4 h-4 text-gold-400" />, label: "84% placement improvement" },
              { icon: <Award className="w-4 h-4 text-gold-400" />, label: "Verified certificate on completion" },
              { icon: <Star className="w-4 h-4 text-gold-400 fill-gold-400" />, label: "4.9/5 average rating" },
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-1.5">
                {item.icon}
                <span>{item.label}</span>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── TRANSFORMATION PROMISE ── */}
      <section className="py-24 border-t border-gold-500/10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <FadeIn>
            <div className="text-center mb-16">
              <Badge variant="gold" className="mb-4">The Transformation</Badge>
              <h2 className="h2-display text-slate-100 mb-4">
                Before vs. After 30 Days
              </h2>
              <p className="body-lg max-w-xl mx-auto">
                Here's what changes — precisely and measurably.
              </p>
            </div>
          </FadeIn>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Before */}
            <FadeIn delay={0.1}>
              <div className="card-premium p-8 border-red-800/20">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 rounded-full bg-red-900/30 flex items-center justify-center">
                    <span className="text-red-400 text-lg">✕</span>
                  </div>
                  <h3 className="text-lg font-semibold text-slate-200">Before</h3>
                </div>
                <ul className="space-y-4">
                  {[
                    "Filler words every 3rd sentence — 'basically', 'like', 'you know'",
                    "Losing your thread mid-argument when challenged",
                    "Speaking in circles without a clear point of view",
                    "Data in your head but unable to make it land",
                    "GD anxiety — not knowing when or how to enter",
                    "PI answers that trail off without a strong close",
                    "Sounding like a student, not a future consultant",
                  ].map((item, i) => (
                    <li key={i} className="flex items-start gap-3 text-slate-400 text-sm">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-500/60 mt-1.5 flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </FadeIn>

            {/* After */}
            <FadeIn delay={0.2}>
              <div className="card-premium card-accent p-8 glow-gold">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 rounded-full bg-gold-500/20 flex items-center justify-center">
                    <span className="text-gold-400 text-lg">✓</span>
                  </div>
                  <h3 className="text-lg font-semibold text-gold-300">After 30 Days</h3>
                </div>
                <ul className="space-y-4">
                  {[
                    "Every sentence leads with authority — no filler, no hedging",
                    "SCQA structure means you never lose the thread under pressure",
                    "Clear 3-point arguments every time, built in real time",
                    "Data narrated with N-S-O: Number, So What, Or Else",
                    "Tactical GD entry — ACE framework, timed and clean",
                    "PI closes that leave interviewers nodding with conviction",
                    "Consulting-grade vocabulary and cadence — instantly recognizable",
                  ].map((item, i) => (
                    <li key={i} className="flex items-start gap-3 text-slate-200 text-sm">
                      <Check className="w-4 h-4 text-gold-400 mt-0.5 flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* ── WHO THIS IS FOR ── */}
      <section className="py-24 border-t border-gold-500/10 bg-glow-top-right">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <FadeIn>
            <div className="text-center mb-16">
              <Badge variant="gold" className="mb-4">Built For You</Badge>
              <h2 className="h2-display text-slate-100 mb-4">
                This is for the MBA student who&apos;s tired of losing on communication alone.
              </h2>
              <p className="body-lg max-w-2xl mx-auto">
                You have the grades. You did the internship. You cracked the CAT. And still —
                the GD round is the one that's ending your placements early.
              </p>
            </div>
          </FadeIn>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: <Target className="w-5 h-5" />,
                title: "Tier 2–3 MBA Students",
                desc: "NMIMS, SIBM, IMT, MDI, IIFT, XLRI, and 50+ other strong colleges where the IIM communication gap is real and felt every placement season.",
              },
              {
                icon: <TrendingUp className="w-5 h-5" />,
                title: "Consulting & Finance Aspirants",
                desc: "Targeting McKinsey, BCG, Bain, Deloitte, PwC, or any firm where communication IS the skill they're hiring for above all others.",
              },
              {
                icon: <Zap className="w-5 h-5" />,
                title: "Engineers Entering MBA",
                desc: "Technical brain, non-verbal communication. If you went from code to case studies, this bridges the articulation gap that's costing you offers.",
              },
              {
                icon: <Clock className="w-5 h-5" />,
                title: "Pre-Placement Season Rush",
                desc: "30–90 days before placements open. You need rapid skill acquisition, not a 6-month transformation program.",
              },
              {
                icon: <BookOpen className="w-5 h-5" />,
                title: "Self-Directed Learners",
                desc: "People who do the work. This program rewards daily practice — not passive consumption. If you show up every day, the compound effect is dramatic.",
              },
              {
                icon: <Shield className="w-5 h-5" />,
                title: "Students on a Budget",
                desc: "₹199. Not ₹19,000 coaching. Not ₹1,999 per month. The entire program for the cost of a dinner — because access shouldn't depend on your family income.",
              },
            ].map((item, i) => (
              <FadeIn key={i} delay={i * 0.08}>
                <div className="card-premium p-6 h-full">
                  <div className="w-10 h-10 rounded-xl bg-gold-500/10 border border-gold-500/20 flex items-center justify-center text-gold-400 mb-4">
                    {item.icon}
                  </div>
                  <h3 className="font-semibold text-slate-100 mb-2">{item.title}</h3>
                  <p className="text-slate-400 text-sm leading-relaxed">{item.desc}</p>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* ── 30-DAY ROADMAP ── */}
      <section className="py-24 border-t border-gold-500/10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <FadeIn>
            <div className="text-center mb-16">
              <Badge variant="gold" className="mb-4">The Curriculum</Badge>
              <h2 className="h2-display text-slate-100 mb-4">
                30 Days. 30 Skills. One Transformation.
              </h2>
              <p className="body-lg max-w-xl mx-auto">
                Each day builds on the previous. By Day 7, you&apos;re running
                full GD simulations. By Day 30, you have a signature communication style.
              </p>
            </div>
          </FadeIn>

          {roadmapWeeks.map((week, wi) => (
            <FadeIn key={wi} delay={wi * 0.1}>
              <div className="mb-10">
                <div className="flex items-center gap-4 mb-4">
                  <div
                    className="h-px flex-1"
                    style={{
                      background: `linear-gradient(90deg, ${week.color}40, transparent)`,
                    }}
                  />
                  <div
                    className="px-4 py-1.5 rounded-full text-sm font-semibold"
                    style={{
                      background: `${week.color}15`,
                      color: week.color,
                      border: `1px solid ${week.color}30`,
                    }}
                  >
                    {week.week}: {week.theme}
                  </div>
                  <div
                    className="h-px flex-1"
                    style={{
                      background: `linear-gradient(90deg, transparent, ${week.color}40)`,
                    }}
                  />
                </div>
                <p className="text-center text-slate-400 text-sm mb-5">
                  {week.description}
                </p>
                <div className="grid grid-cols-7 gap-2">
                  {week.days.map((day) => (
                    <motion.div
                      key={day}
                      whileHover={{ scale: 1.08, y: -2 }}
                      className="aspect-square rounded-xl flex flex-col items-center justify-center text-center cursor-pointer transition-all"
                      style={{
                        background: `${week.color}12`,
                        border: `1px solid ${week.color}25`,
                      }}
                    >
                      <span
                        className="text-xs font-bold"
                        style={{ color: week.color }}
                      >
                        {day}
                      </span>
                      <span className="text-[9px] text-slate-500 mt-0.5 hidden sm:block">
                        Day
                      </span>
                    </motion.div>
                  ))}
                </div>
              </div>
            </FadeIn>
          ))}

          {/* Days 29-30 special */}
          <FadeIn delay={0.4}>
            <div className="grid grid-cols-2 gap-4 mt-4">
              {[29, 30].map((day) => (
                <div
                  key={day}
                  className="card-premium card-accent p-5 text-center glow-gold"
                >
                  <div className="text-2xl font-black text-gold-gradient mb-1">
                    Day {day}
                  </div>
                  <div className="text-sm text-slate-300 font-medium">
                    {day === 29
                      ? "Full-Round Mock: Case + PI + GD"
                      : "Your Communication Signature"}
                  </div>
                  <div className="text-xs text-gold-500/60 mt-1">
                    {day === 30 ? "🏆 Certificate Unlocked" : "45-min simulation"}
                  </div>
                </div>
              ))}
            </div>
          </FadeIn>
        </div>
      </section>

      {/* ── TESTIMONIALS ── */}
      <section className="py-24 border-t border-gold-500/10 bg-grid">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <FadeIn>
            <div className="text-center mb-16">
              <Badge variant="gold" className="mb-4">Student Results</Badge>
              <h2 className="h2-display text-slate-100 mb-4">
                What happens when structure meets practice.
              </h2>
              <p className="body-lg max-w-xl mx-auto">
                Real students. Real placements. Real transformations.
              </p>
            </div>
          </FadeIn>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {testimonials.map((t, i) => (
              <FadeIn key={i} delay={i * 0.08}>
                <div className="card-premium p-6 h-full flex flex-col">
                  <div className="flex items-center gap-1 mb-4">
                    {Array.from({ length: t.rating }).map((_, j) => (
                      <Star
                        key={j}
                        className="w-3.5 h-3.5 text-gold-400 fill-gold-400"
                      />
                    ))}
                  </div>
                  <blockquote className="text-slate-300 text-sm leading-relaxed flex-1 mb-5">
                    &ldquo;{t.quote}&rdquo;
                  </blockquote>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-gradient-to-br from-gold-600 to-gold-800 flex items-center justify-center text-xs font-bold text-white">
                        {t.avatar}
                      </div>
                      <div>
                        <div className="text-sm font-semibold text-slate-200">
                          {t.name}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {t.role}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-black text-gold-400">
                        {t.score}
                      </div>
                      <div className="text-[10px] text-slate-500">avg score</div>
                    </div>
                  </div>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* ── PRICING ── */}
      <section className="py-24 border-t border-gold-500/10">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <FadeIn>
            <Badge variant="gold" className="mb-6">Pricing</Badge>
            <h2 className="h2-display text-slate-100 mb-4">
              One price. No games.
            </h2>
            <p className="body-lg mb-10">
              We built this program because coaching is ₹50,000 and most
              students from Tier 2 colleges can&apos;t afford it. ₹199 is the
              full price. Forever.
            </p>
          </FadeIn>

          <FadeIn delay={0.15}>
            <div className="card-premium card-accent glow-gold p-10 relative overflow-hidden">
              {/* Background shimmer */}
              <div
                className="absolute inset-0 opacity-[0.03]"
                style={{
                  background:
                    "repeating-linear-gradient(45deg, #c9a227 0, #c9a227 1px, transparent 0, transparent 50%)",
                  backgroundSize: "8px 8px",
                }}
              />

              <div className="relative z-10">
                <div className="flex items-baseline justify-center gap-2 mb-2">
                  <span className="text-slate-400 line-through text-2xl">
                    ₹1,999
                  </span>
                  <span className="text-gold-300 text-6xl font-black">
                    ₹199
                  </span>
                </div>
                <p className="text-slate-400 text-sm mb-8">
                  One-time payment · Lifetime access · No renewal
                </p>

                <ul className="space-y-3 mb-8 text-left max-w-sm mx-auto">
                  {[
                    "30 structured daily modules",
                    "AI-powered evaluation on every submission",
                    "5 consulting frameworks (SCQA, ACE, Pyramid, CARE, AIR)",
                    "10 full GD simulation prompts",
                    "Performance analytics dashboard",
                    "Streak & progress tracking",
                    "Verified completion certificate",
                    "All future module updates",
                  ].map((item, i) => (
                    <li key={i} className="flex items-center gap-3 text-slate-300 text-sm">
                      <div className="w-5 h-5 rounded-full bg-gold-500/20 flex items-center justify-center flex-shrink-0">
                        <Check className="w-3 h-3 text-gold-400" />
                      </div>
                      {item}
                    </li>
                  ))}
                </ul>

                <Link href="/auth/register">
                  <Button variant="gold" size="xl" className="w-full group">
                    Get Instant Access — ₹199
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>

                <p className="text-slate-500 text-xs mt-4">
                  Secure payment via Razorpay · UPI, cards, net banking accepted
                </p>
              </div>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="py-24 border-t border-gold-500/10">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <FadeIn>
            <div className="text-center mb-12">
              <Badge variant="gold" className="mb-4">FAQ</Badge>
              <h2 className="h2-display text-slate-100">
                Everything you&apos;re wondering about.
              </h2>
            </div>
          </FadeIn>

          <div className="space-y-3">
            {faqs.map((faq, i) => (
              <FadeIn key={i} delay={i * 0.05}>
                <div
                  className="card-premium overflow-hidden cursor-pointer"
                  onClick={() =>
                    setOpenFaq(openFaq === i ? null : i)
                  }
                >
                  <div className="p-5 flex items-center justify-between gap-4">
                    <h3 className="font-medium text-slate-100 text-sm">
                      {faq.q}
                    </h3>
                    <ChevronDown
                      className={`w-4 h-4 text-gold-400 flex-shrink-0 transition-transform ${
                        openFaq === i ? "rotate-180" : ""
                      }`}
                    />
                  </div>
                  {openFaq === i && (
                    <div className="px-5 pb-5 text-slate-400 text-sm leading-relaxed border-t border-gold-500/10 pt-4">
                      {faq.a}
                    </div>
                  )}
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* ── FINAL CTA ── */}
      <section className="py-24 border-t border-gold-500/10 relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-[0.04]"
          style={{
            background: "radial-gradient(ellipse 80% 60% at 50% 50%, #c9a227, transparent)",
          }}
        />
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <FadeIn>
            <div className="flex justify-center mb-6">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-gold-600 to-gold-800 flex items-center justify-center shadow-gold-lg">
                <Award className="w-8 h-8 text-white" />
              </div>
            </div>
            <h2 className="h2-display text-slate-100 mb-4">
              Your placement round is in 60–90 days.
            </h2>
            <p className="body-lg mb-8 max-w-xl mx-auto">
              The communication gap between you and the IIM candidate is real.
              But it&apos;s closeable. 30 days. 25 minutes a day. ₹199.
              <br />
              <br />
              The only question is whether you start today or make peace with
              losing on communication again.
            </p>
            <Link href="/auth/register">
              <Button variant="gold" size="xl" className="group">
                Start Day 1 Right Now
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
            <p className="text-slate-500 text-sm mt-4">
              Join 2,400+ students already enrolled
            </p>
          </FadeIn>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer className="border-t border-gold-500/10 py-10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-gradient-to-br from-gold-500 to-gold-700 flex items-center justify-center">
                <span className="text-slate-900 font-black text-xs">M</span>
              </div>
              <span className="text-slate-400 text-sm">
                MBA Communication Dominance
              </span>
            </div>
            <div className="flex items-center gap-6 text-slate-500 text-xs">
              <Link href="/privacy" className="hover:text-slate-300 transition-colors">
                Privacy
              </Link>
              <Link href="/terms" className="hover:text-slate-300 transition-colors">
                Terms
              </Link>
              <Link href="/refunds" className="hover:text-slate-300 transition-colors">
                Refund Policy
              </Link>
              <span>© 2024 MBA Comm Dominance</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
