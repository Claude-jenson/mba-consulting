import { NextRequest, NextResponse } from "next/server";
import { getAuthUser } from "@/lib/security/auth-guard";
import { createAdminClient } from "@/lib/supabase/admin";

/**
 * GET /api/enrollment
 * Returns current user's enrollment status.
 * Used by frontend to decide: show paywall or dashboard.
 */
export async function GET(request: NextRequest) {
  const user = await getAuthUser();
  if (!user) {
    return NextResponse.json({ enrolled: false, reason: "unauthenticated" });
  }

  const supabase = createAdminClient();

  const [enrollmentRes, profileRes] = await Promise.all([
    supabase
      .from("enrollments")
      .select("id, is_active, enrolled_at, amount_paid")
      .eq("user_id", user.id)
      .eq("is_active", true)
      .maybeSingle(),
    supabase
      .from("profiles")
      .select("student_id, full_name, college")
      .eq("id", user.id)
      .maybeSingle(),
  ]);

  if (!enrollmentRes.data) {
    return NextResponse.json({
      enrolled: false,
      reason: "not_purchased",
      userId: user.id,
    });
  }

  return NextResponse.json({
    enrolled: true,
    enrolledAt: enrollmentRes.data.enrolled_at,
    studentId: profileRes.data?.student_id,
    profile: profileRes.data,
  });
}
