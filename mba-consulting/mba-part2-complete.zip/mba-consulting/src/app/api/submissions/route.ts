import { NextRequest, NextResponse } from "next/server";
import { requireEnrolledUser } from "@/lib/security/auth-guard";
import { enforceRateLimit } from "@/lib/security/rate-limit";
import { evaluateSubmission } from "@/lib/ai/evaluator";
import {
  upsertSubmission,
  storeScore,
  getUserProgress,
} from "@/lib/db/operations";
import { checkWeeklyReportTrigger } from "@/lib/ai/weekly-report-trigger";

export const maxDuration = 30; // Vercel: allow up to 30s for OpenAI

export async function POST(request: NextRequest) {
  // 1. Auth + enrollment check
  const { user, error: authError } = await requireEnrolledUser(request);
  if (authError) return authError;

  // 2. Parse body
  let body: { dayNumber: number; content: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const { dayNumber, content } = body;

  // 3. Validate inputs
  if (!dayNumber || dayNumber < 1 || dayNumber > 30) {
    return NextResponse.json(
      { error: "dayNumber must be between 1 and 30" },
      { status: 400 }
    );
  }

  const trimmed = content?.trim() || "";
  const wordCount = trimmed.split(/\s+/).filter(Boolean).length;

  if (wordCount < 50) {
    return NextResponse.json(
      {
        error: "Submission too short",
        message: "Please write at least 50 words for meaningful evaluation.",
        wordCount,
      },
      { status: 400 }
    );
  }

  if (wordCount > 1000) {
    return NextResponse.json(
      {
        error: "Submission too long",
        message: "Keep it under 1,000 words — consulting is about concision.",
        wordCount,
      },
      { status: 400 }
    );
  }

  // 4. Rate limit: 10 AI evaluations per user per hour
  const rl = await enforceRateLimit(
    user!.id,
    "submit",
    parseInt(process.env.AI_CALLS_PER_HOUR || "10")
  );
  if (rl) return rl;

  // 5. Verify day is unlocked (can't skip ahead)
  const progress = await getUserProgress(user!.id);
  const maxAllowedDay = Math.max(progress.currentDay, 1);

  if (dayNumber > maxAllowedDay) {
    return NextResponse.json(
      {
        error: "Day locked",
        message: `Complete Day ${maxAllowedDay - 1} first before submitting Day ${dayNumber}.`,
        code: "DAY_LOCKED",
      },
      { status: 403 }
    );
  }

  try {
    // 6. Store submission
    const { submissionId } = await upsertSubmission(
      user!.id,
      dayNumber,
      trimmed
    );

    // 7. Run AI evaluation
    const evaluation = await evaluateSubmission({
      dayNumber,
      submissionText: trimmed,
      wordCount,
    });

    // 8. Persist score
    await storeScore(submissionId, user!.id, dayNumber, evaluation);

    // 9. Check if weekly report should be generated (async, non-blocking)
    checkWeeklyReportTrigger(user!.id, dayNumber).catch((e) =>
      console.error("[WeeklyReport] Trigger failed:", e)
    );

    // 10. Return evaluation to client
    return NextResponse.json({
      success: true,
      submissionId,
      evaluation: {
        compositeScore: evaluation.compositeScore,
        dimensions: {
          clarity: evaluation.clarity,
          structure: evaluation.structure,
          logicalDepth: evaluation.logicalDepth,
          confidenceProjection: evaluation.confidenceProjection,
          consultingArticulation: evaluation.consultingArticulation,
          leadershipSignals: evaluation.leadershipSignals,
        },
        fillerCount: evaluation.fillerCount,
        fillerWordsFound: evaluation.fillerWordsFound,
        wordEconomyScore: evaluation.wordEconomyScore,
        strengths: evaluation.strengths,
        weaknesses: evaluation.weaknesses,
        improvementAdvice: evaluation.improvementAdvice,
        modelAnswer: evaluation.modelAnswer,
      },
      progress: {
        dayCompleted: dayNumber,
        nextDay: dayNumber < 30 ? dayNumber + 1 : null,
        totalCompleted: progress.completedDays.length + 1,
      },
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Evaluation failed";
    console.error("[/api/submissions POST]", message);

    // If OpenAI fails, still save the submission (score will be null)
    return NextResponse.json(
      {
        error: "Evaluation service temporarily unavailable",
        message:
          "Your submission was saved. AI evaluation will process shortly.",
        details: message,
      },
      { status: 503 }
    );
  }
}

export async function GET(request: NextRequest) {
  const { user, error: authError } = await requireEnrolledUser(request);
  if (authError) return authError;

  const { searchParams } = new URL(request.url);
  const day = searchParams.get("day");

  if (day) {
    const { getSubmission } = await import("@/lib/db/operations");
    const submission = await getSubmission(user!.id, parseInt(day));
    return NextResponse.json({ submission });
  }

  // Return all submissions with scores
  const { createAdminClient } = await import("@/lib/supabase/admin");
  const supabase = createAdminClient();
  const { data } = await supabase
    .from("submissions")
    .select("*, scores(*)")
    .eq("user_id", user!.id)
    .order("day_number");

  return NextResponse.json({ submissions: data || [] });
}
