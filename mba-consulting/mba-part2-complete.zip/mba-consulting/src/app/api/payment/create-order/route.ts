import { NextRequest, NextResponse } from "next/server";
import { getAuthUser } from "@/lib/security/auth-guard";
import { getClientIP, enforceRateLimit } from "@/lib/security/rate-limit";
import {
  createRazorpayOrder,
  COURSE_PRICE_PAISE,
} from "@/lib/payments/razorpay";
import { createPaymentRecord, getPaymentByOrder } from "@/lib/db/operations";
import { createAdminClient } from "@/lib/supabase/admin";

export async function POST(request: NextRequest) {
  try {
    // 1. Auth check
    const user = await getAuthUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // 2. Rate limit: 5 order attempts per IP per hour
    const ip = getClientIP(request);
    const rl = await enforceRateLimit(
      ip,
      "create-order",
      parseInt(process.env.PAYMENT_ORDERS_PER_HOUR || "5")
    );
    if (rl) return rl;

    // 3. Check if already enrolled — don't double charge
    const supabase = createAdminClient();
    const { data: existingEnrollment } = await supabase
      .from("enrollments")
      .select("id")
      .eq("user_id", user.id)
      .eq("is_active", true)
      .maybeSingle();

    if (existingEnrollment) {
      return NextResponse.json(
        {
          error: "Already enrolled",
          message: "You already have access to this course.",
          code: "ALREADY_ENROLLED",
        },
        { status: 409 }
      );
    }

    // 4. Check for existing pending order (don't create duplicate)
    const { data: existingPayment } = await supabase
      .from("payments")
      .select("razorpay_order_id, amount_paise")
      .eq("user_id", user.id)
      .eq("status", "created")
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (existingPayment) {
      // Verify the order still exists in Razorpay
      const existing = await getPaymentByOrder(
        existingPayment.razorpay_order_id
      );
      if (existing) {
        return NextResponse.json({
          orderId: existingPayment.razorpay_order_id,
          amount: existingPayment.amount_paise,
          currency: "INR",
          keyId: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID,
          prefill: {
            name: user.user_metadata?.full_name || "",
            email: user.email || "",
          },
        });
      }
    }

    // 5. Create fresh Razorpay order
    const receiptId = `mbac_${user.id.slice(0, 8)}_${Date.now()}`;
    const order = await createRazorpayOrder(receiptId, COURSE_PRICE_PAISE);

    // 6. Persist payment record
    await createPaymentRecord({
      userId: user.id,
      razorpayOrderId: order.id,
      amountPaise: COURSE_PRICE_PAISE,
    });

    return NextResponse.json({
      orderId: order.id,
      amount: order.amount,
      currency: order.currency,
      keyId: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID,
      prefill: {
        name: user.user_metadata?.full_name || "",
        email: user.email || "",
      },
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Order creation failed";
    console.error("[/api/payment/create-order]", message);
    return NextResponse.json(
      { error: "Payment initialization failed", details: message },
      { status: 500 }
    );
  }
}
