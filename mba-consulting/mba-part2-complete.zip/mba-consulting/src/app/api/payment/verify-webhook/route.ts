import { NextRequest, NextResponse } from "next/server";
import {
  verifyWebhookSignature,
  type RazorpayWebhookPayload,
} from "@/lib/payments/razorpay";
import {
  markPaymentVerified,
  createEnrollment,
  getPaymentByOrder,
} from "@/lib/db/operations";

/**
 * Razorpay Webhook Handler
 * Configure in Razorpay Dashboard → Settings → Webhooks
 * URL: https://your-domain.com/api/payment/verify-webhook
 * Events: payment.captured, payment.failed, refund.created
 */
export async function POST(request: NextRequest) {
  // 1. Read raw body for signature verification
  const rawBody = await request.text();
  const signature =
    request.headers.get("x-razorpay-signature") || "";

  // 2. Verify webhook authenticity
  if (!verifyWebhookSignature(rawBody, signature)) {
    console.error("[Webhook] Invalid signature — rejecting request");
    return NextResponse.json(
      { error: "Invalid signature" },
      { status: 400 }
    );
  }

  let payload: RazorpayWebhookPayload;
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return NextResponse.json(
      { error: "Invalid JSON body" },
      { status: 400 }
    );
  }

  const event = payload.event;
  console.log("[Webhook] Event received:", event);

  // 3. Handle events
  try {
    switch (event) {
      case "payment.captured": {
        await handlePaymentCaptured(payload);
        break;
      }
      case "payment.failed": {
        await handlePaymentFailed(payload);
        break;
      }
      case "refund.created": {
        await handleRefund(payload);
        break;
      }
      default:
        console.log("[Webhook] Unhandled event:", event);
    }
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error);
    console.error(`[Webhook] Handler error for ${event}:`, msg);
    // Return 200 to prevent Razorpay from retrying on expected errors
    return NextResponse.json({ received: true, error: msg }, { status: 200 });
  }

  return NextResponse.json({ received: true });
}

// ─────────────────────────────────────────────
async function handlePaymentCaptured(
  payload: RazorpayWebhookPayload
) {
  const payment = payload.payload.payment?.entity;
  if (!payment) throw new Error("Missing payment entity in webhook");

  const orderId = payment.order_id;
  const paymentId = payment.id;

  // Idempotency: skip if already processed
  const existing = await getPaymentByOrder(orderId);
  if (existing?.status === "paid") {
    console.log("[Webhook] Payment already processed:", orderId);
    return;
  }

  // Mark payment as verified
  const { paymentId: dbPaymentId, userId } = await markPaymentVerified({
    razorpayOrderId: orderId,
    razorpayPaymentId: paymentId,
    razorpaySignature: "", // signature is on the webhook level, not payment level
    payload,
  });

  // Grant course access
  const { studentId } = await createEnrollment(
    userId,
    dbPaymentId,
    payment.amount
  );

  console.log(
    `[Webhook] Enrollment created — user: ${userId}, studentId: ${studentId}`
  );
}

async function handlePaymentFailed(
  payload: RazorpayWebhookPayload
) {
  const payment = payload.payload.payment?.entity;
  if (!payment) return;

  const { createAdminClient } = await import("@/lib/supabase/admin");
  const supabase = createAdminClient();

  await supabase
    .from("payments")
    .update({ status: "failed", payload })
    .eq("razorpay_order_id", payment.order_id);

  console.log("[Webhook] Payment failed recorded:", payment.order_id);
}

async function handleRefund(payload: RazorpayWebhookPayload) {
  // Basic refund handling — mark payment refunded, deactivate enrollment
  const { createAdminClient } = await import("@/lib/supabase/admin");
  const supabase = createAdminClient();

  const payment = payload.payload.payment?.entity;
  if (!payment) return;

  const { data: paymentRecord } = await supabase
    .from("payments")
    .update({ status: "refunded", payload })
    .eq("razorpay_order_id", payment.order_id)
    .select("user_id")
    .maybeSingle();

  if (paymentRecord?.user_id) {
    await supabase
      .from("enrollments")
      .update({ is_active: false })
      .eq("user_id", paymentRecord.user_id);

    console.log("[Webhook] Enrollment deactivated for refund:", paymentRecord.user_id);
  }
}
