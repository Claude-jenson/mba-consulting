import { NextRequest, NextResponse } from "next/server";
import { requireEnrolledUser } from "@/lib/security/auth-guard";
import { getUserProgress, getWeeklyReports } from "@/lib/db/operations";

export async function GET(request: NextRequest) {
  const { user, error: authError } = await requireEnrolledUser(request);
  if (authError) return authError;

  try {
    const [progress, weeklyReports] = await Promise.all([
      getUserProgress(user!.id),
      getWeeklyReports(user!.id),
    ]);

    return NextResponse.json({
      ...progress,
      weeklyReports,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    console.error("[/api/progress]", message);
    return NextResponse.json(
      { error: "Failed to fetch progress", details: message },
      { status: 500 }
    );
  }
}
