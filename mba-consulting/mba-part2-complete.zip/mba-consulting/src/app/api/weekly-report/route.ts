import { NextRequest, NextResponse } from "next/server";
import { requireEnrolledUser } from "@/lib/security/auth-guard";
import { getWeeklyReports } from "@/lib/db/operations";
import { generateWeeklyReportForUser } from "@/lib/ai/weekly-report-trigger";

export async function GET(request: NextRequest) {
  const { user, error: authError } = await requireEnrolledUser(request);
  if (authError) return authError;

  try {
    const reports = await getWeeklyReports(user!.id);
    return NextResponse.json({ reports });
  } catch (error) {
    return NextResponse.json(
      { error: "Failed to fetch reports" },
      { status: 500 }
    );
  }
}

/**
 * POST /api/weekly-report
 * Body: { weekNumber: 1|2|3|4 }
 * Manually trigger a weekly report generation (for testing or re-gen).
 */
export async function POST(request: NextRequest) {
  const { user, error: authError } = await requireEnrolledUser(request);
  if (authError) return authError;

  let body: { weekNumber: number };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid body" }, { status: 400 });
  }

  const triggerDays: Record<number, number> = { 1: 7, 2: 15, 3: 23, 4: 30 };
  const triggerDay = triggerDays[body.weekNumber];

  if (!triggerDay) {
    return NextResponse.json(
      { error: "weekNumber must be 1, 2, 3, or 4" },
      { status: 400 }
    );
  }

  try {
    const report = await generateWeeklyReportForUser(
      user!.id,
      triggerDay
    );
    return NextResponse.json({ report });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed";
    console.error("[/api/weekly-report POST]", message);
    return NextResponse.json(
      { error: "Report generation failed", details: message },
      { status: 500 }
    );
  }
}
