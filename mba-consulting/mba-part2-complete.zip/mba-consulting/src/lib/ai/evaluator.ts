import OpenAI from "openai";
import { courseModules } from "@/data/course-modules";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// ─────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────
export interface EvaluationResult {
  // Dimension scores (1.0–5.0)
  clarity: number;
  structure: number;
  logicalDepth: number;
  confidenceProjection: number;
  consultingArticulation: number;
  leadershipSignals: number;

  // Computed
  compositeScore: number; // out of 100

  // Language analysis
  fillerCount: number;
  fillerWordsFound: string[];
  wordEconomyScore: number;

  // Qualitative
  strengths: string[];
  weaknesses: string[];
  improvementAdvice: string;
  modelAnswer: string;

  // Meta
  modelUsed: string;
  evaluationTokens: number;
}

export interface EvaluationInput {
  dayNumber: number;
  submissionText: string;
  wordCount: number;
}

// ─────────────────────────────────────────────
// FILLER WORDS to detect
// ─────────────────────────────────────────────
const FILLER_WORDS = [
  "basically",
  "literally",
  "actually",
  "honestly",
  "kind of",
  "sort of",
  "like",
  "you know",
  "i mean",
  "right?",
  "umm",
  "uh",
  "err",
  "i think",
  "maybe",
  "perhaps",
  "i feel",
  "i guess",
  "so basically",
  "at the end of the day",
  "going forward",
  "touch base",
  "circle back",
  "leverage",
  "synergize",
  "paradigm shift",
];

function detectFillers(text: string): {
  count: number;
  found: string[];
} {
  const lower = text.toLowerCase();
  const found: string[] = [];
  for (const filler of FILLER_WORDS) {
    const regex = new RegExp(`\\b${filler.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "gi");
    const matches = lower.match(regex);
    if (matches && matches.length > 0) {
      found.push(`"${filler}" (×${matches.length})`);
    }
  }
  return { count: found.length, found };
}

// ─────────────────────────────────────────────
// Build the evaluation system prompt
// ─────────────────────────────────────────────
function buildSystemPrompt(dayModule: (typeof courseModules)[0]): string {
  return `You are a senior partner at McKinsey & Company evaluating a candidate's Group Discussion and Personal Interview communication skills. You have 20 years of experience conducting interviews and evaluating MBA candidates from India.

Your task: Evaluate the submitted response against the Day ${dayModule.day_number} module criteria.

MODULE CONTEXT:
- Day: ${dayModule.day_number}
- Title: ${dayModule.title}
- Objective: ${dayModule.objective}
- Framework being assessed: ${dayModule.framework.name} — ${dayModule.framework.description}
- GD/PI Prompt given to student: "${dayModule.gd_prompt}"

EVALUATION CRITERIA (score each 1.0–5.0, one decimal):
1. clarity — Is the main point immediately obvious? Is there no ambiguity?
2. structure — Does it follow a logical arc? Is ${dayModule.framework.name} applied?
3. logicalDepth — Are arguments substantiated? Is analysis beyond surface level?
4. confidenceProjection — Does the language project authority, not tentativeness?
5. consultingArticulation — Business vocabulary, precision, professional tone?
6. leadershipSignals — Does the candidate lead the narrative? Synthesize well?
7. wordEconomyScore — No wasted words? Every sentence earns its place?

SCORING GUIDE:
5.0 = McKinsey/BCG final round standard
4.0–4.9 = Strong, hire-worthy
3.0–3.9 = Adequate, needs polish
2.0–2.9 = Below bar, significant gaps
1.0–1.9 = Fundamental communication issues

Be HONEST and CALIBRATED. Most students score 2.5–3.5 on first attempts. Reserve 4+ for genuinely strong work.

RESPOND ONLY WITH VALID JSON. No markdown fences, no explanation outside the JSON. Use this exact structure:
{
  "clarity": <number 1.0-5.0>,
  "structure": <number 1.0-5.0>,
  "logicalDepth": <number 1.0-5.0>,
  "confidenceProjection": <number 1.0-5.0>,
  "consultingArticulation": <number 1.0-5.0>,
  "leadershipSignals": <number 1.0-5.0>,
  "wordEconomyScore": <number 1.0-5.0>,
  "strengths": [<string>, <string>, <string>],
  "weaknesses": [<string>, <string>, <string>],
  "improvementAdvice": "<2–3 sentence actionable advice for this specific response>",
  "modelAnswer": "<50–80 word consulting-grade model answer for the same prompt>"
}`;
}

// ─────────────────────────────────────────────
// Main evaluation function
// ─────────────────────────────────────────────
export async function evaluateSubmission(
  input: EvaluationInput
): Promise<EvaluationResult> {
  const module = courseModules.find((m) => m.day_number === input.dayNumber);
  if (!module) {
    throw new Error(`Module not found for day ${input.dayNumber}`);
  }

  // Filler detection (local — no API cost)
  const { count: fillerCount, found: fillerWordsFound } = detectFillers(
    input.submissionText
  );

  // Build messages
  const systemPrompt = buildSystemPrompt(module);
  const userMessage = `STUDENT SUBMISSION (${input.wordCount} words):

"${input.submissionText}"

Evaluate this response now.`;

  // Call OpenAI
  const completion = await openai.chat.completions.create({
    model: "gpt-4o",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userMessage },
    ],
    temperature: 0.2, // Low temp for consistent scoring
    max_tokens: 800,
    response_format: { type: "json_object" },
  });

  const raw = completion.choices[0]?.message?.content;
  if (!raw) throw new Error("OpenAI returned empty response");

  let parsed: Record<string, unknown>;
  try {
    parsed = JSON.parse(raw);
  } catch {
    throw new Error(`OpenAI returned invalid JSON: ${raw.slice(0, 200)}`);
  }

  // Extract and clamp scores
  function toScore(val: unknown, fallback = 3.0): number {
    const n = parseFloat(String(val));
    if (isNaN(n)) return fallback;
    return Math.min(5, Math.max(1, Math.round(n * 10) / 10));
  }

  const clarity              = toScore(parsed.clarity);
  const structure            = toScore(parsed.structure);
  const logicalDepth         = toScore(parsed.logicalDepth);
  const confidenceProjection = toScore(parsed.confidenceProjection);
  const consultingArticulation = toScore(parsed.consultingArticulation);
  const leadershipSignals    = toScore(parsed.leadershipSignals);
  const wordEconomyScore     = toScore(parsed.wordEconomyScore);

  // Composite: average of 6 main dimensions, scaled to 100
  const composite = parseFloat(
    (
      ((clarity + structure + logicalDepth + confidenceProjection +
        consultingArticulation + leadershipSignals) /
        30) *
      100
    ).toFixed(1)
  );

  return {
    clarity,
    structure,
    logicalDepth,
    confidenceProjection,
    consultingArticulation,
    leadershipSignals,
    compositeScore: composite,
    fillerCount,
    fillerWordsFound,
    wordEconomyScore,
    strengths: Array.isArray(parsed.strengths)
      ? (parsed.strengths as string[]).slice(0, 3)
      : ["Good attempt"],
    weaknesses: Array.isArray(parsed.weaknesses)
      ? (parsed.weaknesses as string[]).slice(0, 3)
      : ["Needs improvement"],
    improvementAdvice: String(parsed.improvementAdvice || ""),
    modelAnswer: String(parsed.modelAnswer || ""),
    modelUsed: completion.model,
    evaluationTokens: completion.usage?.total_tokens ?? 0,
  };
}

// ─────────────────────────────────────────────
// Weekly report narrative generator
// ─────────────────────────────────────────────
export interface WeeklyReportInput {
  userName: string;
  weekNumber: number;
  daysCovered: number[];
  avgScore: number;
  baselineScore: number;
  growthPct: number;
  categoryScores: Record<string, number>;
  bestCategory: string;
  weakestCategory: string;
}

export async function generateWeeklyNarrative(
  input: WeeklyReportInput
): Promise<{ summaryText: string; topStrength: string; focusArea: string }> {
  const prompt = `You are a McKinsey-trained communication coach writing a concise weekly progress report for an MBA student.

Student: ${input.userName}
Week: ${input.weekNumber} (Days ${input.daysCovered[0]}–${input.daysCovered[input.daysCovered.length - 1]})
Average score this week: ${input.avgScore}/100
Baseline score (first submission): ${input.baselineScore}/100
Growth: ${input.growthPct > 0 ? "+" : ""}${input.growthPct}%
Best performing area: ${input.bestCategory} (${input.categoryScores[input.bestCategory]}/100)
Area needing most work: ${input.weakestCategory} (${input.categoryScores[input.weakestCategory]}/100)

Write a 3-sentence coaching summary, a one-line top strength, and a one-line focus area for next week.

Respond as JSON only:
{
  "summaryText": "<3 sentence coaching narrative — warm, honest, specific>",
  "topStrength": "<one crisp sentence about their biggest win this week>",
  "focusArea": "<one crisp sentence about the single most important thing to improve next week>"
}`;

  const completion = await openai.chat.completions.create({
    model: "gpt-4o",
    messages: [{ role: "user", content: prompt }],
    temperature: 0.4,
    max_tokens: 400,
    response_format: { type: "json_object" },
  });

  const raw = completion.choices[0]?.message?.content || "{}";
  const parsed = JSON.parse(raw);

  return {
    summaryText: String(parsed.summaryText || ""),
    topStrength: String(parsed.topStrength || ""),
    focusArea: String(parsed.focusArea || ""),
  };
}
