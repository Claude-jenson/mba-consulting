import { createAdminClient } from "@/lib/supabase/admin";
import {
  generateWeeklyNarrative,
  type WeeklyReportInput,
} from "@/lib/ai/evaluator";
import { storeWeeklyReport } from "@/lib/db/operations";

// Week configuration: trigger on these days
const WEEK_CONFIG = [
  { weekNumber: 1, triggerDay: 7,  range: [1, 7]   },
  { weekNumber: 2, triggerDay: 15, range: [8, 15]  },
  { weekNumber: 3, triggerDay: 23, range: [16, 23] },
  { weekNumber: 4, triggerDay: 30, range: [24, 30] },
] as const;

type CategoryKey = "foundation" | "structure" | "influence" | "executive" | "mastery";

const DAY_CATEGORIES: Record<number, CategoryKey> = {};
for (let d = 1; d <= 6;  d++) DAY_CATEGORIES[d] = "foundation";
for (let d = 7; d <= 12; d++) DAY_CATEGORIES[d] = "structure";
for (let d = 13; d <= 18; d++) DAY_CATEGORIES[d] = "influence";
for (let d = 19; d <= 24; d++) DAY_CATEGORIES[d] = "executive";
for (let d = 25; d <= 30; d++) DAY_CATEGORIES[d] = "mastery";

/**
 * Called after every submission.
 * If the completed day is a trigger day (7, 15, 23, 30), fires report.
 */
export async function checkWeeklyReportTrigger(
  userId: string,
  completedDay: number
) {
  const config = WEEK_CONFIG.find((w) => w.triggerDay === completedDay);
  if (!config) return; // Not a trigger day

  // Check if report already exists for this week
  const supabase = createAdminClient();
  const { data: existing } = await supabase
    .from("weekly_reports")
    .select("id")
    .eq("user_id", userId)
    .eq("week_number", config.weekNumber)
    .maybeSingle();

  if (existing) {
    console.log(
      `[WeeklyReport] Already exists for user ${userId} week ${config.weekNumber}`
    );
    return;
  }

  await generateWeeklyReportForUser(userId, completedDay);
}

/**
 * Generate and store weekly report for a user.
 */
export async function generateWeeklyReportForUser(
  userId: string,
  triggerDay: number
) {
  const config = WEEK_CONFIG.find((w) => w.triggerDay === triggerDay);
  if (!config) throw new Error(`Invalid trigger day: ${triggerDay}`);

  const supabase = createAdminClient();

  // Fetch scores for the days in this week's range
  const { data: scores } = await supabase
    .from("scores")
    .select("day_number, composite_score")
    .eq("user_id", userId)
    .gte("day_number", config.range[0])
    .lte("day_number", config.range[1])
    .not("composite_score", "is", null);

  if (!scores || scores.length === 0) {
    throw new Error("No scores found for this week range");
  }

  // Compute weekly average
  const avgScore = parseFloat(
    (
      scores.reduce((sum, s) => sum + (s.composite_score || 0), 0) /
      scores.length
    ).toFixed(1)
  );

  // Baseline = first ever submission score
  const { data: firstScore } = await supabase
    .from("scores")
    .select("composite_score")
    .eq("user_id", userId)
    .order("day_number", { ascending: true })
    .limit(1)
    .maybeSingle();

  const baselineScore = firstScore?.composite_score ?? avgScore;
  const growthPct = parseFloat(
    (((avgScore - baselineScore) / baselineScore) * 100).toFixed(1)
  );

  // Category breakdown for this week
  const categoryScores: Record<string, number> = {};
  const categoryAccumulator: Record<string, number[]> = {};

  for (const score of scores) {
    const cat = DAY_CATEGORIES[score.day_number] || "foundation";
    if (!categoryAccumulator[cat]) categoryAccumulator[cat] = [];
    categoryAccumulator[cat].push(score.composite_score || 0);
  }

  for (const [cat, vals] of Object.entries(categoryAccumulator)) {
    categoryScores[cat] = parseFloat(
      (vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(1)
    );
  }

  const sortedCategories = Object.entries(categoryScores).sort(
    ([, a], [, b]) => b - a
  );
  const bestCategory = sortedCategories[0]?.[0] || "foundation";
  const weakestCategory =
    sortedCategories[sortedCategories.length - 1]?.[0] || "foundation";

  // Fetch user name
  const { data: profile } = await supabase
    .from("profiles")
    .select("full_name")
    .eq("id", userId)
    .maybeSingle();

  const userName = profile?.full_name || "Student";

  // Generate AI narrative
  const narrativeInput: WeeklyReportInput = {
    userName,
    weekNumber: config.weekNumber,
    daysCovered: Array.from(
      { length: config.range[1] - config.range[0] + 1 },
      (_, i) => config.range[0] + i
    ),
    avgScore,
    baselineScore,
    growthPct,
    categoryScores,
    bestCategory,
    weakestCategory,
  };

  const { summaryText, topStrength, focusArea } =
    await generateWeeklyNarrative(narrativeInput);

  // Store report
  await storeWeeklyReport({
    userId,
    weekNumber: config.weekNumber,
    triggerDay,
    daysCovered: [config.range[0], config.range[1]],
    avgScore,
    baselineScore,
    growthPct,
    categoryScores,
    bestCategory,
    weakestCategory,
    summaryText,
    topStrength,
    focusArea,
  });

  console.log(
    `[WeeklyReport] Generated for ${userId} — Week ${config.weekNumber}, avg: ${avgScore}`
  );

  return {
    weekNumber: config.weekNumber,
    avgScore,
    growthPct,
    summaryText,
    topStrength,
    focusArea,
  };
}
