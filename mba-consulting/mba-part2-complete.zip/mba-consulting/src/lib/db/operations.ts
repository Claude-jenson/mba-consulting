import { createAdminClient } from "@/lib/supabase/admin";
import type { EvaluationResult } from "@/lib/ai/evaluator";

// ─────────────────────────────────────────────
// ENROLLMENT
// ─────────────────────────────────────────────

export async function createEnrollment(
  userId: string,
  paymentId: string,
  amountPaid: number
): Promise<{ studentId: string }> {
  const supabase = createAdminClient();

  // Generate student ID
  const { data: sid } = await supabase.rpc("generate_student_id");
  const studentId = sid as string;

  // Update profile with student ID
  await supabase
    .from("profiles")
    .update({ student_id: studentId })
    .eq("id", userId);

  // Upsert enrollment
  const { error: enrollError } = await supabase.from("enrollments").upsert(
    {
      user_id: userId,
      payment_id: paymentId,
      is_active: true,
      amount_paid: amountPaid,
      enrolled_at: new Date().toISOString(),
    },
    { onConflict: "user_id" }
  );

  if (enrollError) {
    throw new Error(`Failed to create enrollment: ${enrollError.message}`);
  }

  return { studentId };
}

// ─────────────────────────────────────────────
// SUBMISSIONS
// ─────────────────────────────────────────────

export async function upsertSubmission(
  userId: string,
  dayNumber: number,
  content: string
): Promise<{ submissionId: string; isNew: boolean }> {
  const supabase = createAdminClient();

  const { data, error } = await supabase
    .from("submissions")
    .upsert(
      {
        user_id: userId,
        day_number: dayNumber,
        content,
        submitted_at: new Date().toISOString(),
      },
      { onConflict: "user_id,day_number" }
    )
    .select("id")
    .single();

  if (error) throw new Error(`Submission upsert failed: ${error.message}`);

  return {
    submissionId: data.id,
    isNew: true, // simplified — could track via trigger
  };
}

export async function getSubmission(userId: string, dayNumber: number) {
  const supabase = createAdminClient();
  const { data } = await supabase
    .from("submissions")
    .select("*, scores(*)")
    .eq("user_id", userId)
    .eq("day_number", dayNumber)
    .maybeSingle();
  return data;
}

// ─────────────────────────────────────────────
// SCORES
// ─────────────────────────────────────────────

export async function storeScore(
  submissionId: string,
  userId: string,
  dayNumber: number,
  evaluation: EvaluationResult
): Promise<string> {
  const supabase = createAdminClient();

  const { data, error } = await supabase
    .from("scores")
    .upsert(
      {
        submission_id: submissionId,
        user_id: userId,
        day_number: dayNumber,
        clarity: evaluation.clarity,
        structure: evaluation.structure,
        logical_depth: evaluation.logicalDepth,
        confidence_projection: evaluation.confidenceProjection,
        consulting_articulation: evaluation.consultingArticulation,
        leadership_signals: evaluation.leadershipSignals,
        filler_count: evaluation.fillerCount,
        filler_words_found: evaluation.fillerWordsFound,
        word_economy_score: evaluation.wordEconomyScore,
        strengths: evaluation.strengths,
        weaknesses: evaluation.weaknesses,
        improvement_advice: evaluation.improvementAdvice,
        model_answer: evaluation.modelAnswer,
        model_used: evaluation.modelUsed,
        evaluation_tokens: evaluation.evaluationTokens,
        evaluated_at: new Date().toISOString(),
      },
      { onConflict: "submission_id" }
    )
    .select("id")
    .single();

  if (error) throw new Error(`Score storage failed: ${error.message}`);

  // Also update user_progress
  await supabase.from("user_progress").upsert(
    {
      user_id: userId,
      day_number: dayNumber,
      completed: true,
      completed_at: new Date().toISOString(),
      composite_score: evaluation.compositeScore,
    },
    { onConflict: "user_id,day_number" }
  );

  return data.id;
}

// ─────────────────────────────────────────────
// PROGRESS
// ─────────────────────────────────────────────

export async function getUserProgress(userId: string) {
  const supabase = createAdminClient();

  const [progressRes, scoresRes] = await Promise.all([
    supabase
      .from("user_progress")
      .select("*")
      .eq("user_id", userId)
      .order("day_number"),
    supabase
      .from("scores")
      .select("day_number, composite_score, evaluated_at")
      .eq("user_id", userId)
      .order("day_number"),
  ]);

  const completedDays = (progressRes.data || [])
    .filter((p) => p.completed)
    .map((p) => p.day_number);

  const scoreHistory = (scoresRes.data || []).map((s) => ({
    day: s.day_number,
    score: s.composite_score,
    date: s.evaluated_at,
  }));

  const avgScore =
    scoreHistory.length > 0
      ? Math.round(
          scoreHistory.reduce((sum, s) => sum + (s.score || 0), 0) /
            scoreHistory.length
        )
      : 0;

  // Streak calc
  const { data: streakData } = await supabase.rpc("get_streak", {
    p_user_id: userId,
  });

  return {
    completedDays,
    currentDay: completedDays.length + 1,
    streak: (streakData as number) || 0,
    averageScore: avgScore,
    totalSubmissions: completedDays.length,
    scoreHistory,
    progressPercent: Math.round((completedDays.length / 30) * 100),
  };
}

// ─────────────────────────────────────────────
// WEEKLY REPORT
// ─────────────────────────────────────────────

export async function storeWeeklyReport(params: {
  userId: string;
  weekNumber: number;
  triggerDay: number;
  daysCovered: [number, number]; // [start, end]
  avgScore: number;
  baselineScore: number;
  growthPct: number;
  categoryScores: Record<string, number>;
  bestCategory: string;
  weakestCategory: string;
  summaryText: string;
  topStrength: string;
  focusArea: string;
}) {
  const supabase = createAdminClient();

  const { error } = await supabase.from("weekly_reports").upsert(
    {
      user_id: params.userId,
      week_number: params.weekNumber,
      trigger_day: params.triggerDay,
      days_covered: `[${params.daysCovered[0]},${params.daysCovered[1] + 1})`,
      avg_score: params.avgScore,
      baseline_score: params.baselineScore,
      growth_pct: params.growthPct,
      best_category: params.bestCategory,
      weakest_category: params.weakestCategory,
      category_scores: params.categoryScores,
      summary_text: params.summaryText,
      top_strength: params.topStrength,
      focus_area: params.focusArea,
      generated_at: new Date().toISOString(),
    },
    { onConflict: "user_id,week_number" }
  );

  if (error) {
    console.error("[DB] Weekly report store failed:", error.message);
  }
}

export async function getWeeklyReports(userId: string) {
  const supabase = createAdminClient();
  const { data } = await supabase
    .from("weekly_reports")
    .select("*")
    .eq("user_id", userId)
    .order("week_number");
  return data || [];
}

// ─────────────────────────────────────────────
// PAYMENTS
// ─────────────────────────────────────────────

export async function createPaymentRecord(params: {
  userId: string;
  razorpayOrderId: string;
  amountPaise: number;
}): Promise<string> {
  const supabase = createAdminClient();

  const { data, error } = await supabase
    .from("payments")
    .insert({
      user_id: params.userId,
      razorpay_order_id: params.razorpayOrderId,
      amount_paise: params.amountPaise,
      status: "created",
    })
    .select("id")
    .single();

  if (error) throw new Error(`Payment record creation failed: ${error.message}`);
  return data.id;
}

export async function markPaymentVerified(params: {
  razorpayOrderId: string;
  razorpayPaymentId: string;
  razorpaySignature: string;
  payload: unknown;
}): Promise<{ paymentId: string; userId: string }> {
  const supabase = createAdminClient();

  const { data, error } = await supabase
    .from("payments")
    .update({
      razorpay_payment_id: params.razorpayPaymentId,
      razorpay_signature: params.razorpaySignature,
      status: "paid",
      payload: params.payload,
      verified_at: new Date().toISOString(),
    })
    .eq("razorpay_order_id", params.razorpayOrderId)
    .select("id, user_id")
    .single();

  if (error || !data) {
    throw new Error(
      `Payment update failed: ${error?.message || "order not found"}`
    );
  }

  return { paymentId: data.id, userId: data.user_id };
}

export async function getPaymentByOrder(orderId: string) {
  const supabase = createAdminClient();
  const { data } = await supabase
    .from("payments")
    .select("*")
    .eq("razorpay_order_id", orderId)
    .maybeSingle();
  return data;
}
