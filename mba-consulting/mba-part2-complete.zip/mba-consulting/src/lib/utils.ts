import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: string | Date): string {
  return new Intl.DateTimeFormat("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  }).format(new Date(date));
}

export function getDayStatus(
  dayNumber: number,
  completedDays: number[],
  currentDay: number
): "completed" | "current" | "locked" | "available" {
  if (completedDays.includes(dayNumber)) return "completed";
  if (dayNumber === currentDay) return "current";
  if (dayNumber <= currentDay) return "available";
  return "locked";
}

export function calculateStreak(completedDays: number[]): number {
  if (!completedDays.length) return 0;
  const sorted = [...completedDays].sort((a, b) => b - a);
  let streak = 0;
  let expected = sorted[0];
  for (const day of sorted) {
    if (day === expected) {
      streak++;
      expected--;
    } else {
      break;
    }
  }
  return streak;
}

export function getProgressPercentage(completedDays: number[]): number {
  return Math.round((completedDays.length / 30) * 100);
}

export function getCategoryColor(category: string): string {
  const colors: Record<string, string> = {
    foundation: "#3b82f6",
    structure: "#8b5cf6",
    influence: "#f59e0b",
    executive: "#10b981",
    mastery: "#c9a227",
  };
  return colors[category] || "#64748b";
}
