"use client";

import { useState } from "react";
import type { EvaluationResult } from "@/lib/ai/evaluator";

export interface SubmissionState {
  status: "idle" | "submitting" | "success" | "error";
  evaluation: EvaluationResult | null;
  error: string | null;
  nextDay: number | null;
}

export function useSubmission(dayNumber: number) {
  const [state, setState] = useState<SubmissionState>({
    status: "idle",
    evaluation: null,
    error: null,
    nextDay: null,
  });

  const submit = async (content: string) => {
    setState({ status: "submitting", evaluation: null, error: null, nextDay: null });

    try {
      const res = await fetch("/api/submissions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dayNumber, content }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.message || data.error || "Submission failed");
      }

      setState({
        status: "success",
        evaluation: data.evaluation,
        error: null,
        nextDay: data.progress?.nextDay || null,
      });
    } catch (err) {
      setState({
        status: "error",
        evaluation: null,
        error: err instanceof Error ? err.message : "Submission failed",
        nextDay: null,
      });
    }
  };

  const reset = () =>
    setState({ status: "idle", evaluation: null, error: null, nextDay: null });

  return { ...state, submit, reset };
}
