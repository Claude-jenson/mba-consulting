import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import type { User } from "@supabase/supabase-js";

/**
 * Extract authenticated user from request cookies.
 * Returns user or null. Use in every protected API route.
 */
export async function getAuthUser(): Promise<User | null> {
  try {
    const supabase = createClient();
    const {
      data: { user },
      error,
    } = await supabase.auth.getUser();
    if (error || !user) return null;
    return user;
  } catch {
    return null;
  }
}

/**
 * Verify that a user has an active enrollment.
 */
export async function verifyEnrollment(userId: string): Promise<boolean> {
  try {
    const supabase = createAdminClient();
    const { data, error } = await supabase
      .from("enrollments")
      .select("id, is_active")
      .eq("user_id", userId)
      .eq("is_active", true)
      .maybeSingle();

    if (error || !data) return false;
    return data.is_active === true;
  } catch {
    return false;
  }
}

/**
 * Require auth + enrollment. Returns 401/403 Response if failed,
 * otherwise returns { user }.
 */
export async function requireEnrolledUser(request: Request): Promise<
  | { user: User; error: null }
  | { user: null; error: Response }
> {
  const user = await getAuthUser();

  if (!user) {
    return {
      user: null,
      error: new Response(
        JSON.stringify({ error: "Unauthorized", message: "Please log in." }),
        { status: 401, headers: { "Content-Type": "application/json" } }
      ),
    };
  }

  const enrolled = await verifyEnrollment(user.id);
  if (!enrolled) {
    return {
      user: null,
      error: new Response(
        JSON.stringify({
          error: "Forbidden",
          message: "Course purchase required. Please complete payment.",
          code: "NOT_ENROLLED",
        }),
        { status: 403, headers: { "Content-Type": "application/json" } }
      ),
    };
  }

  return { user, error: null };
}
