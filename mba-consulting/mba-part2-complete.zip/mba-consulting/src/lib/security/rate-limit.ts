import { createAdminClient } from "@/lib/supabase/admin";
import { NextRequest } from "next/server";

export function getClientIP(request: NextRequest): string {
  return (
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    request.headers.get("x-real-ip") ||
    "unknown"
  );
}

/**
 * Check and increment rate limit for a given key.
 * Uses a 1-hour sliding window stored in Supabase.
 * Returns { allowed: boolean, remaining: number }
 */
export async function checkRateLimit(
  key: string,
  maxPerHour: number
): Promise<{ allowed: boolean; remaining: number; resetAt: Date }> {
  const supabase = createAdminClient();
  const windowStart = new Date();
  windowStart.setMinutes(0, 0, 0); // floor to current hour

  const resetAt = new Date(windowStart);
  resetAt.setHours(resetAt.getHours() + 1);

  // Try to upsert
  const { data, error } = await supabase.rpc("upsert_rate_limit", {
    p_key: key,
    p_window_start: windowStart.toISOString(),
    p_max: maxPerHour,
  });

  if (error) {
    // Fail open on DB error — don't block legitimate users
    console.error("[RateLimit] DB error:", error.message);
    return { allowed: true, remaining: maxPerHour, resetAt };
  }

  const count: number = data ?? 1;
  return {
    allowed: count <= maxPerHour,
    remaining: Math.max(0, maxPerHour - count),
    resetAt,
  };
}

/**
 * Convenience: rate limit an API route by user ID.
 * Returns a 429 Response if exceeded, otherwise null.
 */
export async function enforceRateLimit(
  userId: string,
  action: string,
  maxPerHour: number
): Promise<Response | null> {
  const key = `${action}:${userId}`;
  const { allowed, remaining, resetAt } = await checkRateLimit(
    key,
    maxPerHour
  );

  if (!allowed) {
    return new Response(
      JSON.stringify({
        error: "Rate limit exceeded",
        retryAfter: resetAt.toISOString(),
        message: `You can make ${maxPerHour} ${action} requests per hour. Try again after ${resetAt.toLocaleTimeString("en-IN")}.`,
      }),
      {
        status: 429,
        headers: {
          "Content-Type": "application/json",
          "Retry-After": resetAt.toISOString(),
          "X-RateLimit-Remaining": remaining.toString(),
        },
      }
    );
  }
  return null;
}
