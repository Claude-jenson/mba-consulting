import crypto from "crypto";

export const COURSE_PRICE_PAISE =
  parseInt(process.env.NEXT_PUBLIC_COURSE_PRICE_PAISE || "19900");

export interface RazorpayOrderResponse {
  id: string;
  entity: string;
  amount: number;
  amount_paid: number;
  amount_due: number;
  currency: string;
  receipt: string;
  status: string;
  attempts: number;
  created_at: number;
}

/**
 * Create a Razorpay order via their REST API.
 * Razorpay Node SDK is not available in Edge — use fetch directly.
 */
export async function createRazorpayOrder(
  receiptId: string,
  amountPaise: number = COURSE_PRICE_PAISE
): Promise<RazorpayOrderResponse> {
  const keyId = process.env.RAZORPAY_KEY_ID!;
  const keySecret = process.env.RAZORPAY_KEY_SECRET!;

  if (!keyId || !keySecret) {
    throw new Error("Razorpay credentials not configured");
  }

  const basicAuth = Buffer.from(`${keyId}:${keySecret}`).toString("base64");

  const response = await fetch("https://api.razorpay.com/v1/orders", {
    method: "POST",
    headers: {
      Authorization: `Basic ${basicAuth}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      amount: amountPaise,
      currency: "INR",
      receipt: receiptId,
      notes: {
        product: "MBA Communication Dominance",
        type: "course_access",
      },
    }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(
      `Razorpay order creation failed: ${JSON.stringify(err)}`
    );
  }

  return response.json();
}

/**
 * Verify Razorpay payment signature.
 * Must be called after client-side payment success callback.
 *
 * Signature = HMAC-SHA256(order_id + "|" + payment_id, secret)
 */
export function verifyPaymentSignature(
  orderId: string,
  paymentId: string,
  signature: string
): boolean {
  const secret = process.env.RAZORPAY_KEY_SECRET!;
  const body = `${orderId}|${paymentId}`;
  const expected = crypto
    .createHmac("sha256", secret)
    .update(body)
    .digest("hex");
  return crypto.timingSafeEqual(
    Buffer.from(expected, "hex"),
    Buffer.from(signature, "hex")
  );
}

/**
 * Verify Razorpay webhook signature.
 * Uses the WEBHOOK secret (different from key secret).
 *
 * Signature = HMAC-SHA256(rawBody, webhookSecret)
 */
export function verifyWebhookSignature(
  rawBody: string,
  signature: string
): boolean {
  const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET!;
  if (!webhookSecret) {
    console.error("[Razorpay] RAZORPAY_WEBHOOK_SECRET not set");
    return false;
  }
  const expected = crypto
    .createHmac("sha256", webhookSecret)
    .update(rawBody)
    .digest("hex");
  try {
    return crypto.timingSafeEqual(
      Buffer.from(expected, "hex"),
      Buffer.from(signature, "hex")
    );
  } catch {
    return false;
  }
}

export interface RazorpayWebhookPayload {
  entity: string;
  account_id: string;
  event: string; // "payment.captured" | "payment.failed" | "refund.created"
  contains: string[];
  payload: {
    payment?: {
      entity: {
        id: string;
        order_id: string;
        amount: number;
        currency: string;
        status: string;
        method: string;
        email: string;
        contact: string;
        notes: Record<string, string>;
      };
    };
    order?: {
      entity: {
        id: string;
        receipt: string;
        status: string;
      };
    };
  };
  created_at: number;
}
