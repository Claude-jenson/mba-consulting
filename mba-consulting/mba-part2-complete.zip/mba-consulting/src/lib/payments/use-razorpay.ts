"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

declare global {
  interface Window {
    Razorpay: new (options: RazorpayOptions) => RazorpayInstance;
  }
}

interface RazorpayOptions {
  key: string;
  amount: number;
  currency: string;
  name: string;
  description: string;
  order_id: string;
  prefill?: { name?: string; email?: string; contact?: string };
  notes?: Record<string, string>;
  theme?: { color?: string };
  handler: (response: RazorpaySuccessResponse) => void;
  modal?: {
    ondismiss?: () => void;
    escape?: boolean;
  };
}

interface RazorpayInstance {
  open: () => void;
  close: () => void;
}

interface RazorpaySuccessResponse {
  razorpay_payment_id: string;
  razorpay_order_id: string;
  razorpay_signature: string;
}

export type PaymentStatus =
  | "idle"
  | "creating-order"
  | "awaiting-payment"
  | "verifying"
  | "success"
  | "error";

export function useRazorpayCheckout() {
  const router = useRouter();
  const [status, setStatus] = useState<PaymentStatus>("idle");
  const [error, setError] = useState<string | null>(null);

  const loadRazorpayScript = (): Promise<boolean> => {
    return new Promise((resolve) => {
      if (window.Razorpay) return resolve(true);
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  const initiatePayment = async () => {
    setStatus("creating-order");
    setError(null);

    try {
      // 1. Load Razorpay SDK
      const loaded = await loadRazorpayScript();
      if (!loaded) {
        throw new Error(
          "Payment SDK failed to load. Please check your connection."
        );
      }

      // 2. Create order on server
      const orderRes = await fetch("/api/payment/create-order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });

      const orderData = await orderRes.json();

      if (!orderRes.ok) {
        if (orderData.code === "ALREADY_ENROLLED") {
          router.push("/dashboard");
          return;
        }
        throw new Error(orderData.message || "Failed to create payment order");
      }

      // 3. Open Razorpay modal
      setStatus("awaiting-payment");

      const options: RazorpayOptions = {
        key: orderData.keyId,
        amount: orderData.amount,
        currency: orderData.currency,
        name: "MBA Communication Dominance",
        description: "30-Day Consulting Transformation Program",
        order_id: orderData.orderId,
        prefill: {
          name: orderData.prefill?.name || "",
          email: orderData.prefill?.email || "",
        },
        notes: { product: "MBA Communication Dominance" },
        theme: { color: "#c9a227" },
        handler: async (response: RazorpaySuccessResponse) => {
          setStatus("verifying");
          await handlePaymentSuccess(response);
        },
        modal: {
          ondismiss: () => {
            setStatus("idle");
          },
          escape: false,
        },
      };

      const rzp = new window.Razorpay(options);
      rzp.open();
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Payment failed. Please try again.";
      setError(message);
      setStatus("error");
    }
  };

  const handlePaymentSuccess = async (
    response: RazorpaySuccessResponse
  ) => {
    try {
      // Verify on server — enrollment happens via webhook,
      // but we do a client-side check to confirm enrollment is active.
      // Give webhook a moment to process.
      await new Promise((r) => setTimeout(r, 1500));

      const enrollRes = await fetch("/api/enrollment");
      const enrollData = await enrollRes.json();

      if (enrollData.enrolled) {
        setStatus("success");
        router.push("/dashboard?welcome=true");
      } else {
        // Webhook may be slightly delayed — redirect anyway, middleware will handle it
        setStatus("success");
        router.push("/dashboard?payment=pending");
      }
    } catch {
      setStatus("success");
      router.push("/dashboard");
    }
  };

  return { initiatePayment, status, error };
}
