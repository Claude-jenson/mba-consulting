export interface User {
  id: string;
  email: string;
  full_name?: string;
  avatar_url?: string;
  created_at: string;
}

export interface UserProgress {
  user_id: string;
  day_number: number;
  completed: boolean;
  score?: number;
  submitted_at?: string;
  feedback?: string;
}

export interface DayModule {
  id: number;
  day_number: number;
  title: string;
  objective: string;
  framework: Framework;
  example: Example;
  gd_prompt: string;
  category: ModuleCategory;
  duration_minutes: number;
  is_locked?: boolean;
}

export interface Framework {
  name: string;
  description: string;
  steps: string[];
}

export interface Example {
  scenario: string;
  application: string;
  output: string;
}

export type ModuleCategory =
  | "foundation"
  | "structure"
  | "influence"
  | "executive"
  | "mastery";

export interface Submission {
  id: string;
  user_id: string;
  day_number: number;
  content: string;
  score?: number;
  feedback?: string;
  submitted_at: string;
}

export interface Certificate {
  id: string;
  user_id: string;
  issued_at: string;
  final_score: number;
  certificate_url: string;
}

export interface NavItem {
  label: string;
  href: string;
  icon?: string;
}
