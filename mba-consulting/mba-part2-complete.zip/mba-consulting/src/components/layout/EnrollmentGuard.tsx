"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";

interface EnrollmentState {
  loading: boolean;
  enrolled: boolean | null;
  error: string | null;
}

export function EnrollmentGuard({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [state, setState] = useState<EnrollmentState>({
    loading: true,
    enrolled: null,
    error: null,
  });

  useEffect(() => {
    fetch("/api/enrollment")
      .then((r) => r.json())
      .then((data) => {
        if (!data.enrolled) {
          router.replace("/pay");
        } else {
          setState({ loading: false, enrolled: true, error: null });
        }
      })
      .catch(() => {
        // On error, let them through (fail open)
        setState({ loading: false, enrolled: true, error: null });
      });
  }, [router]);

  if (state.loading) {
    return (
      <div className="min-h-screen bg-[#0a0f1e] flex items-center justify-center">
        <div className="flex items-center gap-3 text-slate-400">
          <Loader2 className="w-5 h-5 animate-spin text-gold-400" />
          <span className="text-sm">Loading your dashboard...</span>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
