"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface CardProps {
  children: React.ReactNode;
  className?: string;
  accent?: boolean;
  hoverable?: boolean;
  onClick?: () => void;
  glow?: boolean;
}

export function Card({
  children,
  className,
  accent = false,
  hoverable = false,
  onClick,
  glow = false,
}: CardProps) {
  return (
    <motion.div
      onClick={onClick}
      whileHover={hoverable ? { y: -3 } : undefined}
      className={cn(
        "card-premium",
        accent && "card-accent",
        glow && "glow-gold",
        onClick && "cursor-pointer",
        className
      )}
    >
      {children}
    </motion.div>
  );
}

interface CardHeaderProps {
  children: React.ReactNode;
  className?: string;
}

export function CardHeader({ children, className }: CardHeaderProps) {
  return (
    <div className={cn("px-6 pt-6 pb-4", className)}>
      {children}
    </div>
  );
}

export function CardContent({ children, className }: CardHeaderProps) {
  return (
    <div className={cn("px-6 pb-6", className)}>
      {children}
    </div>
  );
}

export function CardFooter({ children, className }: CardHeaderProps) {
  return (
    <div
      className={cn(
        "px-6 py-4 border-t border-gold-500/10",
        className
      )}
    >
      {children}
    </div>
  );
}
