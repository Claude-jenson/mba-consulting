import { cn } from "@/lib/utils";

type BadgeVariant = "locked" | "available" | "current" | "completed" | "gold" | "blue" | "green" | "red";

interface BadgeProps {
  variant?: BadgeVariant;
  children: React.ReactNode;
  className?: string;
  size?: "sm" | "md";
}

export function Badge({
  variant = "gold",
  children,
  className,
  size = "md",
}: BadgeProps) {
  const variants: Record<BadgeVariant, string> = {
    locked: "badge-locked",
    available: "badge-available",
    current: "badge-current",
    completed: "badge-completed",
    gold: "bg-gold-500/10 text-gold-400 border border-gold-500/20",
    blue: "bg-blue-500/10 text-blue-400 border border-blue-500/20",
    green: "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20",
    red: "bg-red-500/10 text-red-400 border border-red-500/20",
  };

  const sizes = {
    sm: "px-2 py-0.5 text-[10px] rounded-md",
    md: "px-2.5 py-1 text-xs rounded-lg",
  };

  return (
    <span
      className={cn(
        "inline-flex items-center font-medium tracking-wide",
        variants[variant],
        sizes[size],
        className
      )}
    >
      {children}
    </span>
  );
}
