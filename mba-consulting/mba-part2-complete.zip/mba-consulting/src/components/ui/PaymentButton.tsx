"use client";

import { motion, AnimatePresence } from "framer-motion";
import {
  CreditCard,
  CheckCircle2,
  Loader2,
  AlertCircle,
  ArrowRight,
} from "lucide-react";
import { useRazorpayCheckout, type PaymentStatus } from "@/lib/payments/use-razorpay";
import { Button } from "@/components/ui/Button";

interface PaymentButtonProps {
  className?: string;
  size?: "md" | "lg" | "xl";
}

const statusConfig: Record<
  PaymentStatus,
  { label: string; icon?: React.ReactNode; disabled: boolean }
> = {
  idle: {
    label: "Get Access — ₹199",
    icon: <ArrowRight className="w-5 h-5" />,
    disabled: false,
  },
  "creating-order": {
    label: "Setting up payment...",
    icon: <Loader2 className="w-4 h-4 animate-spin" />,
    disabled: true,
  },
  "awaiting-payment": {
    label: "Complete in Razorpay...",
    icon: <CreditCard className="w-4 h-4 animate-pulse" />,
    disabled: true,
  },
  verifying: {
    label: "Confirming payment...",
    icon: <Loader2 className="w-4 h-4 animate-spin" />,
    disabled: true,
  },
  success: {
    label: "Payment Successful!",
    icon: <CheckCircle2 className="w-5 h-5" />,
    disabled: true,
  },
  error: {
    label: "Try Again",
    icon: <ArrowRight className="w-5 h-5" />,
    disabled: false,
  },
};

export function PaymentButton({ className, size = "xl" }: PaymentButtonProps) {
  const { initiatePayment, status, error } = useRazorpayCheckout();
  const config = statusConfig[status];

  return (
    <div className="flex flex-col items-center gap-3">
      <Button
        variant={status === "success" ? "secondary" : "gold"}
        size={size}
        className={className}
        onClick={initiatePayment}
        disabled={config.disabled}
        icon={config.icon}
        iconPosition="right"
      >
        {config.label}
      </Button>

      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="flex items-center gap-2 text-sm text-red-400 max-w-sm text-center"
          >
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            {error}
          </motion.div>
        )}
      </AnimatePresence>

      {status === "idle" && (
        <p className="text-xs text-slate-500">
          Secure payment via Razorpay · UPI, cards, net banking · Instant access
        </p>
      )}
    </div>
  );
}
