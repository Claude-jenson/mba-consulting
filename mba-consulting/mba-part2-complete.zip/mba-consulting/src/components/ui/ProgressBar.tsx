"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface ProgressBarProps {
  value: number; // 0–100
  className?: string;
  showLabel?: boolean;
  label?: string;
  color?: "gold" | "blue" | "green";
  size?: "sm" | "md" | "lg";
  animated?: boolean;
}

export function ProgressBar({
  value,
  className,
  showLabel = false,
  label,
  color = "gold",
  size = "md",
  animated = true,
}: ProgressBarProps) {
  const heights = { sm: "h-1", md: "h-1.5", lg: "h-2.5" };

  const fills = {
    gold: "from-gold-700 via-gold-500 to-gold-300",
    blue: "from-blue-700 via-blue-500 to-blue-300",
    green: "from-emerald-700 via-emerald-500 to-emerald-300",
  };

  const clamped = Math.min(100, Math.max(0, value));

  return (
    <div className={cn("w-full", className)}>
      {(showLabel || label) && (
        <div className="flex justify-between items-center mb-2">
          {label && (
            <span className="text-xs font-medium text-slate-400">{label}</span>
          )}
          {showLabel && (
            <span className="text-xs font-semibold text-gold-400">
              {clamped}%
            </span>
          )}
        </div>
      )}
      <div className={cn("progress-track w-full", heights[size])}>
        <motion.div
          className={cn(
            "progress-fill",
            heights[size],
            "bg-gradient-to-r",
            fills[color]
          )}
          initial={animated ? { width: 0 } : { width: `${clamped}%` }}
          animate={{ width: `${clamped}%` }}
          transition={{ duration: 1.2, ease: "easeOut" }}
        />
      </div>
    </div>
  );
}
