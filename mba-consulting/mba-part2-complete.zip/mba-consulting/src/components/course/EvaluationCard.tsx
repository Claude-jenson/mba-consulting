"use client";

import { motion } from "framer-motion";
import {
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  BookOpen,
  Zap,
  Star,
  ArrowRight,
} from "lucide-react";
import Link from "next/link";
import type { EvaluationResult } from "@/lib/ai/evaluator";
import { Button } from "@/components/ui/Button";

interface EvaluationCardProps {
  evaluation: EvaluationResult;
  dayNumber: number;
  nextDay: number | null;
}

const DIMENSION_LABELS: Record<
  keyof Pick<
    EvaluationResult,
    | "clarity"
    | "structure"
    | "logicalDepth"
    | "confidenceProjection"
    | "consultingArticulation"
    | "leadershipSignals"
  >,
  string
> = {
  clarity: "Clarity",
  structure: "Structure",
  logicalDepth: "Logical Depth",
  confidenceProjection: "Confidence",
  consultingArticulation: "Consulting Voice",
  leadershipSignals: "Leadership",
};

function ScoreRing({ score }: { score: number }) {
  const radius = 52;
  const circumference = 2 * Math.PI * radius;
  const filled = (score / 100) * circumference;

  const color =
    score >= 80
      ? "#34d399"
      : score >= 65
      ? "#c9a227"
      : score >= 50
      ? "#60a5fa"
      : "#f87171";

  return (
    <div className="relative w-36 h-36 flex items-center justify-center">
      <svg
        className="absolute inset-0 -rotate-90"
        width="144"
        height="144"
        viewBox="0 0 144 144"
      >
        <circle
          cx="72"
          cy="72"
          r={radius}
          fill="none"
          stroke="rgba(255,255,255,0.06)"
          strokeWidth="8"
        />
        <motion.circle
          cx="72"
          cy="72"
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth="8"
          strokeLinecap="round"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: circumference - filled }}
          transition={{ duration: 1.4, ease: "easeOut", delay: 0.3 }}
        />
      </svg>
      <div className="text-center">
        <motion.div
          className="text-3xl font-black"
          style={{ color }}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5 }}
        >
          {score}
        </motion.div>
        <div className="text-xs text-slate-500 mt-0.5">/100</div>
      </div>
    </div>
  );
}

function DimensionBar({
  label,
  value,
  delay,
}: {
  label: string;
  value: number;
  delay: number;
}) {
  const pct = (value / 5) * 100;
  const color =
    value >= 4 ? "#34d399" : value >= 3 ? "#c9a227" : "#f87171";

  return (
    <div>
      <div className="flex justify-between text-xs mb-1">
        <span className="text-slate-400">{label}</span>
        <span className="font-bold" style={{ color }}>
          {value.toFixed(1)}/5
        </span>
      </div>
      <div className="h-1.5 rounded-full bg-slate-800">
        <motion.div
          className="h-1.5 rounded-full"
          style={{ background: color }}
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.9, ease: "easeOut", delay }}
        />
      </div>
    </div>
  );
}

export function EvaluationCard({
  evaluation,
  dayNumber,
  nextDay,
}: EvaluationCardProps) {
  const dimensions = Object.entries(DIMENSION_LABELS) as Array<
    [keyof typeof DIMENSION_LABELS, string]
  >;

  const scoreLabel =
    evaluation.compositeScore >= 90
      ? "Exceptional — McKinsey standard"
      : evaluation.compositeScore >= 80
      ? "Strong — hire-worthy performance"
      : evaluation.compositeScore >= 65
      ? "Solid — above average, keep refining"
      : evaluation.compositeScore >= 50
      ? "Developing — clear framework needed"
      : "Foundational — significant gaps, keep practicing";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-5"
    >
      {/* Score hero */}
      <div className="card-premium card-accent p-6">
        <div className="flex flex-col sm:flex-row items-center gap-6">
          <ScoreRing score={evaluation.compositeScore} />
          <div className="text-center sm:text-left">
            <div className="text-xs font-semibold text-gold-500/70 uppercase tracking-wider mb-1">
              AI Evaluation Complete
            </div>
            <h3
              className="text-xl font-bold text-slate-100 mb-1"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Day {dayNumber} Score
            </h3>
            <p className="text-slate-400 text-sm">{scoreLabel}</p>

            {evaluation.fillerCount > 0 && (
              <div className="mt-3 flex items-center gap-2 text-amber-400 text-xs bg-amber-400/10 px-3 py-1.5 rounded-lg border border-amber-400/20 w-fit">
                <Zap className="w-3 h-3" />
                {evaluation.fillerCount} filler word{evaluation.fillerCount > 1 ? "s" : ""} detected
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Dimension bars */}
      <div className="card-premium p-6">
        <h4 className="font-semibold text-slate-200 text-sm mb-4 flex items-center gap-2">
          <Star className="w-4 h-4 text-gold-400" />
          Performance by Dimension
        </h4>
        <div className="space-y-3">
          {dimensions.map(([key, label], i) => (
            <DimensionBar
              key={key}
              label={label}
              value={evaluation[key] as number}
              delay={0.1 + i * 0.07}
            />
          ))}
        </div>

        {evaluation.fillerCount > 0 && (
          <div className="mt-4 pt-4 border-t border-slate-800/50">
            <p className="text-xs text-slate-500 font-medium mb-1">
              Filler words found:
            </p>
            <p className="text-xs text-amber-400/80">
              {evaluation.fillerWordsFound.join(" · ")}
            </p>
          </div>
        )}
      </div>

      {/* Strengths */}
      <div className="card-premium p-6">
        <h4 className="font-semibold text-emerald-400 text-sm mb-3 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          Strengths
        </h4>
        <ul className="space-y-2">
          {evaluation.strengths.map((s, i) => (
            <motion.li
              key={i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + i * 0.1 }}
              className="flex items-start gap-2 text-slate-300 text-sm"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 flex-shrink-0" />
              {s}
            </motion.li>
          ))}
        </ul>
      </div>

      {/* Weaknesses */}
      <div className="card-premium p-6">
        <h4 className="font-semibold text-red-400 text-sm mb-3 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4" />
          Areas to Improve
        </h4>
        <ul className="space-y-2">
          {evaluation.weaknesses.map((w, i) => (
            <motion.li
              key={i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + i * 0.1 }}
              className="flex items-start gap-2 text-slate-300 text-sm"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-red-400 mt-1.5 flex-shrink-0" />
              {w}
            </motion.li>
          ))}
        </ul>
      </div>

      {/* Improvement advice */}
      <div className="card-premium p-6">
        <h4 className="font-semibold text-gold-400 text-sm mb-3 flex items-center gap-2">
          <Lightbulb className="w-4 h-4" />
          Coach Advice
        </h4>
        <p className="text-slate-300 text-sm leading-relaxed">
          {evaluation.improvementAdvice}
        </p>
      </div>

      {/* Model answer */}
      <div className="card-premium p-6">
        <h4 className="font-semibold text-blue-400 text-sm mb-3 flex items-center gap-2">
          <BookOpen className="w-4 h-4" />
          Model Answer
        </h4>
        <p className="text-slate-200 text-sm leading-relaxed font-mono bg-blue-500/5 border border-blue-500/15 rounded-xl p-4">
          {evaluation.modelAnswer}
        </p>
      </div>

      {/* CTA */}
      <div className="flex gap-3">
        {nextDay && nextDay <= 30 && (
          <Link href={`/dashboard/day/${nextDay}`} className="flex-1">
            <Button variant="gold" size="lg" className="w-full group">
              Continue to Day {nextDay}
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
        )}
        <Link href="/dashboard">
          <Button variant="secondary" size="lg">
            Dashboard
          </Button>
        </Link>
      </div>
    </motion.div>
  );
}
