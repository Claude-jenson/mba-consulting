"use client";

import { useState, use } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  Clock,
  Target,
  BookOpen,
  Lightbulb,
  MessageSquare,
  Send,
  CheckCircle2,
  Lock,
  ChevronRight,
} from "lucide-react";
import { courseModules, categoryConfig } from "@/data/course-modules";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { getCategoryColor } from "@/lib/utils";

interface PageProps {
  params: Promise<{ id: string }>;
}

export default function DayPage({ params }: PageProps) {
  const { id } = use(params);
  const dayNumber = parseInt(id);
  const [submission, setSubmission] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [activeTab, setActiveTab] = useState<"learn" | "practice">("learn");

  // Mock: days 1-10 completed, day 11 current, rest locked
  const completedDays = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  const currentDay = 11;
  const isCompleted = completedDays.includes(dayNumber);
  const isCurrent = dayNumber === currentDay;
  const isLocked = dayNumber > currentDay && !completedDays.includes(dayNumber);

  const module = courseModules.find((m) => m.day_number === dayNumber);
  const categoryColor = module ? getCategoryColor(module.category) : "#c9a227";
  const categoryLabel =
    module?.category &&
    categoryConfig[module.category as keyof typeof categoryConfig]?.label;

  if (!module) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl font-black text-slate-700 mb-2">Day {dayNumber}</div>
          <p className="text-slate-400">Module not found</p>
          <Link href="/dashboard" className="text-gold-400 hover:underline mt-4 block">
            ← Back to Dashboard
          </Link>
        </div>
      </div>
    );
  }

  if (isLocked) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md w-full text-center"
        >
          <div className="card-premium p-10">
            <div className="w-16 h-16 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center mx-auto mb-6">
              <Lock className="w-8 h-8 text-slate-500" />
            </div>
            <div className="text-4xl font-black text-slate-700 mb-2">
              Day {dayNumber}
            </div>
            <h2 className="text-xl font-bold text-slate-300 mb-2">
              {module.title}
            </h2>
            <p className="text-slate-500 text-sm mb-6">
              Complete Day {currentDay - 1} to unlock this module. 
              Sequential practice builds real skill — don&apos;t skip.
            </p>
            <Link href={`/dashboard/day/${currentDay}`}>
              <Button variant="gold" className="w-full">
                Continue Day {currentDay}
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </motion.div>
      </div>
    );
  }

  const handleSubmit = async () => {
    if (!submission.trim()) return;
    // Part 2 will add AI evaluation here
    setSubmitted(true);
  };

  const tabs = [
    { id: "learn", label: "Learn", icon: BookOpen },
    { id: "practice", label: "Practice", icon: MessageSquare },
  ];

  return (
    <div className="min-h-screen p-4 md:p-8 max-w-4xl mx-auto">
      {/* Back nav */}
      <motion.div
        initial={{ opacity: 0, x: -10 }}
        animate={{ opacity: 1, x: 0 }}
        className="flex items-center gap-3 mb-6"
      >
        <Link
          href="/dashboard"
          className="flex items-center gap-1.5 text-slate-400 hover:text-slate-200 text-sm transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Dashboard
        </Link>
        <ChevronRight className="w-3 h-3 text-slate-600" />
        <span className="text-slate-400 text-sm">
          Day {dayNumber}
        </span>
      </motion.div>

      {/* Module header */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 }}
        className="mb-8"
      >
        <div className="flex flex-wrap items-center gap-3 mb-3">
          <div
            className="px-3 py-1 rounded-full text-xs font-bold"
            style={{
              background: `${categoryColor}15`,
              color: categoryColor,
              border: `1px solid ${categoryColor}30`,
            }}
          >
            Day {dayNumber}
          </div>
          {categoryLabel && (
            <Badge
              className="text-xs"
              style={
                {
                  "--badge-color": categoryColor,
                } as React.CSSProperties
              }
            >
              {categoryLabel}
            </Badge>
          )}
          <div className="flex items-center gap-1 text-xs text-slate-500">
            <Clock className="w-3 h-3" />
            {module.duration_minutes} min
          </div>
          {isCompleted && (
            <Badge variant="completed">
              <CheckCircle2 className="w-3 h-3 mr-1" />
              Completed
            </Badge>
          )}
          {isCurrent && (
            <Badge variant="current">Today&apos;s Module</Badge>
          )}
        </div>

        <h1
          className="text-2xl md:text-3xl font-bold text-slate-100"
          style={{ fontFamily: "var(--font-display)" }}
        >
          {module.title}
        </h1>
        <p className="text-slate-400 mt-2 body-lg text-sm">{module.objective}</p>
      </motion.div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-slate-900/50 rounded-xl border border-slate-800/50 mb-6 w-fit">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as "learn" | "practice")}
            className={`flex items-center gap-2 px-5 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === tab.id
                ? "bg-gold-500/15 text-gold-300 border border-gold-500/20"
                : "text-slate-500 hover:text-slate-300"
            }`}
          >
            <tab.icon className="w-3.5 h-3.5" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* LEARN TAB */}
      {activeTab === "learn" && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Objective */}
          <div className="card-premium card-accent p-6">
            <div className="flex items-center gap-2 mb-4">
              <Target className="w-4 h-4 text-gold-400" />
              <h3 className="font-semibold text-gold-300 text-sm uppercase tracking-wider">
                Objective
              </h3>
            </div>
            <p className="text-slate-200 leading-relaxed">{module.objective}</p>
          </div>

          {/* Framework */}
          <div className="card-premium p-6">
            <div className="flex items-center gap-2 mb-5">
              <Lightbulb className="w-4 h-4 text-gold-400" />
              <h3 className="font-semibold text-slate-200 text-sm uppercase tracking-wider">
                The Framework
              </h3>
            </div>

            <div
              className="inline-flex items-center px-4 py-2 rounded-xl mb-4 text-sm font-bold"
              style={{
                background: `${categoryColor}12`,
                color: categoryColor,
                border: `1px solid ${categoryColor}25`,
              }}
            >
              {module.framework.name}
            </div>

            <p className="text-slate-400 text-sm mb-5">
              {module.framework.description}
            </p>

            <div className="space-y-3">
              {module.framework.steps.map((step, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.08 }}
                  className="flex items-start gap-4"
                >
                  <div
                    className="w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5"
                    style={{
                      background: `${categoryColor}15`,
                      color: categoryColor,
                      border: `1px solid ${categoryColor}25`,
                    }}
                  >
                    {i + 1}
                  </div>
                  <div className="text-slate-300 text-sm pt-1 leading-relaxed">
                    {step}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Example */}
          <div className="card-premium p-6">
            <div className="flex items-center gap-2 mb-5">
              <BookOpen className="w-4 h-4 text-gold-400" />
              <h3 className="font-semibold text-slate-200 text-sm uppercase tracking-wider">
                Worked Example
              </h3>
            </div>

            <div className="space-y-4">
              <div>
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Scenario
                </span>
                <p className="text-slate-300 text-sm mt-1">
                  {module.example.scenario}
                </p>
              </div>
              <div>
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Application
                </span>
                <p className="text-slate-300 text-sm mt-1">
                  {module.example.application}
                </p>
              </div>
              <div className="mt-2 p-4 rounded-xl bg-gold-500/5 border border-gold-500/15">
                <span className="text-xs font-semibold text-gold-500/60 uppercase tracking-wider block mb-2">
                  Model Output
                </span>
                <p className="text-slate-200 text-sm leading-relaxed font-mono">
                  {module.example.output}
                </p>
              </div>
            </div>
          </div>

          <Button
            variant="gold"
            size="lg"
            className="w-full group"
            onClick={() => setActiveTab("practice")}
          >
            Ready to Practice?
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Button>
        </motion.div>
      )}

      {/* PRACTICE TAB */}
      {activeTab === "practice" && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* GD Prompt */}
          <div className="card-premium card-accent p-6">
            <div className="flex items-center gap-2 mb-4">
              <MessageSquare className="w-4 h-4 text-gold-400" />
              <h3 className="font-semibold text-gold-300 text-sm uppercase tracking-wider">
                Today&apos;s GD / PI Simulation
              </h3>
            </div>
            <p className="text-slate-200 leading-relaxed text-sm md:text-base">
              {module.gd_prompt}
            </p>
          </div>

          {/* Submission */}
          {!submitted ? (
            <div className="card-premium p-6">
              <h3 className="font-semibold text-slate-200 mb-2">
                Your Response
              </h3>
              <p className="text-slate-400 text-sm mb-4">
                Write as if you&apos;re actually speaking. Apply the{" "}
                <span className="text-gold-400 font-medium">
                  {module.framework.name}
                </span>{" "}
                framework. Aim for 150–250 words.
              </p>
              <textarea
                value={submission}
                onChange={(e) => setSubmission(e.target.value)}
                placeholder="Type your response here. Be deliberate — this gets evaluated by AI..."
                className="input-premium h-48 resize-none text-sm font-mono leading-relaxed mb-4"
              />
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-500">
                  {submission.trim().split(/\s+/).filter(Boolean).length} words
                  {" · "}
                  {submission.trim().split(/\s+/).filter(Boolean).length < 150 ? (
                    <span className="text-amber-500">
                      Aim for 150+ words
                    </span>
                  ) : (
                    <span className="text-emerald-400">Good length ✓</span>
                  )}
                </span>
                <Button
                  variant="gold"
                  onClick={handleSubmit}
                  disabled={submission.trim().split(/\s+/).filter(Boolean).length < 50}
                  icon={<Send className="w-4 h-4" />}
                  iconPosition="right"
                >
                  Submit for AI Evaluation
                </Button>
              </div>
              <p className="text-xs text-slate-600 mt-3">
                🔒 AI evaluation activates in Part 2 — submission is recorded
              </p>
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              className="card-premium card-accent glow-gold p-8 text-center"
            >
              <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto mb-4" />
              <h3
                className="text-2xl font-bold text-slate-100 mb-2"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Submitted!
              </h3>
              <p className="text-slate-400 text-sm mb-6">
                Your response is logged. AI evaluation will be enabled in the next
                build. Keep the streak going.
              </p>
              <div className="flex gap-3 justify-center">
                {dayNumber < 30 && (
                  <Link href={`/dashboard/day/${dayNumber + 1}`}>
                    <Button variant="gold" size="lg">
                      Day {dayNumber + 1}
                      <ArrowRight className="w-4 h-4" />
                    </Button>
                  </Link>
                )}
                <Link href="/dashboard">
                  <Button variant="secondary" size="lg">
                    Dashboard
                  </Button>
                </Link>
              </div>
            </motion.div>
          )}

          {/* Tips */}
          <div className="card-premium p-5 text-sm text-slate-400">
            <p className="font-semibold text-slate-300 mb-2">
              💡 Evaluation criteria (Part 2)
            </p>
            <ul className="space-y-1 text-xs">
              <li>• Framework application accuracy</li>
              <li>• Argument structure & clarity</li>
              <li>• Vocabulary & professional tone</li>
              <li>• Consulting-grade language markers</li>
              <li>• Evidence usage & specificity</li>
            </ul>
          </div>
        </motion.div>
      )}

      {/* Module navigation */}
      <div className="flex items-center justify-between mt-10 pt-6 border-t border-gold-500/10">
        {dayNumber > 1 ? (
          <Link href={`/dashboard/day/${dayNumber - 1}`}>
            <Button variant="ghost" size="sm" icon={<ArrowLeft className="w-3.5 h-3.5" />}>
              Day {dayNumber - 1}
            </Button>
          </Link>
        ) : (
          <div />
        )}
        {dayNumber < 30 && (
          <Link href={`/dashboard/day/${dayNumber + 1}`}>
            <Button
              variant="ghost"
              size="sm"
              icon={<ArrowRight className="w-3.5 h-3.5" />}
              iconPosition="right"
              disabled={isLocked}
            >
              Day {dayNumber + 1}
            </Button>
          </Link>
        )}
      </div>
    </div>
  );
}
