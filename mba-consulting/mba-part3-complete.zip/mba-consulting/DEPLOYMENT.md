# 🚀 MBA Communication Dominance — Production Deployment Guide

## Prerequisites

- Node.js v20+
- npm v10+
- Supabase account (free tier works)
- Razorpay account (switch to live after testing)
- OpenAI account with GPT-4o access
- Netlify account (free tier works for start)

---

## 1. Supabase Setup

### 1.1 Create Project
1. Go to https://supabase.com → New Project
2. Choose region closest to India (Singapore recommended)
3. Save your DB password securely

### 1.2 Run Migrations
In Supabase Dashboard → SQL Editor → New Query:

```sql
-- Run in order:
-- 1. Paste content of supabase/migrations/001_schema.sql → Run
-- 2. Paste content of supabase/migrations/002_functions.sql → Run
-- 3. Paste content of supabase/migrations/003_certificates_admin.sql → Run
```

### 1.3 Enable Auth Providers
Dashboard → Authentication → Providers:
- Email/Password: ✅ Enable
- Google OAuth: ✅ Enable (add Client ID + Secret from Google Cloud Console)

### 1.4 Set Auth Redirect URL
Dashboard → Authentication → URL Configuration:
- Site URL: `https://your-domain.netlify.app`
- Redirect URLs: Add `https://your-domain.netlify.app/auth/callback`

### 1.5 Get API Keys
Dashboard → Settings → API:
- Copy `Project URL` → `NEXT_PUBLIC_SUPABASE_URL`
- Copy `anon public` key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- Copy `service_role secret` → `SUPABASE_SERVICE_ROLE_KEY`

### 1.6 Add First Admin User
After your first signup, run in SQL Editor:
```sql
INSERT INTO public.admin_users (id, role)
VALUES ('your-user-uuid-from-auth-users-table', 'superadmin');
```

---

## 2. Razorpay Setup

### 2.1 Create Account
- Go to https://razorpay.com → Sign up
- Complete KYC (required for live payments)
- For testing, use Dashboard → Test Mode toggle

### 2.2 Get API Keys
Dashboard → Settings → API Keys:
- Key ID → `RAZORPAY_KEY_ID` + `NEXT_PUBLIC_RAZORPAY_KEY_ID`
- Key Secret → `RAZORPAY_KEY_SECRET`

### 2.3 Configure Webhook
Dashboard → Settings → Webhooks → Add New Webhook:
- URL: `https://your-domain.netlify.app/api/payment/verify-webhook`
- Secret: Create a strong random string → `RAZORPAY_WEBHOOK_SECRET`
- Events: ✅ `payment.captured` ✅ `payment.failed` ✅ `refund.created`

### 2.4 Switch to Live
When ready for real payments:
- Toggle to Live Mode in Razorpay
- Update `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` with live keys
- Update `NEXT_PUBLIC_RAZORPAY_KEY_ID` with live Key ID

---

## 3. OpenAI Setup

1. Go to https://platform.openai.com
2. Create API key → `OPENAI_API_KEY`
3. Add billing (GPT-4o costs ~$0.002 per evaluation)
4. Set usage limit: Dashboard → Billing → Usage limits

Cost estimate:
- 1 evaluation ≈ 800 tokens ≈ $0.002
- 30 evaluations per student ≈ $0.06 per student
- 1,000 students ≈ $60 in OpenAI costs

---

## 4. Netlify Deployment

### 4.1 Initial Deploy (CLI)
```bash
# Install Netlify CLI
npm install -g netlify-cli

# Login
netlify login

# In project root:
netlify init
# → Create & configure a new site
# → Build command: npm run build
# → Publish directory: .next

# Deploy
netlify deploy --prod
```

### 4.2 Set Environment Variables
Netlify Dashboard → Site → Environment variables → Add all:

```
NEXT_PUBLIC_SUPABASE_URL         = https://xxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY    = eyJ...
SUPABASE_SERVICE_ROLE_KEY        = eyJ...
OPENAI_API_KEY                   = sk-...
RAZORPAY_KEY_ID                  = rzp_live_...
RAZORPAY_KEY_SECRET              = ...
NEXT_PUBLIC_RAZORPAY_KEY_ID      = rzp_live_...
RAZORPAY_WEBHOOK_SECRET          = ...
NEXT_PUBLIC_APP_URL              = https://your-domain.netlify.app
NEXT_PUBLIC_APP_NAME             = MBA Communication Dominance
NEXT_PUBLIC_COURSE_PRICE_PAISE   = 19900
AI_CALLS_PER_HOUR                = 10
PAYMENT_ORDERS_PER_HOUR          = 5
```

### 4.3 Install Next.js Plugin
Netlify Dashboard → Plugins → Search "Next.js" → Install `@netlify/plugin-nextjs`

### 4.4 Custom Domain (optional)
Netlify → Domain Management → Add custom domain
Update DNS at registrar → CNAME record → your-site.netlify.app

---

## 5. Production Checklist

### Before Go-Live

**Infrastructure**
- [ ] All 3 SQL migrations run successfully
- [ ] Supabase RLS policies verified (test with non-admin user)
- [ ] Admin user added to admin_users table
- [ ] Razorpay live keys configured
- [ ] Webhook registered with correct secret
- [ ] OpenAI API key has sufficient credits
- [ ] All env vars set in Netlify

**Security**
- [ ] SUPABASE_SERVICE_ROLE_KEY is NOT in any client-side code
- [ ] Admin route (/admin) inaccessible to non-admin users
- [ ] Webhook signature verification working
- [ ] Rate limiting tested

**Payments**
- [ ] Test payment flow with Razorpay test cards
- [ ] Verify enrollment created after successful payment
- [ ] Test webhook with ngrok before going live
- [ ] Payment failure handled gracefully

**AI Evaluation**
- [ ] Test submission on Day 1 returns scores
- [ ] OpenAI rate limit not exceeded in testing
- [ ] Filler word detection working
- [ ] Weekly report generates after Day 7

**Certificate**
- [ ] Test PDF generation for a completed student
- [ ] QR code scans correctly to /verify
- [ ] Verification page shows correct data
- [ ] LinkedIn share text is accurate

**Performance**
- [ ] Lighthouse score > 85 on landing page
- [ ] Images use next/image with lazy loading
- [ ] Fonts loaded with display: swap
- [ ] Static assets cached for 1 year

---

## 6. Backup Instructions

### 6.1 Database Backup
Supabase Dashboard → Database → Backups:
- Automatic daily backups (enabled by default on Pro plan)
- For free plan, manually export:

```sql
-- Export all tables via pg_dump
-- Or use Supabase CLI:
supabase db dump -f backup_$(date +%Y%m%d).sql
```

### 6.2 Code Backup
```bash
# Push to GitHub (do this before deployment)
git init
git add .
git commit -m "Initial production deployment"
git remote add origin https://github.com/yourname/mba-consulting.git
git push -u origin main
```

### 6.3 Environment Variables Backup
Export from Netlify → Environment Variables → export and store in a secure password manager (not Git).

---

## 7. Post-Launch Monitoring

### Check Weekly
- Supabase → Database → Table sizes (watch for growth)
- OpenAI → Usage dashboard (monitor costs)
- Razorpay → Payments dashboard (refunds, failures)
- Netlify → Analytics (traffic, errors)

### Supabase Rate Limits (Free Tier)
| Resource       | Free Limit     | Monitor When   |
|----------------|----------------|----------------|
| DB size        | 500 MB         | > 300 MB       |
| Monthly egress | 5 GB           | > 3 GB         |
| Monthly active users | 50,000   | > 40,000       |

**Upgrade to Supabase Pro ($25/mo) when**: > 300 MB data or > 40k MAU

---

## 8. Final Project Structure

```
mba-consulting/
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── certificate/generate/     # PDF generation + final eval
│   │   │   ├── certificate/verify/       # Public QR verification
│   │   │   ├── enrollment/               # Check course access
│   │   │   ├── leaderboard/              # Student rankings
│   │   │   ├── payment/create-order/     # Razorpay order
│   │   │   ├── payment/verify-webhook/   # Razorpay webhook
│   │   │   ├── progress/                 # User progress state
│   │   │   ├── submissions/              # Submit + AI evaluate
│   │   │   ├── weekly-report/            # Weekly summaries
│   │   │   └── admin/
│   │   │       ├── approve-certificate/
│   │   │       ├── curriculum/
│   │   │       ├── export-csv/
│   │   │       ├── payments/
│   │   │       ├── scores/
│   │   │       └── students/
│   │   ├── admin/                        # Admin panel UI
│   │   │   ├── certificates/
│   │   │   ├── curriculum/
│   │   │   ├── students/
│   │   │   ├── layout.tsx
│   │   │   └── page.tsx
│   │   ├── auth/login/ register/         # Auth pages
│   │   ├── dashboard/                    # Main app
│   │   │   ├── certificate/              # Certificate page
│   │   │   ├── day/[id]/                 # Daily module + AI eval
│   │   │   ├── leaderboard/
│   │   │   ├── modules/
│   │   │   ├── performance/
│   │   │   ├── settings/
│   │   │   └── layout.tsx
│   │   ├── pay/                          # Payment/paywall page
│   │   ├── verify/                       # Public cert verification
│   │   ├── layout.tsx                    # Root layout + SEO
│   │   └── page.tsx                      # Landing page
│   ├── components/
│   │   ├── admin/
│   │   ├── certificate/EvaluationCard    # AI score results UI
│   │   ├── layout/EnrollmentGuard        # Dashboard paywall
│   │   └── ui/Button Badge Card PaymentButton ProgressBar
│   ├── data/course-modules.ts            # 30 day curriculum
│   ├── lib/
│   │   ├── ai/evaluator.ts              # OpenAI GPT-4o evaluation
│   │   ├── ai/weekly-report-trigger.ts  # Auto weekly reports
│   │   ├── admin/auth.ts                # Admin role guard
│   │   ├── certificate/
│   │   │   ├── final-evaluation.ts      # Day 30 grade computation
│   │   │   └── pdf-generator.ts         # pdf-lib certificate
│   │   ├── db/operations.ts             # All DB helpers
│   │   ├── hooks/use-submission.ts      # Submission React hook
│   │   ├── payments/
│   │   │   ├── razorpay.ts             # Razorpay utils
│   │   │   └── use-razorpay.ts         # Client checkout hook
│   │   ├── security/
│   │   │   ├── auth-guard.ts           # requireEnrolledUser
│   │   │   └── rate-limit.ts           # Sliding window limiter
│   │   └── supabase/
│   │       ├── admin.ts                # Service role client
│   │       ├── client.ts               # Browser client
│   │       ├── middleware.ts           # Route auth
│   │       └── server.ts               # Server client
│   ├── styles/globals.css
│   └── types/index.ts
├── supabase/migrations/
│   ├── 001_schema.sql                   # All tables, RLS, indexes
│   ├── 002_functions.sql                # Rate limit fn, policies
│   └── 003_certificates_admin.sql       # Certs, admin, leaderboard
├── public/manifest.json
├── .env.local.example
├── netlify.toml
├── next.config.js
├── package.json
├── DEPLOYMENT.md                        # This file
├── TESTING_PART2.md                     # API testing guide
└── README.md
```

---

## 9. Tech Stack Summary

| Layer            | Technology                        |
|------------------|-----------------------------------|
| Frontend         | Next.js 14, TypeScript, Tailwind CSS |
| Animation        | Framer Motion                     |
| Auth + DB        | Supabase (PostgreSQL + RLS)        |
| AI Evaluation    | OpenAI GPT-4o                     |
| Payments         | Razorpay                          |
| PDF Generation   | pdf-lib + qrcode                  |
| Deployment       | Netlify + @netlify/plugin-nextjs  |
| Charts           | Recharts                          |
| Icons            | Lucide React                      |

**Estimated Monthly Cost at 100 Active Students**
- Supabase Free: $0
- Netlify Free: $0
- OpenAI GPT-4o: ~$6 (30 evals × 100 students × $0.002)
- Razorpay: 2% per transaction (~₹4 per ₹199 payment)
- **Total: ~$6/month + payment fees**
