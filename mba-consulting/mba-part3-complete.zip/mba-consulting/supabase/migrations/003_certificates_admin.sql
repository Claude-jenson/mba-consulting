-- ============================================================
-- Migration 003: Certificates, Admin Roles, Final Evaluation
-- Run AFTER 001_schema.sql and 002_functions.sql
-- ============================================================

-- ─────────────────────────────────────────────
-- 1. ADMIN ROLES
-- ─────────────────────────────────────────────
create table if not exists public.admin_users (
  id         uuid        primary key references auth.users(id) on delete cascade,
  role       text        not null default 'admin' check (role in ('admin', 'superadmin')),
  added_by   uuid        references auth.users(id),
  created_at timestamptz default now()
);

-- RLS: only admins can see admin_users
alter table public.admin_users enable row level security;

create policy "admin_users_select"
  on public.admin_users for select
  using (auth.uid() = id);

-- ─────────────────────────────────────────────
-- 2. CERTIFICATES
-- ─────────────────────────────────────────────
create table if not exists public.certificates (
  id                uuid        primary key default gen_random_uuid(),
  user_id           uuid        not null unique references auth.users(id) on delete cascade,
  student_id        text        not null,
  verification_id   text        not null unique,   -- short public ID, e.g. MBAC-CERT-A3K9
  issued_at         timestamptz default now(),

  -- Evaluation snapshot
  final_score       numeric(5,1) not null,
  baseline_score    numeric(5,1),
  growth_pct        numeric(5,1),
  grade             text        not null check (grade in ('A', 'B', 'C')),

  -- Approval
  auto_approved     boolean     default false,      -- true if score >= 75
  manually_approved boolean     default false,
  approved_by       uuid        references auth.users(id),
  approved_at       timestamptz,

  -- Counts
  days_completed    integer     not null default 30,
  total_submissions integer     not null default 30
);

create index if not exists idx_certificates_user        on public.certificates(user_id);
create index if not exists idx_certificates_verification on public.certificates(verification_id);

alter table public.certificates enable row level security;

create policy "certificates_select_own"
  on public.certificates for select
  using (auth.uid() = user_id);

-- Service role writes
create policy "certificates_service_all"
  on public.certificates for all
  using (true) with check (true);

-- ─────────────────────────────────────────────
-- 3. FINAL EVALUATION RESULTS
-- ─────────────────────────────────────────────
create table if not exists public.final_evaluations (
  id                uuid        primary key default gen_random_uuid(),
  user_id           uuid        not null unique references auth.users(id) on delete cascade,
  completed_at      timestamptz default now(),

  -- Score analytics
  final_score       numeric(5,1),
  baseline_score    numeric(5,1),
  growth_pct        numeric(5,1),
  grade             text,
  certificate_unlocked boolean   default false,

  -- Category final scores
  category_scores   jsonb,
  best_category     text,
  weakest_category  text,

  -- Dimension averages (across all 30 days)
  avg_clarity             numeric(3,1),
  avg_structure           numeric(3,1),
  avg_logical_depth       numeric(3,1),
  avg_confidence          numeric(3,1),
  avg_consulting          numeric(3,1),
  avg_leadership          numeric(3,1),

  -- Progression
  score_trajectory  jsonb  -- [{day, score}]
);

alter table public.final_evaluations enable row level security;
create policy "final_eval_own" on public.final_evaluations for select using (auth.uid() = user_id);
create policy "final_eval_service" on public.final_evaluations for all using (true) with check (true);

-- ─────────────────────────────────────────────
-- 4. LEADERBOARD VIEW (materialized for performance)
-- ─────────────────────────────────────────────
create or replace view public.leaderboard as
  select
    p.id                            as user_id,
    p.full_name,
    p.student_id,
    p.college,
    count(distinct up.day_number)   as days_completed,
    round(avg(s.composite_score), 1)as avg_score,
    max(s.composite_score)          as best_score,
    public.get_streak(p.id)         as current_streak,
    e.enrolled_at,
    -- Rank composite: 60% avg_score + 40% completion speed
    round(
      (coalesce(avg(s.composite_score), 0) * 0.6) +
      (count(distinct up.day_number) / 30.0 * 100 * 0.4)
    , 1) as rank_score
  from public.profiles p
  inner join public.enrollments e on e.user_id = p.id and e.is_active = true
  left join public.user_progress up on up.user_id = p.id and up.completed = true
  left join public.scores s on s.user_id = p.id
  group by p.id, p.full_name, p.student_id, p.college, e.enrolled_at
  order by rank_score desc;

-- ─────────────────────────────────────────────
-- 5. CURRICULUM (editable by admin)
-- ─────────────────────────────────────────────
create table if not exists public.curriculum_overrides (
  id          uuid        primary key default gen_random_uuid(),
  day_number  integer     not null unique check (day_number between 1 and 30),
  title       text,
  objective   text,
  gd_prompt   text,
  is_active   boolean     default true,
  updated_by  uuid        references auth.users(id),
  updated_at  timestamptz default now()
);

alter table public.curriculum_overrides enable row level security;
create policy "curriculum_service" on public.curriculum_overrides for all using (true) with check (true);

-- ─────────────────────────────────────────────
-- 6. HELPER: Generate verification ID
-- ─────────────────────────────────────────────
create or replace function public.generate_verification_id()
returns text
language plpgsql
as $$
declare
  chars text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  result text := 'MBAC-CERT-';
  i integer;
begin
  for i in 1..6 loop
    result := result || substr(chars, floor(random() * length(chars) + 1)::integer, 1);
  end loop;
  return result;
end;
$$;

-- ─────────────────────────────────────────────
-- 7. HELPER: Check if user is admin
-- ─────────────────────────────────────────────
create or replace function public.is_admin(p_user_id uuid)
returns boolean
language sql
stable
security definer
as $$
  select exists (
    select 1 from public.admin_users
    where id = p_user_id
  );
$$;
