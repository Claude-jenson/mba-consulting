import { NextRequest, NextResponse } from "next/server";
import { requireEnrolledUser } from "@/lib/security/auth-guard";
import { createAdminClient } from "@/lib/supabase/admin";
import { generateCertificatePDF } from "@/lib/certificate/pdf-generator";
import { computeFinalEvaluation, getCertificateRecord } from "@/lib/certificate/final-evaluation";

export const maxDuration = 30;

export async function POST(request: NextRequest) {
  const { user, error: authError } = await requireEnrolledUser(request);
  if (authError) return authError;

  const supabase = createAdminClient();

  try {
    // Check if final evaluation already exists or compute it
    let certRecord = await getCertificateRecord(user!.id);

    if (!certRecord) {
      // Trigger final evaluation (creates cert record if eligible)
      const evaluation = await computeFinalEvaluation(user!.id);

      if (!evaluation.certificateUnlocked) {
        return NextResponse.json(
          {
            error: "Certificate not yet unlocked",
            message: `You need a final score of 75+ and at least 25 days completed. Current: ${evaluation.finalScore}/100, ${evaluation.daysCompleted} days.`,
            finalScore: evaluation.finalScore,
            daysCompleted: evaluation.daysCompleted,
            grade: evaluation.grade,
          },
          { status: 403 }
        );
      }

      certRecord = await getCertificateRecord(user!.id);
    }

    if (!certRecord) {
      return NextResponse.json(
        { error: "Certificate not found after evaluation" },
        { status: 500 }
      );
    }

    // Check if manually approved (for borderline cases)
    const isApproved = certRecord.auto_approved || certRecord.manually_approved;
    if (!isApproved) {
      return NextResponse.json(
        {
          error: "Certificate pending admin approval",
          message: "Your certificate is under review. You'll be notified once approved.",
          code: "PENDING_APPROVAL",
        },
        { status: 403 }
      );
    }

    // Get user profile for name
    const { data: profile } = await supabase
      .from("profiles")
      .select("full_name")
      .eq("id", user!.id)
      .single();

    const studentName = profile?.full_name || "Valued Student";

    // Format issue date
    const issuedDate = new Date(certRecord.issued_at).toLocaleDateString("en-IN", {
      day: "numeric",
      month: "long",
      year: "numeric",
    });

    // Generate PDF
    const pdfBytes = await generateCertificatePDF(
      {
        studentName,
        studentId: certRecord.student_id,
        verificationId: certRecord.verification_id,
        issuedDate,
        finalScore: certRecord.final_score,
        grade: certRecord.grade,
        growthPct: certRecord.growth_pct,
      },
      process.env.NEXT_PUBLIC_APP_URL || "https://mba-comm.netlify.app"
    );

    // Stream PDF as download
    const safeFileName = studentName
      .replace(/[^a-zA-Z0-9 ]/g, "")
      .replace(/\s+/g, "_");

    return new NextResponse(pdfBytes, {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="MBA_Certificate_${safeFileName}.pdf"`,
        "Content-Length": pdfBytes.length.toString(),
        "Cache-Control": "private, no-store",
      },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "PDF generation failed";
    console.error("[/api/certificate/generate]", message);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  const { user, error: authError } = await requireEnrolledUser(request);
  if (authError) return authError;

  const certRecord = await getCertificateRecord(user!.id);

  if (!certRecord) {
    // Check if eligible
    const supabase = createAdminClient();
    const { count } = await supabase
      .from("user_progress")
      .select("*", { count: "exact", head: true })
      .eq("user_id", user!.id)
      .eq("completed", true);

    return NextResponse.json({
      hasCertificate: false,
      daysCompleted: count || 0,
      canGenerate: (count || 0) >= 25,
    });
  }

  return NextResponse.json({
    hasCertificate: true,
    isApproved: certRecord.auto_approved || certRecord.manually_approved,
    verificationId: certRecord.verification_id,
    grade: certRecord.grade,
    finalScore: certRecord.final_score,
    issuedAt: certRecord.issued_at,
    studentId: certRecord.student_id,
  });
}
