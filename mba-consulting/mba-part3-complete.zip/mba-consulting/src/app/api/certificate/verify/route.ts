import { NextRequest, NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";

/**
 * GET /api/certificate/verify?id=MBAC-CERT-A3K9
 * Public endpoint — no auth required.
 * Used by QR code scanner and /verify page.
 */
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const verificationId = searchParams.get("id")?.trim().toUpperCase();

  if (!verificationId || !/^MBAC-CERT-[A-Z0-9]{6}$/.test(verificationId)) {
    return NextResponse.json(
      { valid: false, error: "Invalid verification ID format" },
      { status: 400 }
    );
  }

  const supabase = createAdminClient();

  const { data: cert, error } = await supabase
    .from("certificates")
    .select(
      `id, verification_id, student_id, issued_at,
       final_score, grade, growth_pct, days_completed,
       auto_approved, manually_approved,
       profiles!certificates_user_id_fkey(full_name, college)`
    )
    .eq("verification_id", verificationId)
    .maybeSingle();

  if (error) {
    console.error("[verify]", error.message);
    return NextResponse.json({ valid: false, error: "Lookup failed" }, { status: 500 });
  }

  if (!cert) {
    return NextResponse.json({ valid: false, error: "Certificate not found" }, { status: 404 });
  }

  const isApproved = cert.auto_approved || cert.manually_approved;

  if (!isApproved) {
    return NextResponse.json(
      { valid: false, error: "Certificate is pending approval" },
      { status: 403 }
    );
  }

  // Return public-safe info only
  return NextResponse.json({
    valid: true,
    verificationId: cert.verification_id,
    studentId: cert.student_id,
    studentName: (cert as Record<string, unknown> & { profiles?: { full_name?: string } }).profiles?.full_name || "Verified Student",
    college: (cert as Record<string, unknown> & { profiles?: { college?: string } }).profiles?.college || null,
    issuedAt: cert.issued_at,
    finalScore: cert.final_score,
    grade: cert.grade,
    daysCompleted: cert.days_completed,
    courseName: "MBA Communication Dominance — 30-Day Consulting Transformation",
  });
}
