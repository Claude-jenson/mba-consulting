import { NextRequest, NextResponse } from "next/server";
import { getAuthUser } from "@/lib/security/auth-guard";
import { createAdminClient } from "@/lib/supabase/admin";

export async function GET(request: NextRequest) {
  // Public-ish: requires login but not enrollment (so users can preview)
  const user = await getAuthUser();
  if (!user) {
    return NextResponse.json({ error: "Login required" }, { status: 401 });
  }

  const { searchParams } = new URL(request.url);
  const sortBy = searchParams.get("sort") || "rank_score"; // rank_score | avg_score | days_completed | current_streak
  const limit  = Math.min(parseInt(searchParams.get("limit") || "50"), 100);

  const supabase = createAdminClient();

  const allowedSorts = ["rank_score", "avg_score", "days_completed", "current_streak"];
  const safeSort = allowedSorts.includes(sortBy) ? sortBy : "rank_score";

  // Use the leaderboard view
  const { data, error } = await supabase
    .from("leaderboard")
    .select("*")
    .order(safeSort, { ascending: false })
    .limit(limit);

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  // Find current user's rank
  const currentUserRank =
    (data || []).findIndex((entry) => entry.user_id === user.id) + 1;

  // Anonymise entries slightly — only show initials for non-current users
  const leaderboard = (data || []).map((entry, i) => ({
    rank: i + 1,
    isCurrentUser: entry.user_id === user.id,
    displayName:
      entry.user_id === user.id
        ? entry.full_name || "You"
        : anonymiseName(entry.full_name || ""),
    studentId: entry.student_id,
    college: entry.college || "—",
    daysCompleted: entry.days_completed,
    avgScore: entry.avg_score,
    bestScore: entry.best_score,
    currentStreak: entry.current_streak,
    rankScore: entry.rank_score,
    enrolledAt: entry.enrolled_at,
  }));

  return NextResponse.json({
    leaderboard,
    currentUserRank: currentUserRank || null,
    total: data?.length || 0,
    sortedBy: safeSort,
  });
}

function anonymiseName(name: string): string {
  const parts = name.trim().split(" ");
  if (parts.length === 0 || !parts[0]) return "Student";
  if (parts.length === 1) return parts[0][0].toUpperCase() + "***";
  return `${parts[0]} ${parts[parts.length - 1][0].toUpperCase()}.`;
}
