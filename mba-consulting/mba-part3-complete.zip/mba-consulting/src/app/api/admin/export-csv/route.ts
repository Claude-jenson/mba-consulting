import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin/auth";
import { createAdminClient } from "@/lib/supabase/admin";

function escapeCSV(val: unknown): string {
  if (val === null || val === undefined) return "";
  const str = String(val);
  if (str.includes(",") || str.includes('"') || str.includes("\n")) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

function toCSVRow(values: unknown[]): string {
  return values.map(escapeCSV).join(",");
}

export async function GET(request: NextRequest) {
  const { error } = await requireAdmin();
  if (error) return error;

  const { searchParams } = new URL(request.url);
  const type = searchParams.get("type") || "students"; // students | scores | payments

  const supabase = createAdminClient();
  let csvRows: string[] = [];

  if (type === "students") {
    const { data } = await supabase
      .from("profiles")
      .select(`
        id, full_name, email, college, student_id, created_at,
        enrollments!left(is_active, enrolled_at, amount_paid)
      `)
      .order("created_at", { ascending: false });

    csvRows = [
      toCSVRow(["Student ID", "Full Name", "Email", "College", "Registered At", "Enrolled", "Enrolled At", "Amount Paid (₹)"]),
      ...(data || []).map((s) => {
        const enrollment = Array.isArray(s.enrollments) ? s.enrollments[0] : s.enrollments;
        return toCSVRow([
          s.student_id, s.full_name, s.email, s.college,
          s.created_at, enrollment?.is_active ? "Yes" : "No",
          enrollment?.enrolled_at || "",
          enrollment?.amount_paid ? (enrollment.amount_paid / 100).toFixed(2) : "",
        ]);
      }),
    ];
  } else if (type === "scores") {
    const { data } = await supabase
      .from("scores")
      .select(`
        day_number, composite_score, clarity, structure,
        logical_depth, confidence_projection, consulting_articulation,
        leadership_signals, word_economy_score, filler_count, evaluated_at,
        profiles!scores_user_id_fkey(full_name, student_id)
      `)
      .order("evaluated_at", { ascending: false });

    csvRows = [
      toCSVRow([
        "Student ID", "Name", "Day", "Composite Score",
        "Clarity", "Structure", "Logical Depth", "Confidence",
        "Consulting", "Leadership", "Word Economy", "Fillers", "Evaluated At",
      ]),
      ...(data || []).map((s) => {
        const profile = s.profiles as { student_id?: string; full_name?: string } | null;
        return toCSVRow([
          profile?.student_id, profile?.full_name,
          s.day_number, s.composite_score,
          s.clarity, s.structure, s.logical_depth, s.confidence_projection,
          s.consulting_articulation, s.leadership_signals,
          s.word_economy_score, s.filler_count, s.evaluated_at,
        ]);
      }),
    ];
  } else if (type === "payments") {
    const { data } = await supabase
      .from("payments")
      .select(`
        razorpay_order_id, razorpay_payment_id, amount_paise,
        currency, status, created_at, verified_at,
        profiles!payments_user_id_fkey(full_name, email, student_id)
      `)
      .order("created_at", { ascending: false });

    csvRows = [
      toCSVRow([
        "Student ID", "Name", "Email",
        "Order ID", "Payment ID", "Amount (₹)", "Currency",
        "Status", "Created At", "Verified At",
      ]),
      ...(data || []).map((p) => {
        const profile = p.profiles as { student_id?: string; full_name?: string; email?: string } | null;
        return toCSVRow([
          profile?.student_id, profile?.full_name, profile?.email,
          p.razorpay_order_id, p.razorpay_payment_id || "",
          (p.amount_paise / 100).toFixed(2), p.currency,
          p.status, p.created_at, p.verified_at || "",
        ]);
      }),
    ];
  }

  const csv = csvRows.join("\n");
  const filename = `mbac_${type}_${new Date().toISOString().split("T")[0]}.csv`;

  return new NextResponse(csv, {
    status: 200,
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${filename}"`,
    },
  });
}
