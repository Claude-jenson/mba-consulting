import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin/auth";
import { createAdminClient } from "@/lib/supabase/admin";

export async function GET(request: NextRequest) {
  const { error } = await requireAdmin();
  if (error) return error;

  const { searchParams } = new URL(request.url);
  const userId   = searchParams.get("userId");
  const dayNumber = searchParams.get("day");
  const limit    = parseInt(searchParams.get("limit") || "100");

  const supabase = createAdminClient();

  let query = supabase
    .from("scores")
    .select(
      `id, user_id, day_number, composite_score,
       clarity, structure, logical_depth, confidence_projection,
       consulting_articulation, leadership_signals,
       filler_count, word_economy_score, evaluated_at,
       profiles!scores_user_id_fkey(full_name, student_id, college)`
    )
    .order("evaluated_at", { ascending: false })
    .limit(limit);

  if (userId) query = query.eq("user_id", userId);
  if (dayNumber) query = query.eq("day_number", parseInt(dayNumber));

  const { data, error: dbError } = await query;
  if (dbError) return NextResponse.json({ error: dbError.message }, { status: 500 });

  return NextResponse.json({ scores: data || [] });
}
