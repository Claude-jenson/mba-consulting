import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin/auth";
import { createAdminClient } from "@/lib/supabase/admin";

export async function GET(request: NextRequest) {
  const { error } = await requireAdmin();
  if (error) return error;

  const { searchParams } = new URL(request.url);
  const status = searchParams.get("status"); // created | paid | failed | refunded
  const limit  = parseInt(searchParams.get("limit") || "100");

  const supabase = createAdminClient();

  let query = supabase
    .from("payments")
    .select(
      `id, razorpay_order_id, razorpay_payment_id,
       amount_paise, currency, status, created_at, verified_at,
       profiles!payments_user_id_fkey(full_name, email, student_id)`
    )
    .order("created_at", { ascending: false })
    .limit(limit);

  if (status) query = query.eq("status", status);

  const { data, error: dbError } = await query;
  if (dbError) return NextResponse.json({ error: dbError.message }, { status: 500 });

  // Compute revenue summary
  const paid = (data || []).filter((p) => p.status === "paid");
  const totalRevenue = paid.reduce((sum, p) => sum + p.amount_paise, 0);

  return NextResponse.json({
    payments: data || [],
    summary: {
      totalRevenue: totalRevenue / 100, // rupees
      totalPaid: paid.length,
      totalFailed: (data || []).filter((p) => p.status === "failed").length,
      totalRefunded: (data || []).filter((p) => p.status === "refunded").length,
    },
  });
}
