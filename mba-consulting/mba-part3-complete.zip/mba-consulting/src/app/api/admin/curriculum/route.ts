import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin/auth";
import { createAdminClient } from "@/lib/supabase/admin";

export async function GET(request: NextRequest) {
  const { error } = await requireAdmin();
  if (error) return error;

  const supabase = createAdminClient();
  const { data } = await supabase
    .from("curriculum_overrides")
    .select("*")
    .order("day_number");

  return NextResponse.json({ overrides: data || [] });
}

export async function PUT(request: NextRequest) {
  const { user, error } = await requireAdmin();
  if (error) return error;

  let body: {
    dayNumber: number;
    title?: string;
    objective?: string;
    gdPrompt?: string;
    isActive?: boolean;
  };

  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid body" }, { status: 400 });
  }

  if (!body.dayNumber || body.dayNumber < 1 || body.dayNumber > 30) {
    return NextResponse.json({ error: "dayNumber must be 1–30" }, { status: 400 });
  }

  const supabase = createAdminClient();

  const { data, error: dbError } = await supabase
    .from("curriculum_overrides")
    .upsert(
      {
        day_number: body.dayNumber,
        title: body.title,
        objective: body.objective,
        gd_prompt: body.gdPrompt,
        is_active: body.isActive ?? true,
        updated_by: user!.id,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "day_number" }
    )
    .select()
    .single();

  if (dbError) {
    return NextResponse.json({ error: dbError.message }, { status: 500 });
  }

  return NextResponse.json({ success: true, override: data });
}

export async function DELETE(request: NextRequest) {
  const { error } = await requireAdmin();
  if (error) return error;

  const { searchParams } = new URL(request.url);
  const dayNumber = parseInt(searchParams.get("day") || "0");

  if (!dayNumber) return NextResponse.json({ error: "Missing day" }, { status: 400 });

  const supabase = createAdminClient();
  await supabase.from("curriculum_overrides").delete().eq("day_number", dayNumber);

  return NextResponse.json({ success: true });
}
