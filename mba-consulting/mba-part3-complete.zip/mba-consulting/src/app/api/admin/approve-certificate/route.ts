import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin/auth";
import { createAdminClient } from "@/lib/supabase/admin";

export async function POST(request: NextRequest) {
  const { user, error } = await requireAdmin();
  if (error) return error;

  let body: { userId: string; approved: boolean; reason?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid body" }, { status: 400 });
  }

  const supabase = createAdminClient();

  if (body.approved) {
    // Ensure certificate record exists (create if missing for manual override)
    const { data: existing } = await supabase
      .from("certificates")
      .select("id")
      .eq("user_id", body.userId)
      .maybeSingle();

    if (!existing) {
      // Create cert record for admin-approved student
      const { data: profile } = await supabase
        .from("profiles")
        .select("student_id")
        .eq("id", body.userId)
        .single();

      const { data: scores } = await supabase
        .from("scores")
        .select("composite_score")
        .eq("user_id", body.userId);

      const avgScore = scores?.length
        ? parseFloat((scores.reduce((s, r) => s + (r.composite_score || 0), 0) / scores.length).toFixed(1))
        : 0;

      const { data: verificationId } = await supabase.rpc("generate_verification_id");

      await supabase.from("certificates").insert({
        user_id: body.userId,
        student_id: profile?.student_id || "MBAC-ADMIN",
        verification_id: verificationId,
        final_score: avgScore,
        grade: avgScore >= 85 ? "A" : avgScore >= 75 ? "B" : "C",
        days_completed: scores?.length || 0,
        total_submissions: scores?.length || 0,
        auto_approved: false,
        manually_approved: true,
        approved_by: user!.id,
        approved_at: new Date().toISOString(),
      });
    } else {
      // Update existing cert
      await supabase
        .from("certificates")
        .update({
          manually_approved: true,
          approved_by: user!.id,
          approved_at: new Date().toISOString(),
        })
        .eq("user_id", body.userId);
    }

    return NextResponse.json({ success: true, approved: true });
  } else {
    // Revoke approval
    await supabase
      .from("certificates")
      .update({ manually_approved: false, auto_approved: false, approved_by: user!.id })
      .eq("user_id", body.userId);

    return NextResponse.json({ success: true, approved: false });
  }
}
