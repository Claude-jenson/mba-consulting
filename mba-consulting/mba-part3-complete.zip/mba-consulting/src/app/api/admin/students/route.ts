import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin/auth";
import { createAdminClient } from "@/lib/supabase/admin";

export async function GET(request: NextRequest) {
  const { error } = await requireAdmin();
  if (error) return error;

  const { searchParams } = new URL(request.url);
  const page  = parseInt(searchParams.get("page") || "1");
  const limit = parseInt(searchParams.get("limit") || "50");
  const search = searchParams.get("search") || "";
  const offset = (page - 1) * limit;

  const supabase = createAdminClient();

  let query = supabase
    .from("profiles")
    .select(
      `id, full_name, email, college, student_id, created_at,
       enrollments!left(is_active, enrolled_at, amount_paid),
       user_progress!left(day_number, completed, composite_score)`,
      { count: "exact" }
    )
    .order("created_at", { ascending: false })
    .range(offset, offset + limit - 1);

  if (search) {
    query = query.or(
      `full_name.ilike.%${search}%,email.ilike.%${search}%,student_id.ilike.%${search}%`
    );
  }

  const { data, count, error: dbError } = await query;

  if (dbError) {
    return NextResponse.json({ error: dbError.message }, { status: 500 });
  }

  // Compute per-student stats
  const students = (data || []).map((student) => {
    const progress = Array.isArray(student.user_progress) ? student.user_progress : [];
    const completed = progress.filter((p: { completed: boolean }) => p.completed);
    const scores = completed
      .filter((p: { composite_score: number | null }) => p.composite_score)
      .map((p: { composite_score: number }) => p.composite_score);

    const avgScore =
      scores.length > 0
        ? Math.round(scores.reduce((a: number, b: number) => a + b, 0) / scores.length)
        : 0;

    const enrollment = Array.isArray(student.enrollments)
      ? student.enrollments[0]
      : student.enrollments;

    return {
      id: student.id,
      fullName: student.full_name,
      email: student.email,
      college: student.college,
      studentId: student.student_id,
      registeredAt: student.created_at,
      enrolled: enrollment?.is_active || false,
      enrolledAt: enrollment?.enrolled_at || null,
      amountPaid: enrollment?.amount_paid || 0,
      daysCompleted: completed.length,
      averageScore: avgScore,
    };
  });

  return NextResponse.json({
    students,
    total: count || 0,
    page,
    totalPages: Math.ceil((count || 0) / limit),
  });
}
