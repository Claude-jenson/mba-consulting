"use client";

import { useState, useEffect } from "react";
import { BookOpen, Save, RotateCcw, CheckCircle2, Loader2 } from "lucide-react";
import { courseModules } from "@/data/course-modules";
import { Button } from "@/components/ui/Button";

interface Override {
  day_number: number; title?: string; objective?: string;
  gd_prompt?: string; is_active?: boolean;
}

export default function AdminCurriculumPage() {
  const [overrides, setOverrides] = useState<Record<number, Override>>({});
  const [editing, setEditing]     = useState<number | null>(null);
  const [saving, setSaving]       = useState(false);
  const [saved, setSaved]         = useState(false);
  const [form, setForm]           = useState({ title: "", objective: "", gdPrompt: "" });

  useEffect(() => {
    fetch("/api/admin/curriculum").then(r => r.json()).then(d => {
      const map: Record<number, Override> = {};
      (d.overrides || []).forEach((o: Override) => { map[o.day_number] = o; });
      setOverrides(map);
    }).catch(console.error);
  }, []);

  const handleEdit = (day: number) => {
    const mod = courseModules.find(m => m.day_number === day)!;
    const ov  = overrides[day];
    setForm({
      title:    ov?.title     || mod.title,
      objective:ov?.objective || mod.objective,
      gdPrompt: ov?.gd_prompt || mod.gd_prompt,
    });
    setEditing(day);
  };

  const handleSave = async () => {
    if (!editing) return;
    setSaving(true);
    try {
      const res = await fetch("/api/admin/curriculum", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dayNumber: editing, title: form.title, objective: form.objective, gdPrompt: form.gdPrompt }),
      });
      if (res.ok) {
        const data = await res.json();
        setOverrides(prev => ({ ...prev, [editing]: data.override }));
        setSaved(true);
        setTimeout(() => setSaved(false), 2000);
      }
    } finally { setSaving(false); }
  };

  const handleReset = async (day: number) => {
    if (!confirm(`Reset Day ${day} to default content?`)) return;
    await fetch(`/api/admin/curriculum?day=${day}`, { method: "DELETE" });
    setOverrides(prev => { const n = { ...prev }; delete n[day]; return n; });
    if (editing === day) setEditing(null);
  };

  return (
    <div className="p-6 max-w-5xl">
      <div className="mb-6">
        <h1 className="text-xl font-bold text-slate-100">Curriculum Editor</h1>
        <p className="text-slate-500 text-sm">Override module titles, objectives, and GD prompts</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Day list */}
        <div className="space-y-1.5 max-h-[calc(100vh-200px)] overflow-y-auto pr-1">
          {courseModules.map(mod => {
            const hasOverride = !!overrides[mod.day_number];
            const isEditing   = editing === mod.day_number;
            return (
              <button key={mod.day_number} onClick={() => handleEdit(mod.day_number)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border text-left transition-all ${
                  isEditing
                    ? "bg-gold-500/10 border-gold-500/30 text-gold-300"
                    : "card-premium hover:border-slate-700"
                }`}>
                <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center text-xs font-bold text-slate-400 flex-shrink-0">
                  {mod.day_number}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-slate-300 truncate">{overrides[mod.day_number]?.title || mod.title}</div>
                  <div className="text-xs text-slate-600">{mod.category}</div>
                </div>
                {hasOverride && <div className="w-2 h-2 rounded-full bg-gold-500 flex-shrink-0" title="Overridden" />}
              </button>
            );
          })}
        </div>

        {/* Editor */}
        {editing ? (
          <div className="card-premium p-6 h-fit sticky top-6">
            <div className="flex items-center justify-between mb-5">
              <h2 className="font-semibold text-slate-200 flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-gold-400" /> Day {editing}
              </h2>
              {overrides[editing] && (
                <button onClick={() => handleReset(editing)} className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-red-400 transition-colors">
                  <RotateCcw className="w-3 h-3" /> Reset
                </button>
              )}
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-400 mb-1.5 block uppercase tracking-wider">Title</label>
                <input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
                  className="input-premium w-full text-sm" />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-400 mb-1.5 block uppercase tracking-wider">Objective</label>
                <textarea value={form.objective} onChange={e => setForm(f => ({ ...f, objective: e.target.value }))}
                  className="input-premium w-full text-sm h-24 resize-none" />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-400 mb-1.5 block uppercase tracking-wider">GD / PI Prompt</label>
                <textarea value={form.gdPrompt} onChange={e => setForm(f => ({ ...f, gdPrompt: e.target.value }))}
                  className="input-premium w-full text-sm h-32 resize-none" />
              </div>
            </div>

            <Button variant="gold" className="w-full mt-5" onClick={handleSave} disabled={saving}
              icon={saving ? <Loader2 className="w-4 h-4 animate-spin" /> : saved ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Save className="w-4 h-4" />}>
              {saving ? "Saving…" : saved ? "Saved!" : "Save Override"}
            </Button>
          </div>
        ) : (
          <div className="flex items-center justify-center min-h-48 card-premium rounded-xl">
            <p className="text-slate-600 text-sm">Select a day to edit</p>
          </div>
        )}
      </div>
    </div>
  );
}
