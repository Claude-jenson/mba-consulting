"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  Users, BarChart2, CreditCard, BookOpen,
  Award, Download, ShieldAlert, LogOut, Loader2,
} from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { cn } from "@/lib/utils";

const adminNav = [
  { href: "/admin",             label: "Overview",    icon: BarChart2,  exact: true },
  { href: "/admin/students",    label: "Students",    icon: Users },
  { href: "/admin/scores",      label: "Scores",      icon: BarChart2 },
  { href: "/admin/payments",    label: "Payments",    icon: CreditCard },
  { href: "/admin/curriculum",  label: "Curriculum",  icon: BookOpen },
  { href: "/admin/certificates",label: "Certificates",icon: Award },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const [checking, setChecking] = useState(true);
  const [isAdmin, setIsAdmin]   = useState(false);
  const router   = useRouter();
  const pathname = usePathname();
  const supabase = createClient();

  useEffect(() => {
    fetch("/api/admin/students?limit=1")
      .then((r) => {
        if (r.status === 401 || r.status === 403) { router.replace("/dashboard"); return; }
        setIsAdmin(true);
      })
      .catch(() => router.replace("/dashboard"))
      .finally(() => setChecking(false));
  }, [router]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.push("/");
  };

  if (checking) {
    return (
      <div className="min-h-screen bg-[#0a0f1e] flex items-center justify-center">
        <div className="flex items-center gap-3 text-slate-400">
          <Loader2 className="w-5 h-5 animate-spin text-gold-400" />
          <span className="text-sm">Verifying admin access…</span>
        </div>
      </div>
    );
  }

  if (!isAdmin) return null;

  return (
    <div className="min-h-screen bg-[#070c18] flex">
      {/* Sidebar */}
      <aside className="w-56 flex-shrink-0 border-r border-red-900/20 flex flex-col"
        style={{ background: "linear-gradient(180deg, #0d0612 0%, #070c18 100%)" }}>
        <div className="px-4 py-5 border-b border-red-900/20">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-red-600 flex items-center justify-center">
              <ShieldAlert className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="text-xs font-bold text-red-300">ADMIN PANEL</div>
              <div className="text-[10px] text-red-900/60">Restricted Access</div>
            </div>
          </div>
        </div>

        <nav className="flex-1 px-2 py-4 space-y-0.5">
          {adminNav.map((item) => {
            const isActive = item.exact
              ? pathname === item.href
              : pathname.startsWith(item.href) && item.href !== "/admin";
            return (
              <Link key={item.href} href={item.href}
                className={cn(
                  "flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-all",
                  isActive
                    ? "bg-red-500/10 text-red-300 border border-red-500/20"
                    : "text-slate-500 hover:text-slate-300 hover:bg-slate-800/40"
                )}>
                <item.icon className="w-3.5 h-3.5 flex-shrink-0" />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="px-2 py-4 border-t border-red-900/20 space-y-1">
          <Link href="/dashboard" className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs text-slate-600 hover:text-slate-400 transition-all">
            ← Back to Dashboard
          </Link>
          <button onClick={handleLogout} className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs text-red-900 hover:text-red-400 hover:bg-red-900/10 transition-all w-full">
            <LogOut className="w-3.5 h-3.5" /> Sign Out
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-y-auto">{children}</main>
    </div>
  );
}
