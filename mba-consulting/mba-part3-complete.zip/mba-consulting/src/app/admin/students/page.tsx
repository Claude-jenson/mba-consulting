"use client";

import { useState, useEffect, useCallback } from "react";
import { Users, Search, CheckCircle2, XCircle, Award, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/Button";

interface Student {
  id: string; fullName: string; email: string; college: string;
  studentId: string; registeredAt: string; enrolled: boolean;
  enrolledAt: string | null; amountPaid: number;
  daysCompleted: number; averageScore: number;
}

export default function AdminStudentsPage() {
  const [students, setStudents] = useState<Student[]>([]);
  const [search, setSearch]     = useState("");
  const [total, setTotal]       = useState(0);
  const [page, setPage]         = useState(1);
  const [loading, setLoading]   = useState(true);
  const [approving, setApproving] = useState<string | null>(null);

  const fetchStudents = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), limit: "25" });
      if (search) params.set("search", search);
      const res = await fetch(`/api/admin/students?${params}`);
      const data = await res.json();
      setStudents(data.students || []);
      setTotal(data.total || 0);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [page, search]);

  useEffect(() => { fetchStudents(); }, [fetchStudents]);

  const handleApproveCert = async (userId: string, approved: boolean) => {
    setApproving(userId);
    await fetch("/api/admin/approve-certificate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, approved }),
    });
    setApproving(null);
    fetchStudents();
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold text-slate-100">Students</h1>
          <p className="text-slate-500 text-sm">{total} total registrations</p>
        </div>
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            value={search} onChange={e => { setSearch(e.target.value); setPage(1); }}
            placeholder="Search name, email, ID…"
            className="input-premium pl-9 pr-4 py-2 text-sm w-64"
          />
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center min-h-64">
          <Loader2 className="w-6 h-6 animate-spin text-gold-400" />
        </div>
      ) : (
        <div className="card-premium overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-800/60">
                {["Student", "ID", "Enrolled", "Days", "Avg Score", "Paid (₹)", "Actions"].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {students.map((s, i) => (
                <tr key={s.id} className={`border-b border-slate-800/30 hover:bg-slate-800/20 transition-colors ${i % 2 === 0 ? "" : "bg-slate-900/20"}`}>
                  <td className="px-4 py-3">
                    <div className="font-medium text-slate-200">{s.fullName || "—"}</div>
                    <div className="text-xs text-slate-500">{s.email}</div>
                    {s.college && <div className="text-xs text-slate-600">{s.college}</div>}
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-gold-400">{s.studentId || "—"}</td>
                  <td className="px-4 py-3">
                    {s.enrolled
                      ? <span className="flex items-center gap-1 text-emerald-400 text-xs"><CheckCircle2 className="w-3.5 h-3.5" />Yes</span>
                      : <span className="flex items-center gap-1 text-slate-600 text-xs"><XCircle className="w-3.5 h-3.5" />No</span>}
                  </td>
                  <td className="px-4 py-3 text-slate-300">{s.daysCompleted}/30</td>
                  <td className="px-4 py-3">
                    <span className={`font-medium ${s.averageScore >= 75 ? "text-emerald-400" : s.averageScore >= 50 ? "text-amber-400" : "text-slate-400"}`}>
                      {s.averageScore || "—"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-slate-300">
                    {s.amountPaid ? `₹${(s.amountPaid / 100).toFixed(0)}` : "—"}
                  </td>
                  <td className="px-4 py-3">
                    {s.enrolled && s.daysCompleted >= 20 && (
                      <Button variant="secondary" size="sm"
                        onClick={() => handleApproveCert(s.id, true)}
                        disabled={approving === s.id}
                        icon={approving === s.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Award className="w-3 h-3" />}>
                        Cert
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {total > 25 && (
            <div className="flex items-center justify-between px-4 py-3 border-t border-slate-800/60">
              <span className="text-xs text-slate-500">Page {page} · {total} total</span>
              <div className="flex gap-2">
                <Button variant="ghost" size="sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>← Prev</Button>
                <Button variant="ghost" size="sm" disabled={students.length < 25} onClick={() => setPage(p => p + 1)}>Next →</Button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
