"use client";

import { useEffect, useState } from "react";
import { Users, CreditCard, Award, BarChart2, Download, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/Button";

interface AdminStats {
  totalStudents: number;
  enrolledStudents: number;
  totalRevenue: number;
  totalPaid: number;
  avgScore: number;
  certificatesIssued: number;
}

export default function AdminPage() {
  const [stats, setStats]   = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch("/api/admin/students?limit=1").then(r => r.json()),
      fetch("/api/admin/payments").then(r => r.json()),
    ]).then(([studentsData, paymentsData]) => {
      setStats({
        totalStudents: studentsData.total || 0,
        enrolledStudents: studentsData.students?.filter((s: { enrolled: boolean }) => s.enrolled).length || 0,
        totalRevenue: paymentsData.summary?.totalRevenue || 0,
        totalPaid: paymentsData.summary?.totalPaid || 0,
        avgScore: 0,
        certificatesIssued: 0,
      });
    }).catch(console.error).finally(() => setLoading(false));
  }, []);

  const handleExport = (type: string) => {
    window.open(`/api/admin/export-csv?type=${type}`, "_blank");
  };

  const kpis = stats ? [
    { icon: Users,      label: "Total Registrations", value: stats.totalStudents,   color: "#60a5fa" },
    { icon: TrendingUp, label: "Enrolled Students",   value: stats.enrolledStudents, color: "#34d399" },
    { icon: CreditCard, label: "Total Revenue (₹)",   value: `₹${stats.totalRevenue.toLocaleString("en-IN")}`, color: "#c9a227" },
    { icon: Award,      label: "Payments Confirmed",  value: stats.totalPaid,       color: "#a78bfa" },
  ] : [];

  return (
    <div className="p-6 max-w-5xl">
      <div className="mb-7">
        <h1 className="text-xl font-bold text-slate-100">Admin Overview</h1>
        <p className="text-slate-500 text-sm mt-0.5">Platform metrics and quick actions</p>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {loading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="card-premium p-5 h-24 animate-pulse bg-slate-800/40" />
          ))
        ) : kpis.map((kpi, i) => (
          <div key={i} className="card-premium p-5">
            <kpi.icon className="w-5 h-5 mb-2" style={{ color: kpi.color }} />
            <div className="text-2xl font-bold text-slate-100">{kpi.value}</div>
            <div className="text-xs text-slate-500 mt-0.5">{kpi.label}</div>
          </div>
        ))}
      </div>

      {/* Export section */}
      <div className="card-premium p-6 mb-6">
        <h2 className="font-semibold text-slate-200 mb-4 flex items-center gap-2">
          <Download className="w-4 h-4 text-gold-400" /> Export Data
        </h2>
        <div className="flex flex-wrap gap-3">
          {[
            { type: "students", label: "Export Students CSV" },
            { type: "scores",   label: "Export Scores CSV" },
            { type: "payments", label: "Export Payments CSV" },
          ].map((exp) => (
            <Button key={exp.type} variant="secondary" size="sm" onClick={() => handleExport(exp.type)}
              icon={<Download className="w-3.5 h-3.5" />}>
              {exp.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Quick links */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {[
          { href: "/admin/students",     label: "Manage Students",     icon: Users },
          { href: "/admin/scores",       label: "View All Scores",     icon: BarChart2 },
          { href: "/admin/payments",     label: "Payment Logs",        icon: CreditCard },
          { href: "/admin/curriculum",   label: "Edit Curriculum",     icon: BarChart2 },
          { href: "/admin/certificates", label: "Approve Certificates",icon: Award },
        ].map((link) => (
          <a key={link.href} href={link.href}
            className="card-premium p-4 flex items-center gap-3 hover:border-gold-500/20 transition-all group">
            <link.icon className="w-4 h-4 text-slate-500 group-hover:text-gold-400 transition-colors" />
            <span className="text-sm text-slate-400 group-hover:text-slate-200 transition-colors">{link.label}</span>
          </a>
        ))}
      </div>
    </div>
  );
}
