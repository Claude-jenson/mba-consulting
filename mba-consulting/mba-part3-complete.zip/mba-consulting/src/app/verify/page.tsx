"use client";

import { useEffect, useState, use } from "react";
import { motion } from "framer-motion";
import { CheckCircle2, XCircle, Award, Loader2, ExternalLink } from "lucide-react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";

interface VerifyResult {
  valid: boolean;
  error?: string;
  verificationId?: string;
  studentId?: string;
  studentName?: string;
  college?: string;
  issuedAt?: string;
  finalScore?: number;
  grade?: string;
  daysCompleted?: number;
  courseName?: string;
}

const GRADE_LABELS: Record<string, string> = { A: "Distinction", B: "Merit", C: "Pass" };
const GRADE_COLORS: Record<string, string> = {
  A: "#34d399", B: "#c9a227", C: "#60a5fa",
};

export default function VerifyPage() {
  const searchParams = useSearchParams();
  const id           = searchParams.get("id") || "";
  const [result, setResult] = useState<VerifyResult | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) {
      setResult({ valid: false, error: "No verification ID provided." });
      setLoading(false);
      return;
    }

    fetch(`/api/certificate/verify?id=${encodeURIComponent(id)}`)
      .then((r) => r.json())
      .then(setResult)
      .catch(() => setResult({ valid: false, error: "Verification service unavailable." }))
      .finally(() => setLoading(false));
  }, [id]);

  return (
    <div className="min-h-screen bg-[#0a0f1e] bg-grid flex items-center justify-center px-4 py-16">
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: "radial-gradient(ellipse 60% 40% at 50% 0%, rgba(201,162,39,0.06), transparent)" }}
      />

      <div className="w-full max-w-lg relative z-10">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-gold-500 to-gold-700 flex items-center justify-center">
              <span className="text-slate-900 font-black text-sm">M</span>
            </div>
            <span className="text-sm font-semibold text-slate-300">MBA Communication Dominance</span>
          </Link>
        </div>

        {loading ? (
          <div className="card-premium p-12 text-center">
            <Loader2 className="w-10 h-10 animate-spin text-gold-400 mx-auto mb-4" />
            <p className="text-slate-400 text-sm">Verifying certificate…</p>
          </div>
        ) : result?.valid ? (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            {/* Valid certificate */}
            <div className="card-premium card-accent p-8 text-center mb-5">
              <div className="w-16 h-16 rounded-full bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center mx-auto mb-5">
                <CheckCircle2 className="w-9 h-9 text-emerald-400" />
              </div>

              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold mb-5">
                <CheckCircle2 className="w-3.5 h-3.5" /> Verified Certificate
              </div>

              <h2 className="text-2xl font-bold text-gold-gradient mb-1" style={{ fontFamily: "var(--font-display)" }}>
                {result.studentName}
              </h2>
              {result.college && (
                <p className="text-slate-500 text-sm mb-5">{result.college}</p>
              )}

              <div className="grid grid-cols-2 gap-3 mb-5">
                {[
                  { label: "Grade",           value: `${result.grade} — ${GRADE_LABELS[result.grade || "C"] || ""}`, color: GRADE_COLORS[result.grade || "C"] },
                  { label: "Final Score",     value: `${result.finalScore}/100`,  color: "#c9a227" },
                  { label: "Days Completed",  value: `${result.daysCompleted}/30`, color: "#60a5fa" },
                  { label: "Student ID",      value: result.studentId || "—",     color: "#94a3b8" },
                ].map((s, i) => (
                  <div key={i} className="bg-slate-900/60 rounded-xl border border-slate-800/60 p-3 text-center">
                    <div className="text-xs text-slate-500 mb-0.5">{s.label}</div>
                    <div className="text-sm font-semibold" style={{ color: s.color }}>{s.value}</div>
                  </div>
                ))}
              </div>

              <p className="text-slate-400 text-xs leading-relaxed">{result.courseName}</p>

              <div className="mt-4 pt-4 border-t border-gold-500/10">
                <p className="text-slate-600 text-xs">
                  Issued: {result.issuedAt ? new Date(result.issuedAt).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" }) : "—"}
                  {" · "}
                  ID: <span className="font-mono text-gold-500/70">{result.verificationId}</span>
                </p>
              </div>
            </div>

            <div className="text-center text-xs text-slate-600">
              This certificate was issued by{" "}
              <Link href="/" className="text-gold-400 hover:underline">MBA Communication Dominance</Link>
            </div>
          </motion.div>
        ) : (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="card-premium p-8 text-center">
              <div className="w-16 h-16 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center mx-auto mb-5">
                <XCircle className="w-9 h-9 text-red-400" />
              </div>
              <h2 className="text-xl font-bold text-slate-200 mb-2">Certificate Not Found</h2>
              <p className="text-slate-400 text-sm mb-6">
                {result?.error || "The verification ID you entered could not be found or is invalid."}
              </p>
              {id && (
                <div className="bg-slate-900/60 rounded-xl border border-slate-800 px-4 py-2 font-mono text-xs text-slate-500 mb-5 inline-block">
                  {id}
                </div>
              )}
              <p className="text-slate-600 text-xs">
                If you believe this is an error, contact{" "}
                <a href="mailto:support@mbacomm.in" className="text-gold-400 hover:underline">
                  support@mbacomm.in
                </a>
              </p>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
