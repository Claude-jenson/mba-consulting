import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Certificate Verification | MBA Communication Dominance",
  description: "Verify the authenticity of an MBA Communication Dominance certificate.",
};

export default function VerifyLayout({ children }: { children: React.ReactNode }) {
  return children;
}
