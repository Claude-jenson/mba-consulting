import type { Metadata, Viewport } from "next";
import { DM_Sans, Playfair_Display } from "next/font/google";
import "./globals.css";

const dmSans = DM_Sans({ subsets: ["latin"], variable: "--font-sans", display: "swap" });
const playfair = Playfair_Display({ subsets: ["latin"], variable: "--font-display", display: "swap" });

const APP_URL  = process.env.NEXT_PUBLIC_APP_URL || "https://mba-comm.netlify.app";
const APP_NAME = "MBA Communication Dominance";
const APP_DESC = "30-Day Consulting Communication Transformation. AI-powered GD/PI coaching for MBA aspirants. Used by 2,400+ students. ₹199 lifetime access.";

export const metadata: Metadata = {
  metadataBase: new URL(APP_URL),
  title: {
    default:  `${APP_NAME} — 30-Day Consulting Transformation`,
    template: `%s | ${APP_NAME}`,
  },
  description: APP_DESC,
  keywords: [
    "MBA communication", "consulting interview prep", "GD PI coaching",
    "SCQA framework", "pyramid principle", "MBA group discussion",
    "McKinsey interview", "BCG prep", "IIM NMIMS XLRI interview", "MBA India",
  ],
  authors: [{ name: APP_NAME }],
  openGraph: {
    type: "website", locale: "en_IN", url: APP_URL, siteName: APP_NAME,
    title: `${APP_NAME} — AI-Powered 30-Day Consulting Transformation`,
    description: APP_DESC,
    images: [{ url: `${APP_URL}/og-image.jpg`, width: 1200, height: 630, alt: `${APP_NAME}` }],
  },
  twitter: {
    card: "summary_large_image",
    title: `${APP_NAME} — 30-Day Consulting Communication`,
    description: APP_DESC,
    images: [`${APP_URL}/og-image.jpg`],
  },
  robots: {
    index: true, follow: true,
    googleBot: { index: true, follow: true, "max-image-preview": "large", "max-snippet": -1 },
  },
  alternates: { canonical: APP_URL },
};

export const viewport: Viewport = {
  width: "device-width", initialScale: 1, maximumScale: 5, themeColor: "#0a0f1e",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${dmSans.variable} ${playfair.variable}`} suppressHydrationWarning>
      <head>
        <link rel="icon" href="/favicon.ico" sizes="any" />
        <link rel="manifest" href="/manifest.json" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="dns-prefetch" href="https://checkout.razorpay.com" />
        <link rel="dns-prefetch" href="https://api.razorpay.com" />
      </head>
      <body className="font-sans antialiased text-slate-100 bg-[#0a0f1e]">{children}</body>
    </html>
  );
}
