"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Trophy, Flame, BarChart2, Zap, Crown, Loader2, Medal } from "lucide-react";

interface LeaderboardEntry {
  rank: number;
  isCurrentUser: boolean;
  displayName: string;
  studentId: string;
  college: string;
  daysCompleted: number;
  avgScore: number;
  bestScore: number;
  currentStreak: number;
  rankScore: number;
}

const SORT_OPTIONS = [
  { key: "rank_score",      label: "Overall",     icon: Trophy },
  { key: "avg_score",       label: "Avg Score",   icon: BarChart2 },
  { key: "days_completed",  label: "Completion",  icon: Zap },
  { key: "current_streak",  label: "Streak",      icon: Flame },
] as const;

const RANK_MEDAL = [
  { icon: Crown, color: "#FFD700" },
  { icon: Medal, color: "#C0C0C0" },
  { icon: Medal, color: "#CD7F32" },
];

export default function LeaderboardPage() {
  const [entries, setEntries]   = useState<LeaderboardEntry[]>([]);
  const [sortBy, setSortBy]     = useState<typeof SORT_OPTIONS[number]["key"]>("rank_score");
  const [myRank, setMyRank]     = useState<number | null>(null);
  const [loading, setLoading]   = useState(true);

  useEffect(() => {
    setLoading(true);
    fetch(`/api/leaderboard?sort=${sortBy}&limit=50`)
      .then((r) => r.json())
      .then((d) => {
        setEntries(d.leaderboard || []);
        setMyRank(d.currentUserRank || null);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [sortBy]);

  return (
    <div className="p-4 md:p-8 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-slate-100" style={{ fontFamily: "var(--font-display)" }}>
            Leaderboard
          </h1>
          <p className="text-slate-500 text-sm mt-0.5">
            {myRank ? `You are ranked #${myRank} · ` : ""}Ranked among all enrolled students
          </p>
        </div>

        {/* Sort tabs */}
        <div className="flex gap-1 p-1 bg-slate-900/50 rounded-xl border border-slate-800/50">
          {SORT_OPTIONS.map((opt) => (
            <button
              key={opt.key}
              onClick={() => setSortBy(opt.key)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                sortBy === opt.key
                  ? "bg-gold-500/15 text-gold-300 border border-gold-500/20"
                  : "text-slate-500 hover:text-slate-300"
              }`}
            >
              <opt.icon className="w-3 h-3" />
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* My rank banner */}
      {myRank && myRank > 3 && (
        <div className="card-premium card-accent p-4 mb-5 flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-gold-500/15 border border-gold-500/25 flex items-center justify-center">
            <Trophy className="w-5 h-5 text-gold-400" />
          </div>
          <div>
            <div className="text-sm font-semibold text-slate-200">Your rank: #{myRank}</div>
            <div className="text-xs text-slate-500">Keep grinding to climb higher</div>
          </div>
        </div>
      )}

      {/* Table */}
      {loading ? (
        <div className="flex items-center justify-center min-h-64">
          <Loader2 className="w-6 h-6 animate-spin text-gold-400" />
        </div>
      ) : (
        <div className="space-y-2">
          {entries.map((entry, i) => {
            const medal = RANK_MEDAL[i];
            const isTop3 = i < 3;

            return (
              <motion.div
                key={entry.rank}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: Math.min(i * 0.03, 0.5) }}
                className={`relative flex items-center gap-4 px-5 py-4 rounded-xl border transition-all ${
                  entry.isCurrentUser
                    ? "bg-gold-500/8 border-gold-500/25 ring-1 ring-gold-500/20"
                    : isTop3
                    ? "bg-slate-900/60 border-slate-700/60"
                    : "card-premium"
                }`}
              >
                {/* Rank */}
                <div className="w-10 flex-shrink-0 text-center">
                  {isTop3 && medal ? (
                    <medal.icon className="w-5 h-5 mx-auto" style={{ color: medal.color }} />
                  ) : (
                    <span className="text-sm font-bold text-slate-500">#{entry.rank}</span>
                  )}
                </div>

                {/* Avatar */}
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0"
                  style={{
                    background: entry.isCurrentUser
                      ? "linear-gradient(135deg, #c9a227, #8a6c12)"
                      : "linear-gradient(135deg, #1e293b, #0f172a)",
                    color: entry.isCurrentUser ? "#0a0f1e" : "#64748b",
                    border: "1px solid rgba(255,255,255,0.06)",
                  }}
                >
                  {entry.displayName[0]?.toUpperCase()}
                </div>

                {/* Name & college */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className={`text-sm font-semibold truncate ${entry.isCurrentUser ? "text-gold-300" : "text-slate-200"}`}>
                      {entry.displayName}
                    </span>
                    {entry.isCurrentUser && (
                      <span className="text-[10px] bg-gold-500/15 text-gold-400 border border-gold-500/20 px-1.5 py-0.5 rounded-full flex-shrink-0">
                        You
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-slate-500 truncate">{entry.college}</div>
                </div>

                {/* Stats */}
                <div className="hidden sm:flex items-center gap-6 flex-shrink-0">
                  <div className="text-center">
                    <div className="text-sm font-bold text-slate-200">{entry.avgScore || "—"}</div>
                    <div className="text-[10px] text-slate-500">Avg Score</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-bold text-slate-200">{entry.daysCompleted}/30</div>
                    <div className="text-[10px] text-slate-500">Days</div>
                  </div>
                  {entry.currentStreak > 0 && (
                    <div className="flex items-center gap-1 text-orange-400">
                      <Flame className="w-3.5 h-3.5" />
                      <span className="text-sm font-bold">{entry.currentStreak}</span>
                    </div>
                  )}
                  <div className="text-center min-w-[52px]">
                    <div className="text-sm font-bold text-gold-400">{entry.rankScore}</div>
                    <div className="text-[10px] text-slate-500">Rank Score</div>
                  </div>
                </div>
              </motion.div>
            );
          })}

          {entries.length === 0 && (
            <div className="text-center py-16 text-slate-500">
              <Trophy className="w-12 h-12 mx-auto mb-3 text-slate-700" />
              <p>No students on the leaderboard yet.</p>
              <p className="text-xs mt-1">Complete Day 1 to appear here!</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
