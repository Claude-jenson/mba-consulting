"use client";

import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Award, Download, Linkedin, CheckCircle2, Lock,
  TrendingUp, Star, Target, Copy, ExternalLink,
  Loader2, AlertCircle, RefreshCw,
} from "lucide-react";
import { Button } from "@/components/ui/Button";

interface CertStatus {
  hasCertificate: boolean;
  isApproved?: boolean;
  verificationId?: string;
  grade?: "A" | "B" | "C";
  finalScore?: number;
  issuedAt?: string;
  studentId?: string;
  daysCompleted?: number;
  canGenerate?: boolean;
}

const GRADE_CONFIG = {
  A: { label: "Distinction", color: "#34d399", bg: "rgba(52,211,153,0.08)", border: "rgba(52,211,153,0.25)" },
  B: { label: "Merit",       color: "#c9a227", bg: "rgba(201,162,39,0.08)", border: "rgba(201,162,39,0.25)" },
  C: { label: "Pass",        color: "#60a5fa", bg: "rgba(96,165,250,0.08)", border: "rgba(96,165,250,0.25)" },
};

function LinkedInShareCard({ userName, grade, finalScore, verificationId }: {
  userName: string; grade: string; finalScore: number; verificationId: string;
}) {
  const [copied, setCopied] = useState(false);
  const appUrl = process.env.NEXT_PUBLIC_APP_URL || "https://mba-comm.netlify.app";

  const post = `🎓 Completed MBA Communication Dominance – 30-Day Consulting Transformation!

After 30 days of structured practice & AI-powered feedback, I earned Grade ${grade} (${finalScore}/100).

📌 What I built:
✅ SCQA, Pyramid Principle & ACE frameworks
✅ Executive presence & consulting articulation  
✅ Issue tree thinking & structured communication
✅ Eliminated filler words & hedging language

This was a daily mirror held up to my communication style — and I came out sharper.

🔗 Verify: ${appUrl}/verify?id=${verificationId}

#MBA #ConsultingCommunication #PersonalDevelopment #MBADomination #McKinsey #BCG`;

  const handleCopy = () => {
    navigator.clipboard.writeText(post);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="card-premium p-6">
      <div className="flex items-center gap-2 mb-4">
        <Linkedin className="w-5 h-5 text-[#0077B5]" />
        <h3 className="font-semibold text-slate-200">Share on LinkedIn</h3>
        <span className="ml-auto text-xs text-slate-500">Tell your network!</span>
      </div>
      <div className="bg-slate-900/60 rounded-xl border border-slate-800/60 p-4 mb-4 text-xs text-slate-300 leading-relaxed whitespace-pre-wrap font-mono max-h-48 overflow-y-auto">
        {post}
      </div>
      <div className="flex gap-3">
        <Button
          variant="primary"
          className="flex-1 !bg-[#0077B5] hover:!bg-[#006399]"
          onClick={() => window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(`${appUrl}/verify?id=${verificationId}`)}`, "_blank", "width=600,height=600")}
          icon={<Linkedin className="w-4 h-4" />}
        >
          Post to LinkedIn
        </Button>
        <Button variant="secondary" onClick={handleCopy}
          icon={copied ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}>
          {copied ? "Copied!" : "Copy"}
        </Button>
      </div>
    </div>
  );
}

export default function CertificatePage() {
  const [certStatus, setCertStatus]   = useState<CertStatus | null>(null);
  const [daysCompleted, setDaysCompleted] = useState(0);
  const [avgScore, setAvgScore]       = useState(0);
  const [loading, setLoading]         = useState(true);
  const [evaluating, setEvaluating]   = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [error, setError]             = useState<string | null>(null);
  const [userName, setUserName]       = useState("Student");

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [certRes, progressRes, enrollRes] = await Promise.all([
        fetch("/api/certificate/generate"),
        fetch("/api/progress"),
        fetch("/api/enrollment"),
      ]);
      const cert     = await certRes.json();
      const progress = progressRes.ok ? await progressRes.json() : null;
      const enroll   = enrollRes.ok ? await enrollRes.json() : null;

      setCertStatus(cert);
      if (progress) {
        setDaysCompleted(progress.totalSubmissions || 0);
        setAvgScore(progress.averageScore || 0);
      }
      if (enroll?.profile?.full_name) setUserName(enroll.profile.full_name);
    } catch {
      setError("Failed to load certificate data");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleRunEvaluation = async () => {
    setEvaluating(true);
    setError(null);
    try {
      const res = await fetch("/api/certificate/generate", { method: "POST" });
      const data = await res.json().catch(() => ({}));
      if (!res.ok && !data.certificate_unlocked) {
        throw new Error(data.message || "Evaluation complete but certificate not yet unlocked.");
      }
      await fetchData();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Evaluation failed");
    } finally {
      setEvaluating(false);
    }
  };

  const handleDownload = async () => {
    setDownloading(true);
    setError(null);
    try {
      const res = await fetch("/api/certificate/generate", { method: "POST" });
      if (!res.ok) {
        const d = await res.json().catch(() => ({}));
        throw new Error(d.message || "Download failed");
      }
      const blob = await res.blob();
      const url  = URL.createObjectURL(blob);
      const a    = Object.assign(document.createElement("a"), {
        href: url,
        download: `MBA_Certificate_${userName.replace(/\s+/g, "_")}.pdf`,
      });
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Download failed");
    } finally {
      setDownloading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <Loader2 className="w-6 h-6 animate-spin text-gold-400" />
      </div>
    );
  }

  const hasCert   = certStatus?.hasCertificate;
  const approved  = certStatus?.isApproved;
  const grade     = certStatus?.grade;
  const gc        = grade ? GRADE_CONFIG[grade] : null;
  const canUnlock = daysCompleted >= 25 && avgScore >= 70;

  return (
    <div className="p-4 md:p-8 max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-100" style={{ fontFamily: "var(--font-display)" }}>
          Your Certificate
        </h1>
        <p className="text-slate-500 text-sm mt-1">25+ days + avg score ≥75 unlocks your certificate</p>
      </div>

      <AnimatePresence>
        {error && (
          <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
            className="flex items-start gap-3 p-4 rounded-xl bg-red-900/20 border border-red-800/30 mb-6">
            <AlertCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
            <p className="text-red-400 text-sm">{error}</p>
            <button onClick={() => setError(null)} className="ml-auto text-xs text-red-400/60 hover:underline">✕</button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── EARNED & APPROVED ── */}
      {hasCert && approved && grade && (
        <div className="space-y-5">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
            className="card-premium card-accent p-8 text-center relative overflow-hidden">
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.04]">
              <span className="text-9xl font-black text-gold-400 rotate-12">VERIFIED</span>
            </div>
            <div className="relative z-10">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-gold-400 to-gold-700 flex items-center justify-center mx-auto mb-5 shadow-gold">
                <Award className="w-10 h-10 text-slate-900" />
              </div>
              <p className="text-slate-400 text-xs uppercase tracking-widest mb-2">Certificate of Completion</p>
              <h2 className="text-3xl font-bold text-gold-gradient mb-1" style={{ fontFamily: "var(--font-display)" }}>
                {userName}
              </h2>
              <p className="text-slate-400 text-sm mb-6">MBA Communication Dominance — 30-Day Consulting Transformation</p>

              <div className="inline-flex items-center gap-4 px-6 py-3 rounded-2xl border mb-7"
                style={{ background: gc?.bg, borderColor: gc?.border }}>
                <div className="text-center">
                  <div className="text-xs text-slate-500 mb-0.5">Grade</div>
                  <div className="text-2xl font-black" style={{ color: gc?.color }}>{grade}</div>
                </div>
                <div className="w-px h-10 bg-white/10" />
                <div className="text-center">
                  <div className="text-xs text-slate-500 mb-0.5">Label</div>
                  <div className="font-bold text-slate-200">{gc?.label}</div>
                </div>
                <div className="w-px h-10 bg-white/10" />
                <div className="text-center">
                  <div className="text-xs text-slate-500 mb-0.5">Score</div>
                  <div className="font-bold text-slate-200">{certStatus?.finalScore}/100</div>
                </div>
                <div className="w-px h-10 bg-white/10" />
                <div className="text-center">
                  <div className="text-xs text-slate-500 mb-0.5">Verify ID</div>
                  <div className="font-mono text-xs text-gold-400">{certStatus?.verificationId}</div>
                </div>
              </div>

              <div className="flex flex-wrap gap-3 justify-center">
                <Button variant="gold" size="lg" onClick={handleDownload} disabled={downloading}
                  icon={downloading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}>
                  {downloading ? "Generating…" : "Download PDF Certificate"}
                </Button>
                <a href={`/verify?id=${certStatus?.verificationId}`} target="_blank" rel="noopener noreferrer">
                  <Button variant="secondary" size="lg" icon={<ExternalLink className="w-4 h-4" />}>Verify</Button>
                </a>
              </div>
            </div>
          </motion.div>

          {/* Stats row */}
          <div className="grid grid-cols-3 gap-4">
            {[
              { icon: Target,     label: "Final Score",   value: `${certStatus?.finalScore}/100`, color: "#c9a227" },
              { icon: TrendingUp, label: "Days Completed", value: `${daysCompleted}/30`,           color: "#34d399" },
              { icon: Star,       label: "Achievement",   value: gc?.label || "",                 color: gc?.color  },
            ].map((s, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 + i * 0.08 }}
                className="card-premium p-5 text-center">
                <s.icon className="w-5 h-5 mx-auto mb-2" style={{ color: s.color }} />
                <div className="text-lg font-bold text-slate-100">{s.value}</div>
                <div className="text-xs text-slate-500 mt-0.5">{s.label}</div>
              </motion.div>
            ))}
          </div>

          <LinkedInShareCard
            userName={userName} grade={grade}
            finalScore={certStatus?.finalScore || 0}
            verificationId={certStatus?.verificationId || ""}
          />
        </div>
      )}

      {/* ── PENDING APPROVAL ── */}
      {hasCert && !approved && (
        <div className="card-premium p-10 text-center">
          <RefreshCw className="w-12 h-12 text-amber-400 mx-auto mb-4 animate-spin" style={{ animationDuration: "4s" }} />
          <h2 className="text-xl font-bold text-slate-200 mb-2">Certificate Under Review</h2>
          <p className="text-slate-400 text-sm max-w-sm mx-auto">Your certificate is pending admin approval — usually within 24 hours.</p>
          <div className="mt-4 text-xs font-mono text-gold-400">{certStatus?.verificationId}</div>
        </div>
      )}

      {/* ── NOT YET EARNED ── */}
      {!hasCert && (
        <div className="space-y-5">
          <div className="card-premium p-7">
            <div className="flex items-start gap-4 mb-6">
              <div className="w-12 h-12 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center flex-shrink-0">
                <Lock className="w-6 h-6 text-slate-500" />
              </div>
              <div>
                <h2 className="font-bold text-slate-200 text-lg mb-1">Certificate Locked</h2>
                <p className="text-slate-400 text-sm">Complete 25+ days with an average score of 75 or above.</p>
              </div>
            </div>

            <div className="space-y-4">
              {[
                { label: "Days completed",      current: daysCompleted,  required: 25,  done: daysCompleted >= 25, unit: "days" },
                { label: "Average score ≥ 75",  current: avgScore,       required: 75,  done: avgScore >= 75,      unit: "/100" },
              ].map((req, i) => (
                <div key={i}>
                  <div className="flex justify-between text-sm mb-1.5">
                    <span className="text-slate-400 flex items-center gap-2">
                      {req.done
                        ? <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        : <div className="w-4 h-4 rounded-full border border-slate-600" />}
                      {req.label}
                    </span>
                    <span className={req.done ? "text-emerald-400 font-medium" : "text-slate-500"}>
                      {req.current}{req.unit}
                    </span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-800 overflow-hidden">
                    <motion.div className="h-2 rounded-full"
                      style={{ background: req.done ? "#34d399" : "#c9a227" }}
                      initial={{ width: 0 }}
                      animate={{ width: `${Math.min((req.current / req.required) * 100, 100)}%` }}
                      transition={{ duration: 1, delay: i * 0.2 }}
                    />
                  </div>
                </div>
              ))}
            </div>

            {canUnlock && (
              <div className="mt-6">
                <Button variant="gold" size="lg" className="w-full" onClick={handleRunEvaluation} disabled={evaluating}
                  icon={evaluating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Award className="w-4 h-4" />}>
                  {evaluating ? "Running Final Evaluation…" : "Generate Certificate"}
                </Button>
                <p className="text-slate-500 text-xs text-center mt-2">Analyzes all your submissions and assigns final grade</p>
              </div>
            )}
          </div>

          <div className="card-premium p-6">
            <h3 className="font-semibold text-slate-300 text-sm mb-4">What your certificate includes</h3>
            <div className="grid grid-cols-2 gap-2.5">
              {["Name & Student ID", "Final grade (A/B/C)", "QR verification code", "Growth % trajectory",
                "Unique Verify ID", "Date of completion"].map((item, i) => (
                <div key={i} className="flex items-center gap-2 text-sm text-slate-400">
                  <div className="w-1.5 h-1.5 rounded-full bg-gold-400 flex-shrink-0" />
                  {item}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
