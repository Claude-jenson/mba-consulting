import { createAdminClient } from "@/lib/supabase/admin";
import { getAuthUser } from "@/lib/security/auth-guard";
import type { User } from "@supabase/supabase-js";

export async function requireAdmin(): Promise<
  | { user: User; isAdmin: true; error: null }
  | { user: null; isAdmin: false; error: Response }
> {
  const user = await getAuthUser();

  if (!user) {
    return {
      user: null,
      isAdmin: false,
      error: new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { "Content-Type": "application/json" } }
      ),
    };
  }

  const supabase = createAdminClient();
  const { data: adminRecord } = await supabase
    .from("admin_users")
    .select("id, role")
    .eq("id", user.id)
    .maybeSingle();

  if (!adminRecord) {
    return {
      user: null,
      isAdmin: false,
      error: new Response(
        JSON.stringify({
          error: "Forbidden",
          message: "Admin access required.",
        }),
        { status: 403, headers: { "Content-Type": "application/json" } }
      ),
    };
  }

  return { user, isAdmin: true, error: null };
}
