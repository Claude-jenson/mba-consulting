import { createAdminClient } from "@/lib/supabase/admin";

export interface FinalEvaluationResult {
  finalScore: number;
  baselineScore: number;
  growthPct: number;
  grade: "A" | "B" | "C";
  certificateUnlocked: boolean;
  categoryScores: Record<string, number>;
  bestCategory: string;
  weakestCategory: string;
  avgDimensions: {
    clarity: number;
    structure: number;
    logicalDepth: number;
    confidenceProjection: number;
    consultingArticulation: number;
    leadershipSignals: number;
  };
  scoreTrajectory: Array<{ day: number; score: number }>;
  daysCompleted: number;
}

const GRADE_THRESHOLDS = {
  A: 85,
  B: 75,
  C: 0,
} as const;

const DAY_CATEGORY_MAP: Record<number, string> = Object.fromEntries([
  ...[1,2,3,4,5,6].map(d => [d, "foundation"]),
  ...[7,8,9,10,11,12].map(d => [d, "structure"]),
  ...[13,14,15,16,17,18].map(d => [d, "influence"]),
  ...[19,20,21,22,23,24].map(d => [d, "executive"]),
  ...[25,26,27,28,29,30].map(d => [d, "mastery"]),
]);

export async function computeFinalEvaluation(
  userId: string
): Promise<FinalEvaluationResult> {
  const supabase = createAdminClient();

  // Fetch all scores for this user, ordered by day
  const { data: scores, error } = await supabase
    .from("scores")
    .select(
      `day_number, composite_score,
       clarity, structure, logical_depth,
       confidence_projection, consulting_articulation, leadership_signals`
    )
    .eq("user_id", userId)
    .not("composite_score", "is", null)
    .order("day_number", { ascending: true });

  if (error) throw new Error(`Score fetch failed: ${error.message}`);
  if (!scores || scores.length === 0) {
    throw new Error("No scores found. Complete at least 1 day before final evaluation.");
  }

  const daysCompleted = scores.length;

  // Trajectory
  const scoreTrajectory = scores.map((s) => ({
    day: s.day_number,
    score: s.composite_score ?? 0,
  }));

  // Baseline = Day 1 score (or first available)
  const baselineScore = scores[0].composite_score ?? 0;

  // Final score = weighted average: last 5 days count 50%, earlier 50%
  const lastFive = scores.slice(-5);
  const earlier = scores.slice(0, -5);
  const lastFiveAvg =
    lastFive.length > 0
      ? lastFive.reduce((sum, s) => sum + (s.composite_score ?? 0), 0) / lastFive.length
      : 0;
  const earlierAvg =
    earlier.length > 0
      ? earlier.reduce((sum, s) => sum + (s.composite_score ?? 0), 0) / earlier.length
      : lastFiveAvg;

  const finalScore = parseFloat(
    (lastFive.length === scores.length
      ? lastFiveAvg  // only 5 or fewer submissions total
      : lastFiveAvg * 0.5 + earlierAvg * 0.5
    ).toFixed(1)
  );

  // Growth
  const growthPct = parseFloat(
    (((finalScore - baselineScore) / Math.max(baselineScore, 1)) * 100).toFixed(1)
  );

  // Grade
  const grade: "A" | "B" | "C" =
    finalScore >= GRADE_THRESHOLDS.A
      ? "A"
      : finalScore >= GRADE_THRESHOLDS.B
      ? "B"
      : "C";

  // Certificate unlocked if final score >= 75 AND completed >= 25 days
  const certificateUnlocked = finalScore >= 75 && daysCompleted >= 25;

  // Category breakdown
  const catAccum: Record<string, number[]> = {};
  for (const s of scores) {
    const cat = DAY_CATEGORY_MAP[s.day_number] || "foundation";
    if (!catAccum[cat]) catAccum[cat] = [];
    catAccum[cat].push(s.composite_score ?? 0);
  }
  const categoryScores: Record<string, number> = {};
  for (const [cat, vals] of Object.entries(catAccum)) {
    categoryScores[cat] = parseFloat(
      (vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(1)
    );
  }
  const sorted = Object.entries(categoryScores).sort(([, a], [, b]) => b - a);
  const bestCategory = sorted[0]?.[0] || "foundation";
  const weakestCategory = sorted[sorted.length - 1]?.[0] || "mastery";

  // Avg dimensions
  const avg = (key: string) =>
    parseFloat(
      (
        scores.reduce((sum, s) => sum + ((s as Record<string, unknown>)[key] as number ?? 0), 0) /
        scores.length
      ).toFixed(1)
    );

  const avgDimensions = {
    clarity: avg("clarity"),
    structure: avg("structure"),
    logicalDepth: avg("logical_depth"),
    confidenceProjection: avg("confidence_projection"),
    consultingArticulation: avg("consulting_articulation"),
    leadershipSignals: avg("leadership_signals"),
  };

  // Persist final evaluation
  await supabase.from("final_evaluations").upsert(
    {
      user_id: userId,
      final_score: finalScore,
      baseline_score: baselineScore,
      growth_pct: growthPct,
      grade,
      certificate_unlocked: certificateUnlocked,
      category_scores: categoryScores,
      best_category: bestCategory,
      weakest_category: weakestCategory,
      avg_clarity: avgDimensions.clarity,
      avg_structure: avgDimensions.structure,
      avg_logical_depth: avgDimensions.logicalDepth,
      avg_confidence: avgDimensions.confidenceProjection,
      avg_consulting: avgDimensions.consultingArticulation,
      avg_leadership: avgDimensions.leadershipSignals,
      score_trajectory: scoreTrajectory,
      completed_at: new Date().toISOString(),
    },
    { onConflict: "user_id" }
  );

  // If certificate unlocked, create the certificate record
  if (certificateUnlocked) {
    await ensureCertificateRecord(userId, {
      finalScore,
      baselineScore,
      growthPct,
      grade,
      daysCompleted,
    });
  }

  return {
    finalScore,
    baselineScore,
    growthPct,
    grade,
    certificateUnlocked,
    categoryScores,
    bestCategory,
    weakestCategory,
    avgDimensions,
    scoreTrajectory,
    daysCompleted,
  };
}

async function ensureCertificateRecord(
  userId: string,
  params: {
    finalScore: number;
    baselineScore: number;
    growthPct: number;
    grade: string;
    daysCompleted: number;
  }
) {
  const supabase = createAdminClient();

  // Check if exists
  const { data: existing } = await supabase
    .from("certificates")
    .select("id")
    .eq("user_id", userId)
    .maybeSingle();

  if (existing) return; // Already created

  // Get student ID
  const { data: profile } = await supabase
    .from("profiles")
    .select("student_id")
    .eq("id", userId)
    .single();

  const studentId = profile?.student_id || "MBAC-0000";

  // Generate unique verification ID
  const { data: verificationId } = await supabase.rpc("generate_verification_id");

  await supabase.from("certificates").insert({
    user_id: userId,
    student_id: studentId,
    verification_id: verificationId,
    final_score: params.finalScore,
    baseline_score: params.baselineScore,
    growth_pct: params.growthPct,
    grade: params.grade,
    days_completed: params.daysCompleted,
    total_submissions: params.daysCompleted,
    auto_approved: true,
    approved_at: new Date().toISOString(),
  });
}

export async function getFinalEvaluation(userId: string) {
  const supabase = createAdminClient();
  const { data } = await supabase
    .from("final_evaluations")
    .select("*")
    .eq("user_id", userId)
    .maybeSingle();
  return data;
}

export async function getCertificateRecord(userId: string) {
  const supabase = createAdminClient();
  const { data } = await supabase
    .from("certificates")
    .select("*")
    .eq("user_id", userId)
    .maybeSingle();
  return data;
}
