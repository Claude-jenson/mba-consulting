import { PDFDocument, rgb, StandardFonts, degrees } from "pdf-lib";
import QRCode from "qrcode";

export interface CertificateData {
  studentName: string;
  studentId: string;
  verificationId: string;
  issuedDate: string;       // formatted: "28 February 2026"
  finalScore: number;
  grade: "A" | "B" | "C";
  growthPct: number;
}

// Color palette — dark slate + gold brand
const COLORS = {
  darkBg:      rgb(0.039, 0.059, 0.118),   // #0a0f1e
  midBg:       rgb(0.059, 0.075, 0.153),   // #0f1327
  gold:        rgb(0.788, 0.635, 0.153),   // #c9a227
  goldLight:   rgb(0.886, 0.776, 0.447),   // #e2c672
  white:       rgb(1, 1, 1),
  offWhite:    rgb(0.878, 0.886, 0.902),   // #e0e2e6
  slate400:    rgb(0.58, 0.627, 0.714),    // #94a3b8
  slate600:    rgb(0.271, 0.349, 0.478),   // #475569
  goldBorder:  rgb(0.788, 0.635, 0.153),
};

const GRADE_LABELS: Record<string, string> = {
  A: "Distinction",
  B: "Merit",
  C: "Pass",
};

export async function generateCertificatePDF(
  data: CertificateData,
  appUrl: string = "https://mba-comm.netlify.app"
): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.create();

  // A4 Landscape: 842 × 595
  const page = pdfDoc.addPage([842, 595]);
  const W = 842;
  const H = 595;

  // ─── BACKGROUND ────────────────────────────────────────────
  // Dark base
  page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: COLORS.darkBg });

  // Subtle mid panel (center card)
  page.drawRectangle({
    x: 40, y: 40, width: W - 80, height: H - 80,
    color: COLORS.midBg,
    borderColor: COLORS.gold,
    borderWidth: 1.5,
    opacity: 0.95,
  });

  // Gold accent bar — top
  page.drawRectangle({ x: 40, y: H - 47, width: W - 80, height: 7, color: COLORS.gold });

  // Gold accent bar — bottom
  page.drawRectangle({ x: 40, y: 40, width: W - 80, height: 7, color: COLORS.gold });

  // Decorative corner brackets
  const bracketSize = 24;
  const bracketThickness = 2.5;
  const corners = [
    // top-left
    { x: 52, y: H - 60, dx: bracketSize, dy: -bracketSize },
    // top-right
    { x: W - 52, y: H - 60, dx: -bracketSize, dy: -bracketSize },
    // bottom-left
    { x: 52, y: 60, dx: bracketSize, dy: bracketSize },
    // bottom-right
    { x: W - 52, y: 60, dx: -bracketSize, dy: bracketSize },
  ];

  for (const c of corners) {
    page.drawLine({ start: { x: c.x, y: c.y }, end: { x: c.x + c.dx, y: c.y }, color: COLORS.gold, thickness: bracketThickness });
    page.drawLine({ start: { x: c.x, y: c.y }, end: { x: c.x, y: c.y + c.dy }, color: COLORS.gold, thickness: bracketThickness });
  }

  // ─── FONTS ─────────────────────────────────────────────────
  const fontBold     = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const fontRegular  = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const fontOblique  = await pdfDoc.embedFont(StandardFonts.HelveticaOblique);

  // ─── LEFT COLUMN ───────────────────────────────────────────
  const leftX = 80;

  // Logo badge — stylised "M"
  page.drawCircle({ x: leftX + 28, y: H - 110, size: 28, color: COLORS.gold });
  page.drawText("M", { x: leftX + 17, y: H - 120, size: 28, font: fontBold, color: COLORS.darkBg });

  // Course title
  page.drawText("MBA Communication Dominance", {
    x: leftX, y: H - 160, size: 11, font: fontBold, color: COLORS.gold,
  });

  // ─── CERTIFICATE OF COMPLETION heading ─────────────────────
  const centerX = W / 2;

  page.drawText("CERTIFICATE", {
    x: centerX - 120, y: H - 120, size: 28, font: fontBold, color: COLORS.white,
  });
  page.drawText("OF COMPLETION", {
    x: centerX - 82, y: H - 148, size: 16, font: fontRegular, color: COLORS.goldLight,
  });

  // Thin horizontal rule
  page.drawLine({
    start: { x: leftX, y: H - 162 }, end: { x: W - 80, y: H - 162 },
    color: COLORS.gold, thickness: 0.5, opacity: 0.4,
  });

  // "This certifies that"
  page.drawText("This certifies that", {
    x: centerX - 58, y: H - 190, size: 10, font: fontOblique, color: COLORS.slate400,
  });

  // ─── STUDENT NAME (largest text) ───────────────────────────
  const nameFontSize = 32;
  const nameWidth = fontBold.widthOfTextAtSize(data.studentName, nameFontSize);
  page.drawText(data.studentName, {
    x: centerX - nameWidth / 2,
    y: H - 232,
    size: nameFontSize,
    font: fontBold,
    color: COLORS.goldLight,
  });

  // Gold underline under name
  page.drawLine({
    start: { x: centerX - nameWidth / 2 - 10, y: H - 238 },
    end: { x: centerX + nameWidth / 2 + 10, y: H - 238 },
    color: COLORS.gold, thickness: 1,
  });

  // "has successfully completed"
  const bodyText = "has successfully completed the 30-Day Consulting Communication Transformation Program";
  const bodyWidth = fontRegular.widthOfTextAtSize(bodyText, 10.5);
  page.drawText(bodyText, {
    x: centerX - bodyWidth / 2, y: H - 265, size: 10.5, font: fontRegular, color: COLORS.offWhite,
  });

  // ─── METRICS ROW ─────────────────────────────────────────
  const metricsY = H - 310;
  const metrics = [
    { label: "Final Score",    value: `${data.finalScore}/100` },
    { label: "Grade",          value: `${data.grade} — ${GRADE_LABELS[data.grade]}` },
    { label: "Growth",         value: `${data.growthPct > 0 ? "+" : ""}${data.growthPct}%` },
    { label: "Days Completed", value: "30 Days" },
  ];

  const metricSpacing = (W - 160) / metrics.length;
  metrics.forEach((m, i) => {
    const mx = leftX + i * metricSpacing + metricSpacing / 2;
    const labelWidth = fontRegular.widthOfTextAtSize(m.label, 8);
    const valWidth   = fontBold.widthOfTextAtSize(m.value, 13);

    page.drawRectangle({
      x: mx - metricSpacing / 2 + 8, y: metricsY - 22,
      width: metricSpacing - 16, height: 44,
      color: rgb(1, 1, 1), opacity: 0.04,
      borderColor: COLORS.gold, borderWidth: 0.5, opacity: 0.5,
    });
    page.drawText(m.value, { x: mx - valWidth / 2, y: metricsY + 8, size: 13, font: fontBold, color: COLORS.goldLight });
    page.drawText(m.label, { x: mx - labelWidth / 2, y: metricsY - 10, size: 8, font: fontRegular, color: COLORS.slate400 });
  });

  // ─── BOTTOM ROW ─────────────────────────────────────────
  const bottomY = 82;

  // Issue date
  page.drawText("Date of Issue", { x: leftX, y: bottomY + 22, size: 8, font: fontRegular, color: COLORS.slate400 });
  page.drawText(data.issuedDate, { x: leftX, y: bottomY + 7, size: 11, font: fontBold, color: COLORS.offWhite });

  // Student ID
  const idX = leftX + 160;
  page.drawText("Student ID", { x: idX, y: bottomY + 22, size: 8, font: fontRegular, color: COLORS.slate400 });
  page.drawText(data.studentId, { x: idX, y: bottomY + 7, size: 11, font: fontBold, color: COLORS.offWhite });

  // Verification ID
  const vX = leftX + 320;
  page.drawText("Verification ID", { x: vX, y: bottomY + 22, size: 8, font: fontRegular, color: COLORS.slate400 });
  page.drawText(data.verificationId, { x: vX, y: bottomY + 7, size: 11, font: fontBold, color: COLORS.gold });

  // ─── QR CODE ─────────────────────────────────────────────
  const verifyUrl = `${appUrl}/verify?id=${data.verificationId}`;
  const qrDataUrl = await QRCode.toDataURL(verifyUrl, {
    width: 80,
    margin: 1,
    color: { dark: "#c9a227", light: "#0a0f1e" },
  });

  // Convert data URL to bytes
  const qrBase64 = qrDataUrl.split(",")[1];
  const qrBytes  = Buffer.from(qrBase64, "base64");
  const qrImage  = await pdfDoc.embedPng(qrBytes);

  const qrSize = 68;
  const qrX    = W - 80 - qrSize;
  const qrY    = 60;

  // QR border
  page.drawRectangle({
    x: qrX - 4, y: qrY - 4, width: qrSize + 8, height: qrSize + 8,
    color: COLORS.gold, opacity: 0.15, borderColor: COLORS.gold, borderWidth: 0.8,
  });
  page.drawImage(qrImage, { x: qrX, y: qrY, width: qrSize, height: qrSize });
  page.drawText("Scan to verify", { x: qrX - 2, y: qrY - 14, size: 7, font: fontRegular, color: COLORS.slate400 });

  // ─── WATERMARK "VERIFIED" (rotated, faint) ───────────────
  page.drawText("VERIFIED", {
    x: W / 2 - 60, y: H / 2 - 20,
    size: 72, font: fontBold,
    color: rgb(0.788, 0.635, 0.153),
    opacity: 0.04,
    rotate: degrees(35),
  });

  // ─── PDF METADATA ────────────────────────────────────────
  pdfDoc.setTitle(`Certificate — ${data.studentName}`);
  pdfDoc.setAuthor("MBA Communication Dominance");
  pdfDoc.setSubject(`Consulting Communication Certificate — ${data.grade} Grade`);
  pdfDoc.setCreator("MBA Communication Dominance Platform");
  pdfDoc.setKeywords(["MBA", "consulting", "certificate", "communication", data.verificationId]);

  return pdfDoc.save();
}
